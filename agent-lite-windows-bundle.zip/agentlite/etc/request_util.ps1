$httpPort = 5815
$agentRootPath = "http://localhost:$httpPort/agent/"

. "c:\temp\userenv.ps1"

function Download-File([string] $Path, [string] $ParamName='') {
    if ([string]::IsNullOrEmpty($Path)) {
        return ""
    }
    if ([string]::IsNullOrEmpty($ParamName)) {
        $requestPath = "repository/download?path=$Path"
    } else {
        $requestPath = "repository/$ParamName/download?path=$Path"
    }

    $uri = "{0}{1}" -f $agentRootPath, $requestPath

    $response = Invoke-WebRequest $uri
    #If http request failed, an exception should have been throwed. Just do an extra check
    if(($response.StatusCode -lt 200) -or ($response.StatusCode -ge 300)) {
        throw "Failed to download from $Path"
    }
    return $response.Content
}

function getStoragePassCode() {
    $uri = "{0}storage/passcode" -f $agentRootPath

    $response = Invoke-WebRequest $uri

    if(($response.StatusCode -lt 200) -or ($response.StatusCode -ge 300)) {
        throw "Failed to get storage passcode"
    }
    return $response.Content
}

function Backup-file([string] $Path, [string] $LocalFile) {
	if ([string]::IsNullOrEmpty($env:JOB_EXPORT_REQUEST_ID)) {
		$request = "$agentRootPath/repository/backup?path=$Path&localFile=$LocalFile"
	} else {
		$request = "$agentRootPath/repository/export?path=$Path&localFile=$LocalFile&jobExportRequestId=$env:JOB_EXPORT_REQUEST_ID"
	}
	
	$response = Invoke-WebRequest $request
	if(($response.StatusCode -lt 200) -or ($response.StatusCode -ge 300)) {
        throw "Failed to backup $LocalFile to remote repository"
    }
    return $response.Content
}

function Restore-file([string] $Path) {
	$request="$agentRootPath/repository/restore?path=$Path"
	$response = Invoke-WebRequest $request
	if(($response.StatusCode -lt 200) -or ($response.StatusCode -ge 300)) {
        throw "Failed to restore $Path"
    }
    return $response.Content
}
