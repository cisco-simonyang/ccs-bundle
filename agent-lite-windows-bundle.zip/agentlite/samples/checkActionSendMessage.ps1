. "C:\opt\agentlite\utils\agent_util.ps1"

Write-Host "Example file to show how to use the util method to send message to CloudCenter during execution of script"
Write-Host "Source the file agent_util.ps1 with absolute path, as done in this file's first line"
Write-Host "Invoke the function actionSendMessage with your custom message inside quotes whenever any status message has to be sent to CloudCenter"
actionSendMessage "Started script execution. Now sleep for 2 seconds"
Start-Sleep -Seconds 2
actionSendMessage "Woke Up.Ending ..."
