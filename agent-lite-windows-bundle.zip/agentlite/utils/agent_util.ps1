function actionSendMessage {
    param ([string]$message)

    $Body = [byte[]][char[]]$message;
    $Request = [System.Net.HttpWebRequest]::CreateHttp("http://localhost:5815/agent/status/action/message/$Env:actionExecutionId/$Env:cloudResourceUniqueId");
    $Request.Method = 'POST';
    $Stream = $Request.GetRequestStream();
    $Stream.Write($Body, 0, $Body.Length);
    $Request.GetResponse();
}

function agentSendLogMessage {
	param ([string]$message)
    Add-Content c:\temp\user_script.log "$message"
	$Body = [byte[]][char[]]$message;
    $Request = [System.Net.HttpWebRequest]::CreateHttp('http://localhost:5815/agent/status/message');
    $Request.Method = 'POST';
    $Stream = $Request.GetRequestStream();
    $Stream.Write($Body, 0, $Body.Length);
    $Request.GetResponse();
}