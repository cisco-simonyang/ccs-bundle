#!/bin/sh

. /usr/local/osmosix/etc/userenv

agentSendLogMessage() {

	echo "$*" >> "/tmp/user_script.log"
	retryCount=10
	retryDelay=3

	while [ "$retryCount" -gt 0 ]; do
		curl --header "Content-Type: text/plain" -X POST http://localhost:5810/agent/status/message --data "$*"

		if [ $? -eq 0 ];
		then
			break
		fi

		let "retryCount-=1"
		sleep $retryDelay
	done
}

actionSendMessage() {
	retryCount=10
	retryDelay=3

	while [ "$retryCount" -gt 0 ]; do
		curl --header "Content-Type: text/plain" -X POST http://localhost:5810/agent/status/action/message/"$actionExecutionId"/"$cloudResourceUniqueId" --data "$*"

		if [ $? -eq 0 ];
		then
			break
		fi

		let "retryCount-=1"
		sleep $retryDelay
	done
}

