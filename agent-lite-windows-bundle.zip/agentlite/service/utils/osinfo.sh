#!/bin/bash
## On execution a series of space-separated values are returned in the following format:
## <OS_FLAVOR> <OS_VERSION>
if [ -f /etc/centos-release ];  then
	distro='centos'
	version=`cat /etc/centos-release | sed s/.*release\ // | sed s/\ .*//`
elif [ -f /etc/redhat-release ]; then
	distro='rhel'
	version=`cat /etc/redhat-release | sed s/.*release\ // | sed s/\ .*//`
elif [ -f /etc/SuSE-release ]; then
	distro='suse'
	version=`cat /etc/os-release | grep -w VERSION | sed s/.*=\//`
elif [ -f /etc/lsb-release ]; then
	distro='ubuntu'
	version=`lsb_release -sr`
elif [ -f /etc/debian_version ]; then
	distro='debian'
else
	distro='generic'
fi
echo ${distro}
echo ${version}
