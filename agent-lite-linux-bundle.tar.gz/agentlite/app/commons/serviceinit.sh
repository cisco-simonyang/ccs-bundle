#!/bin/bash

# application script resource


GenerateNodeList() {
	if [ ! -d "$WORK_DIR" ]; then
		mkdir -p $WORK_DIR
	fi

	if [ -z "$NODE_LIST" ]; then
		logger -t "node list is empty"
		exit 1
	fi

	if [ -z "$MAP_TASKS" -o -z "$REDUCE_TASKS" ]; then
		logger -t "invalid $MAP_TASKS or $REDUCE_TASKS specified"
		exit 1
	fi

	node_list_file=$WORK_DIR/NODELIST
	if [  -e "$node_list_file" ]; then
		rm -rf $node_list_file
	fi

	cat /dev/null > $node_list_file
	nodes=$(echo $NODE_LIST | tr ',' ' ')
	for node in $nodes; do
		echo "$node" >> $node_list_file
	done
	param_file=$WORK_DIR/NODELIST.params
	touch $param_file
	echo "numMapTasksPerNode $MAP_TASKS" >> $param_file
	echo "numReduceTasksPerNode $REDUCE_TASKS" >> $param_file

	touch $WORK_DIR/NODELIST.ready
}

WaitForServiceReady() {
	while true; do
		if [ -f $WORK_DIR/NODELIST.init ]; then
			break
		fi
		sleep 5
	done
}

ServiceInit() {
	WORK_DIR=$1
	MAP_TASKS=$2
	REDUCE_TASKS=$3
	NODE_LIST=$4

	logger -t "OSMOSIX" "service initialization: generating node list"
	GenerateNodeList

	logger -t "OSMOSIX" "service initialization: waiting for service ready"
	WaitForServiceReady
	
	logger -t "OSMOSIX" "service is ready now"
}

ServiceInit $*



