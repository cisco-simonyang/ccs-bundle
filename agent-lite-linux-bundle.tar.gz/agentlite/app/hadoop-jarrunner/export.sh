#!/bin/bash

HadoopOutputPath=$1
LocalOutputPath=$2

if [ "$DataImportExport" == "false" ]; then
	logger -t "OSMOSIX" "[hadoop] data export skipped"
        exit 0
fi

#[ "`cat /tmp/hadoop.role`" != "mgmt" ] && exit 0
logger -t "OSMOSIX" "[hadoop] exporting hadoop path $HadoopOutputPath to local path $LocalOutputPath"
if [ ! -d "$LocalOutputPath" ]; then
	mkdir -p $LocalOutputPath
fi
hadoop fs -get $HadoopOutputPath/* $LocalOutputPath
hadoop fs -rm -r $HadoopOutputPath
logger -t "OSMOSIX" "[hadoop] exporting completed"

