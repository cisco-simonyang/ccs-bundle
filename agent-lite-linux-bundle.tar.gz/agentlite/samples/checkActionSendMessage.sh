#!/bin/sh
. /usr/local/agentlite/utils/agent_util.sh

echo "Example file to show how to use the util method to send message to CloudCenter during execution of script"
echo "Source the file agent_util.sh with absolute path, as done in this file's first line"
echo "Invoke the function actionSendMessage with your custom message inside quotes whenever any status message has to be sent to CloudCenter"

ans=$(( 2 + 5))
echo $ans
actionSendMessage "Result of adding 2 and 5 : $ans"
sleep 5
actionSendMessage "Woke up from Sleep .. will sleep again"
sleep 5
actionSendMessage "Woke up from Sleep"
echo "Done executing"
