#!/bin/sh

actionSendMessage() {
    retryCount=10
    retryDelay=3
    uri="http://localhost:5815/agent/status/action/message/"

    while [ "$retryCount" -gt 0 ]; do
        curl --header "Content-Type: text/plain" -X POST "$uri""$actionExecutionId""/""$cloudResourceUniqueId" --data "$*"

        if [ $? -eq 0 ];
        then
            break
        fi

        let "retryCount-=1"
        sleep $retryDelay
    done
}

agentSendLogMessage() {
	echo "$*" >> "/tmp/user_script.log"
	retryCount=10
	retryDelay=3

	while [ "$retryCount" -gt 0 ]; do
        curl --header "Content-Type: text/plain" -X POST http://localhost:5815/agent/status/message --data "$*"

        if [ $? -eq 0 ];
        then
            break
        fi

        let "retryCount-=1"
        sleep $retryDelay
    done
}