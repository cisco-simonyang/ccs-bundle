#!/bin/bash

log() {
	logger -t "OSMOSIX" "$*"
}

getCurrentOSInfo(){
	declare -A osInfoArr;

	if [ -f /etc/debian_version ]; then
		OS=Ubuntu;
		VER=$(cat /etc/issue.net);
		CODENAME=`lsb_release -c | awk '{print $2}'`
	elif [ -f /etc/redhat-release ]; then
		# TODO add code for Red Hat and CentOS here
		if grep -q "CentOS" "/etc/redhat-release"; then
			OS=CentOS;
		else
			OS=RHEL;
		fi
		VER=$(cat /etc/redhat-release);
	elif [ -f /etc/lsb-release ]; then
		OS=$(lsb_release -si);
		VER=$(lsb_release -sr);
	else
		OS=$(uname -s);
		VER=$(uname -r);
	fi

	if [ -z $OS ]
	then
		log "Cannot get the current OS name";
	fi

	case $(uname -m) in
		x86_64)
			BITS=64
			;;
		i*86)
			BITS=32
			;;
		*)
			BITS=?
			;;
	esac

	log "OS=$OS|VER=$VER|BITS=$BITS|CODENAME=$CODENAME";
	echo "OS=$OS|VER=$VER|BITS=$BITS|CODENAME=$CODENAME";
}

#get information about the current os : name, version, arch
currentOsInfo=$(getCurrentOSInfo);
IFS='|' read -ra os_info <<< "$currentOsInfo";

for i in "${os_info[@]}";
do
	IFS='=' read -a resultMap <<< "$i"
	if [ "${resultMap[0]}" == "OS" ]
	then
		os="${resultMap[1]}";
	elif [ "${resultMap[0]}" == "VER" ]
	then
		ver="${resultMap[1]}";
	elif [ "${resultMap[0]}" == "BITS" ]
	then
		bits="${resultMap[1]}";
	elif [ "${resultMap[0]}" == "CODENAME" ]
	then
		codename="${resultMap[1]}";
	fi
done
