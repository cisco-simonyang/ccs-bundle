#!/bin/bash

. /usr/local/osmosix/service/utils/os_info_util.sh
. /usr/local/osmosix/etc/request_util.sh

#get information about the current os : name, version, arch
currentOsInfo=$(getCurrentOSInfo);
IFS='|' read -ra os_info <<< "$currentOsInfo";

for i in "${os_info[@]}";
do
	IFS='=' read -a resultMap <<< "$i"
	if [ "${resultMap[0]}" == "OS" ]
	then
		os="${resultMap[1]}";
	elif [ "${resultMap[0]}" == "VER" ]
	then
		ver="${resultMap[1]}";
	fi
done


cleanup_repo() {
	action=$1
	backup_dir='bkprepo'
	cliqr_yum_config='cliqr.repo'  

	if [[ ${action} == "pre" ]]; then
		cd /etc/yum.repos.d/
		if [[ -f ${cliqr_yum_config} ]]; then
			mkdir -p ${backup_dir}
			mv *  ${backup_dir}  
			mv ${backup_dir}/${cliqr_yum_config} .
			if [[ $? -ne 0 ]]; then
				exit 2
			fi
		fi
	fi

	if [[ ${action} == "post" ]]; then
		cd /etc/yum.repos.d/
		if [[ -d ${backup_dir} ]]; then
			mv   ${backup_dir}/* .
			if [[ $? -ne 0 ]]; then
				exit 2
			fi
			rmdir   ${backup_dir}
		fi
	fi

	return 0
}


waitForDebianPackageManager(){
	while sudo fuser /var/lib/dpkg/lock >/dev/null 2>&1; do
		echo "Waiting for package manager lock..."
		sleep 1
	done
}

install() {
	#name of the service to be installed
	service_name=$1;
	if [ "$os" == "Ubuntu" ]
	then
		eval "declare -Ag  package_map=""${2#*=}" # an associative array of the osName to packageName
	else
		eval "declare -A  package_map=""${2#*=}" # an associative array of the osName to packageName
	fi
	for i in "${!package_map[@]}"
	do
		echo "key  : $i"
		echo "value: ${package_map[$i]}"
	done
	for i in "${!package_map[@]}"; do
		if [ $os == "$i" ]
		then
			#name of the particular package to be installed
			package_name="${package_map[$i]}"
		fi
	done        

	if [ ! -z $package_name ]
	then
		if [ $os == "Ubuntu" ]
		then
			export DEBIAN_FRONTEND=noninteractive
			waitForDebianPackageManager
			pkg_string=$(echo $package_name | cut -d '=' -f 1)
			ver_string=$(echo $package_name | cut -d '=' -f 2)
			apt-get install -y $package_name
			if [ $? -ne 0 ]
			then
				if [ -n "$ver_string"  ]; then 
					echo "ver_string is not empty. So lets try with to get latest package"
					apt-get install -y $pkg_string	
					if [ $? -ne 0 ]
					then
						echo "Install of $pkg_name also failed"
						exit 2 
					fi
				else
					echo "Install  of $package_name failed" 
					exit 2
				fi
			fi
		elif [ $os == "suse11" ] || [ $os == "suse12" ]
		then
			zypper -n in $package_name
			if [ $? -ne 0 ]
			then
				echo "Install  of $package_name failed" 
				exit 2
			fi
		elif ([ $os == "CentOS" ] || [ $os == "RHEL" ] || [ $os == "amazon" ])
		then
			cleanup_repo "pre"
			yum install -y "$package_name"
			if [ $? -ne 0 ]
			then
				echo "Install  of $package_name failed. Trying with skip broken option"        
				yum --skip-broken install -y $package_name
				if [ $? -ne 0 ]
				then
					exit 2
				fi
			fi
			cleanup_repo "post"
		fi
	else
		echo "No package found. Installation of $service_name failed." 
		exit 2
	fi

	return 0
}

preInstall(){
	#name of the operation to be performed
	operation=$1;
	echo "Called Pre-Install for : $os"
	if ([ $operation == "update-multiverse" ])
	then
		if [ $os == "Ubuntu" ]
		then
			perl -pi -e "s/^# (deb.*multiverse.*)/\1/" /etc/apt/sources.list

			apt-get update
			if [ $? -ne 0 ]
			then
				echo "check update failed"
			fi

		elif ([ $os == "CentOS" ] || [ $os == "RHEL" ])
		then
			yum check-update
			if [ $? -ne 0 ]
			then
				echo "check update failed"
				# return 1
			fi
		fi
	elif [ $operation == "package-update" ]
	then
		if [ $os == "Ubuntu" ]
		then
			apt-get update
		elif ([ $os == "CentOS" ] || [ $os == "RHEL" ])
		then
			yum check-update
		fi
	elif ([ $operation == "apt-update" ] && [ $os == "Ubuntu" ])
	then
		apt-get update
	elif ([ $operation == "apt-get-install" ])
	then
		serviceName=$2
		apt-get install -y $serviceName
	fi


	return 0    
}
check_systemctl_presence(){
	#returns 0 is systemctl is present
	#returns 1 otherwise

	type systemctl > /dev/null 2>&1
	if [[ $? -ne 0 ]]; then
		return 1
	fi
	return 0
}

postInstall(){
	#name of the operation to be performed
	operation=$1;
	serviceName=$2;
	echo "Called Post-Install for : $os and Service : $serviceName"
	if ([ $operation == "removeSystemVstyleInitScriptlinks" ])
	then
		if [ $os == "Ubuntu" ]
		then
			update-rc.d -f $serviceName remove
		elif ([ $os == "CentOS" ] || [ $os == "RHEL" ])
		then
			chkconfig --del $serviceName
		fi

		if [ $? -ne 0 ]
		then
			return 1
		fi
	elif [ $operation == "update-rc" ]
	then
		update-rc.d -f $serviceName remove
		if [ $? -ne 0 ]
		then
			return 1
		fi
	elif [ $operation == "chkconfig" ]
	then
		chkconfig $serviceName off
	elif [ $operation == "systemd" ]
	then
		systemctl disable $serviceName
	fi

	return 0
}

serviceInstall(){
	serviceName=$1;
	if [ $os == "Ubuntu" ]
	then
		apt-get install -y $serviceName
	elif ([ $os == "CentOS" ] || [ $os == "RHEL" ])
	then
		cleanup_repo "pre"
		yum install -y $serviceName
		if [ $? -ne 0 ]
		then
			echo "Install  of $serviceName failed. Trying with skip broken option"
			yum --skip-broken install -y $serviceName
			if [ $? -ne 0 ]
			then
				exit 2
			fi
		fi
		cleanup_repo "post"
	fi
}

packageUpdate(){
	if [ $os == "Ubuntu" ]
	then
		apt-get update
	elif ([ $os == "CentOS" ] || [ $os == "RHEL" ])
	then
		yum check-update
	fi
}

installJava6(){
	echo "Installing Java 6..."	
	USER_JDK_URL='http://repo.cliqrtech.com/bin/jdk-6u45-linux-x64.bin'
	USER_JDK_BIN='jdk-6u45-linux-x64.bin'
	USER_JDK_DIR='jdk1.6.0_45'
	if [[ ! -z $CUSTOM_REPO_URL ]]; then
		USER_JDK_URL=${CUSTOM_REPO_URL}/bin/${USER_JDK_BIN}
	fi

	if [[ -d '/usr/lib/jvm/java-6-sun' ]]; then
		echo "JDK 6 present in instance"
		return 0
	fi

	mkdir -p /usr/lib/jvm
	cd /usr/lib/jvm

	installWget
	wget ${USER_JDK_URL}
	if [[ $? -ne 0 ]]; then
		echo "Failed downloading jdk"
		exit 1
	fi

	chmod 755 $USER_JDK_BIN
	./${USER_JDK_BIN} -noregister
	if [[ $? -ne 0 ]]; then
		echo "Failed installing jdk"
		exit 1
	fi

	ln -s /usr/lib/jvm/${USER_JDK_DIR} /usr/lib/jvm/java-6-sun
	if [[ $? -ne 0 ]]; then
		echo "Failed creating soft link for jdk"
		exit 1
	fi

	rm -f ${USER_JDK_BIN}

	return 0
}

installJava7(){
	echo "Installing Java 7..."	
	USER_JDK_URL='http://repo.cliqrtech.com/bin/jdk-7u80-linux-x64.tar.gz'
	USER_JDK_TAR='jdk-7u80-linux-x64.tar.gz'
	USER_JDK_DIR='jdk1.7.0_80'

	if [[ ! -z $CUSTOM_REPO_URL ]]; then
		USER_JDK_URL=${CUSTOM_REPO_URL}/bin/${USER_JDK_TAR}
	fi	

	if [[ -d '/usr/lib/jvm/java-7-sun' ]]; then
		echo "JDK 7 present in instance"
		return 0
	fi

	mkdir -p /usr/lib/jvm
	cd /usr/lib/jvm

	installWget
	wget ${USER_JDK_URL}
	if [[ $? -ne 0 ]]; then
		echo "Failed downloading jdk"
		exit 1
	fi

	tar -zxvf ${USER_JDK_TAR} 
	if [[ $? -ne 0 ]]; then
		echo "Failed extracting jdk"
		exit 1
	fi

	ln -s /usr/lib/jvm/${USER_JDK_DIR} /usr/lib/jvm/java-7-sun
	if [[ $? -ne 0 ]]; then
		echo "Failed creating soft link for jdk"
		exit 1
	fi

	rm -f ${USER_JDK_TAR}

	return 0
}

installJava8_152(){
	echo "Installing Java 8..."
	USER_JDK_URL='http://repo.cliqrtech.com/bin/jdk-8u152-linux-x64.tar.gz'
	USER_JDK_TAR='jdk-8u152-linux-x64.tar.gz'
	USER_JDK_DIR='jdk1.8.0_152'
	if [[ ! -z $CUSTOM_REPO_URL ]]; then
		USER_JDK_URL=${CUSTOM_REPO_URL}/bin/${USER_JDK_TAR}
	fi
	if [[ -d '/usr/lib/jvm/java-8-sun' ]]; then
		echo "JDK 8 present in instance"
		return 0
	fi
	mkdir -p /usr/lib/jvm
	cd /usr/lib/jvm
	installWget
	wget ${USER_JDK_URL}
	if [[ $? -ne 0 ]]; then
		echo "Failed downloading jdk"
		exit 1
	fi
	tar -zxvf ${USER_JDK_TAR}
	if [[ $? -ne 0 ]]; then
		echo "Failed extracting jdk"
		exit 1
	fi
	ln -s /usr/lib/jvm/${USER_JDK_DIR} /usr/lib/jvm/java-8-sun
	if [[ $? -ne 0 ]]; then
		echo "Failed creating soft link for jdk"
		exit 1
	fi
	rm -f ${USER_JDK_TAR}
	return 0
}

installJava8_131(){
	echo "Installing Java 8..."
	USER_JDK_URL='http://repo.cliqrtech.com/bin/jdk-8u131-linux-x64.tar.gz'
	USER_JDK_TAR='jdk-8u131-linux-x64.tar.gz'
	USER_JDK_DIR='jdk1.8.0_131'
	if [[ ! -z $CUSTOM_REPO_URL ]]; then
		USER_JDK_URL=${CUSTOM_REPO_URL}/bin/${USER_JDK_TAR}
	fi
	if [[ -d '/usr/lib/jvm/java-8-sun' ]]; then
		echo "JDK 8 present in instance"
		return 0
	fi
	mkdir -p /usr/lib/jvm
	cd /usr/lib/jvm
	installWget
	wget ${USER_JDK_URL}
	if [[ $? -ne 0 ]]; then
		echo "Failed downloading jdk"
		exit 1
	fi
	tar -zxvf ${USER_JDK_TAR}
	if [[ $? -ne 0 ]]; then
		echo "Failed extracting jdk"
		exit 1
	fi
	ln -s /usr/lib/jvm/${USER_JDK_DIR} /usr/lib/jvm/java-8-sun
	if [[ $? -ne 0 ]]; then
		echo "Failed creating soft link for jdk"
		exit 1
	fi
	rm -f ${USER_JDK_TAR}
	return 0
}

installJava8_181(){
	echo "Installing Java 8..."
	USER_JDK_URL='http://repo.cliqrtech.com/bin/jdk-8u181-linux-x64.tar.gz'
	USER_JDK_TAR='jdk-8u181-linux-x64.tar.gz'
	USER_JDK_DIR='jdk1.8.0_181'
	if [[ ! -z $CUSTOM_REPO_URL ]]; then
		USER_JDK_URL=${CUSTOM_REPO_URL}/bin/${USER_JDK_TAR}
	fi
	if [[ -d '/usr/lib/jvm/java-8-sun' ]]; then
		echo "JDK 8 present in instance"
		return 0
	fi
	mkdir -p /usr/lib/jvm
	cd /usr/lib/jvm
	wget ${USER_JDK_URL}
	if [[ $? -ne 0 ]]; then
		echo "Failed downloading jdk"
		exit 1
	fi
	tar -zxvf ${USER_JDK_TAR}
	if [[ $? -ne 0 ]]; then
		echo "Failed extracting jdk"
		exit 1
	fi
	ln -s /usr/lib/jvm/${USER_JDK_DIR} /usr/lib/jvm/java-8-sun
	if [[ $? -ne 0 ]]; then
		echo "Failed creating soft link for jdk"
		exit 1
	fi
	rm -f ${USER_JDK_TAR}
	return 0
}

installJava8(){
	echo "Installing Java 8..."	
	USER_JDK_URL='http://repo.cliqrtech.com/bin/jdk-8u102-linux-x64.tar.gz'
	USER_JDK_TAR='jdk-8u102-linux-x64.tar.gz'
	USER_JDK_DIR='jdk1.8.0_102'
	if [[ ! -z $CUSTOM_REPO_URL ]]; then
		USER_JDK_URL=${CUSTOM_REPO_URL}/bin/${USER_JDK_TAR}
	fi	

	if [[ -d '/usr/lib/jvm/java-8-sun' ]]; then
		echo "JDK 8 present in instance"
		return 0
	fi

	mkdir -p /usr/lib/jvm
	cd /usr/lib/jvm

	installWget
	wget ${USER_JDK_URL}
	if [[ $? -ne 0 ]]; then
		echo "Failed downloading jdk"
		exit 1
	fi

	tar -zxvf ${USER_JDK_TAR} 
	if [[ $? -ne 0 ]]; then
		echo "Failed extracting jdk"
		exit 1
	fi

	ln -s /usr/lib/jvm/${USER_JDK_DIR} /usr/lib/jvm/java-8-sun
	if [[ $? -ne 0 ]]; then
		echo "Failed creating soft link for jdk"
		exit 1
	fi

	rm -f ${USER_JDK_TAR}

	return 0
}

installUnzip(){
	if ([ "$os" == "CentOS" ] || [ "$os" == "RHEL" ]) && ([ `yum list installed | grep unzip | wc -l` -eq 0 ])
	then
		#install unzip if its not installed
		echo "Installing unzip"
		yum install -y unzip
		if [ $? -ne 0 ]
		then
			echo "Failed to install unzip"
			exit 1
		fi
	elif [ $os == "Ubuntu" ]
	then
		echo "Installing unzip"
		apt-get install -y unzip
		if [ $? -ne 0 ]
		then
			echo "Failed to install unzip"
			exit 1
		fi
	fi

	return 0
}

installPhp(){
	if ([ "$os" == "CentOS" ] || [ "$os" == "RHEL" ])
	then
		serviceInstall php
		serviceInstall php-mysql php-common php-gd php-mbstring php-mcrypt php-devel php-xml
		serviceInstall python
		serviceInstall php-gd php-pear php-curl

		#post php install
		a2enmod ssl
		service httpd restart
		servive httpd stop

	elif [ $os == "Ubuntu" ]
	then
		serviceInstall php5
		serviceInstall libapache2-mod-auth-mysql php5-mysql
		serviceInstall perl libapache2-mod-perl2
		serviceInstall python libapache2-mod-python

		#post php install
		a2enmod ssl
		check_error $? "Error running a2enmod ssl" 1    
		/etc/init.d/apache2  restart
		/etc/init.d/apache2  stop

		apt-get update
		apt-get -y install php5-gd php-pear php5-curl
		check_error $? "Failed installing php gd" 1
	fi    
}

#Check for exit status and print error msg
check_error(){
	status=$1
	msg=$2
	exit_status=$3

	if [[ ${status} -ne 0 ]]; then
		echo -e "\033[31m       - ${msg} \033[0m"   
		exit ${exit_status}
	fi

	return 0
}

installWget(){
	if ([ "$os" == "CentOS" ] || [ "$os" == "RHEL" ]) && ([ `yum list installed | grep wget | wc -l` -eq 0 ])
	then
		#install wget if its not installed
		echo "Installing wget"
		yum install -y wget
		if [ $? -ne 0 ]
		then
			echo "Failed to install wget"
			exit 1
		fi
	elif ([ "$os" == "Ubuntu" ]) && ([ `dpkg-query -l | grep wget | wc -l` -eq 0 ])
	then
		echo "Installing wget"
		apt-get install -y wget
		if [ $? -ne 0 ]
		then
			echo "Failed to install wget"
			exit 1
		fi
	fi

	return 0
}


waitForPropertyInFile(){
	fileName=$1
	propName=$2
	echo "Checking for $2 in file: $1"
	let count=0;
	while ! grep "$propName" $fileName
	do
		echo "Waiting for $propName in $fileName - attempt [ $count ]"
		let count=$count+1
		sleep 10;
	done
}


installCurl(){
	echo "Installing curl"
	if ([ "$os" == "CentOS" ] || [ "$os" == "RHEL" ]) && ([ `yum list installed | grep curl | wc -l` -eq 0 ])
	then
		yum install -y curl
	elif ([ "$os" == "Ubuntu" ]) && ([ `dpkg-query -l | grep curl | wc -l` -eq 0 ])
	then
		apt-get install -y curl
	else
		echo "cURL is already installed"
		return 0
	fi

	if [ $? -ne 0 ]
	then
		echo "Failed to install curl"
		return 1
	fi

	return 0
}

checkIfUrlIsValid(){
	url=$1
	if [ ! -z $url ]; then
		echo "Check validity for URL: $url..."

		#Install cURL if not already installed
		installCurl

		if ([ `curl -I -H 'Cache-Control: no-cache' --stderr /tmp/checkValidUrlErr $url | head -1 | cut -d' ' -f2` -eq 200 ])
		then
			if [[ -f /tmp/checkValidUrlErr ]]; then
				error=`cat /tmp/checkValidUrlErr`
				rm -rf /tmp/checkValidUrlErr
				echo "Content of /tmp/checkValidUrlErr : $error"
			fi
			echo "URL is valid"
			return 0
		else
			if [[ -f /tmp/checkValidUrlErr ]]; then
				error=`cat /tmp/checkValidUrlErr`
				rm -rf /tmp/checkValidUrlErr
				echo "Content of /tmp/checkValidUrlErr : $error"
			fi
			echo "URL is not valid. "
			return 1
		fi
	else
		echo "Missing input URL to check for validity: $url"
		return 1
	fi
}

runNodejsAndExportPath() {
	if [ -z "$cliqrNodejsPublicPath" ]; then
		if [ -z "$1" ]; then
			cliqrNodejsPublicPath=/root/node/public
		else
			cliqrNodejsPublicPath=$1
		fi
	fi

	cd /usr/local/
	installWget
	wget https://s3.amazonaws.com/cliqr/node-v0.12.2-linux-x64.tar.gz
	tar xzvf node-v0.12.2-linux-x64.tar.gz
	ln -s node-v0.12.2-linux-x64/ node
	export PATH=$PATH:/usr/local/node/bin
	npm install -g express
	export NODE_PATH=/usr/local/node/lib/node_modules
	mkdir -p $cliqrNodejsPublicPath
	cd "$cliqrNodejsPublicPath"/..
	spath=`getStorageServerPasscode`
	cat > dfs.js <<EOF
var express = require('express');
var app = express();
var http = require('http');
var https = require('https');
var fs = require('fs');
var meta;

console.log("Stealth path: " + spath);

function getMetadata() {
	if (meta == undefined) {
		meta = require('./meta.json');
	}
}

httpsOptions = {
	key: fs.readFileSync('server-key.pem'),
	cert: fs.readFileSync('server-cert.pem')
};

fs.exists('./meta.json', function(exists) {
	if (exists) {
		getMetadata();
	}
});

app.get('/:key', function (req, res) {
	if (meta == undefined) {
		return res.send('');
	} else {
		return res.send(meta[req.params.key]);
	}
});

app.get('/:spath/:file', function (req, res) {
	if ("$spath" == req.params.spath) {
		console.log("Script download requested");
		var file = __dirname + '/public/' + req.params.file;
		fs.exists(file, function(exists) {
			res.download(file);    
		});
	} else if (meta == undefined) {
		return res.send('');
	} else {
		return res.send(meta[req.params.key]);
	}
});

https.createServer(httpsOptions, app).listen(443)
http.createServer(function (req, res) {
	res.writeHead(301, { "Location": "https://" + req.headers['host'] + req.url });
	res.end();
}).listen(80);
EOF
mv "$cliqrNodejsPublicPath"/meta.json .
openssl genrsa -out server-key.pem 1024
(echo "US"; echo "CA"; echo "San Jose"; echo "CliQr"; echo "RD"; echo "cliqr"; echo "admin@cliqr.com"; echo; echo) | openssl req -new -key server-key.pem -out server-certrequest.csr
openssl x509 -req -in server-certrequest.csr -signkey server-key.pem -out server-cert.pem
rm -rf server-certrequest.csr
node dfs.js > /tmp/node.log 2>&1 &
}
