#!/bin/bash

. /usr/local/osmosix/etc/userenv

overrideNosqlIp() {
	if [ ! -z $CliqrTier_NoSQLDatabase_IP ];
	then
		export CliqrTier_NoSQLDatabase_IP=`echo $CliqrTier_NoSQLDatabase_IP | awk -F , '{print $1}'`
	fi
}
