#!/bin/bash

exec 2>&1

OSSVC_HOME=/usr/local/osmosix/service
. $OSSVC_HOME/utils/install_util.sh
. $OSSVC_HOME/utils/os_info_util.sh

CUSTOM_REPO="Custom Repo"
CLOUD_REPO_KEY=cloudrepo.key
PACKAGE_FOLDER=''

DEB_REPO=debRepo
DEB_SOURCES_LIST=/etc/apt/sources.list
DEB_APT_PREFERENCE=/etc/apt/preferences.d/local-pin-900

YUM_REPO=yumRepo
CLIQR_YUM_CONFIG=cliqr.repo
YUM_CONFIG_REPO=/etc/yum.repos.d/$CLIQR_YUM_CONFIG
NULL_VAR="null"

log "Configuring Custom Repository"
echo "Configuring Custom Repository"

CUSTOM_REPO_URL=$1
if [ -z "$CUSTOM_REPO_URL" ]; then
	log "$CUSTOM_REPO: Missing custom repo parameter, hence, skipping configuration."
	echo "$CUSTOM_REPO: Missing custom repo parameter, hence, skipping configuration."
	exit 0
fi

VAR1=$(echo $CUSTOM_REPO_URL | tr [:upper:] [:lower:])

if [[ $VAR1 == $NULL_VAR ]];then
	log "$CUSTOM_REPO: Custom repo parameter set to NULL , hence, skipping configuration."
	echo "$CUSTOM_REPO: Custom repo parameter set to NULL , hence, skipping configuration."
	exit 0	
fi

if [[ $os == "Ubuntu" ]]
then
	#add a new entry in /etc/apt/sources.list.
	if ([[ $ver =~ "14.04" ]])
	then
		PACKAGE_FOLDER="ubuntu1404";
	elif ([[ $ver =~ "16.04" ]])
	then
		PACKAGE_FOLDER="ubuntu1604";
	elif ([[ $ver =~ "18.04" ]])
	then
		PACKAGE_FOLDER="ubuntu1804";
	fi
	if [[ $bits =~ "64" ]]
	then
		PACKAGE_FOLDER=$PACKAGE_FOLDER"/amd64";
	elif [[ $bits =~ "32" ]]
	then
		PACKAGE_FOLDER=$PACKAGE_FOLDER"/i386";
	fi

	if type curl 2>/dev/null; then
		log "Using cURL to download gpg key: $CUSTOM_REPO_URL/$CLOUD_REPO_KEY ..."
		curl -O $CUSTOM_REPO_URL/$CLOUD_REPO_KEY
	elif type wget 2>/dev/null; then
		log "Using wget to download gpg key: $CUSTOM_REPO_URL/$CLOUD_REPO_KEY ..."
		wget $CUSTOM_REPO_URL/$CLOUD_REPO_KEY
	else
		log "No curl or wget found. Cannot download gpg key: $CUSTOM_REPO_URL/$CLOUD_REPO_KEY"
		log "Use an image which has cURL or wget available."
		exit 1
	fi

	if [ $? -ne 0 ]
	then
		log "Failed to download gpg key: $CUSTOM_REPO_URL/$CLOUD_REPO_KEY"
		echo "Failed to download gpg key: $CUSTOM_REPO_URL/$CLOUD_REPO_KEY"
		exit 1
	fi

	log "Add the key: $CLOUD_REPO_KEY"
	apt-key add $CLOUD_REPO_KEY
	log "Key added"


	log "$CUSTOM_REPO: The package folder is: $PACKAGE_FOLDER. Adding entry in $DEB_SOURCES_LIST"
	echo "$CUSTOM_REPO: The package folder is: $PACKAGE_FOLDER. Adding entry in $DEB_SOURCES_LIST"

	echo "deb $CUSTOM_REPO_URL/$DEB_REPO/$PACKAGE_FOLDER/binary/ /" | cat - $DEB_SOURCES_LIST > cliqr_repo_temp && mv cliqr_repo_temp $DEB_SOURCES_LIST
	log "$CUSTOM_REPO: Updated $DEB_SOURCES_LIST"

	log "$CUSTOM_REPO: Pinning the custom repo, to give it highest precedence"
	echo "$CUSTOM_REPO: Pinning the custom repo, to give it highest precedence"

	{ echo "Package: *"; echo "Pin: release o=CloudRepo"; echo "Pin-Priority: 900"; } >> $DEB_APT_PREFERENCE
	log "$CUSTOM_REPO: Updated $DEB_APT_PREFERENCE"

elif ([[ $os == "CentOS" ]] || [[ $os == "RHEL" ]])
then
	#add a new repo entry in /etc/yum.repos.d
	if [[ $os == "CentOS" ]]
	then
		if ([[ $ver =~ [[:space:]]+6.5 ]])
		then
			PACKAGE_FOLDER="centos/6.5";
		elif ([[ $ver =~ [[:space:]]+6. ]])
		then
			PACKAGE_FOLDER="centos/6.0";
		elif ([[ $ver =~ [[:space:]]+7. ]])
		then
			PACKAGE_FOLDER="centos/7.0";
		fi
	elif [[ $os == "RHEL" ]]
	then
		if ([[ $ver =~ "6.6" ]])
		then
			PACKAGE_FOLDER="rhel/6.6";
		elif ([[ $ver =~ "6" ]])
		then
			PACKAGE_FOLDER="rhel/6.0";
		elif ([[ $ver =~ "7" ]])
		then
			PACKAGE_FOLDER="rhel/7.0";
		elif ([[ $ver =~ "8" ]])
		then
		    PACKAGE_FOLDER="rhel/8.0";
		fi
	fi

	if [[ $bits =~ "64" ]]
	then
		PACKAGE_FOLDER=$PACKAGE_FOLDER"/x86_64";
	elif [[ $bits =~ "32" ]]
	then
		PACKAGE_FOLDER=$PACKAGE_FOLDER"/i386";
	fi

	if checkIfUrlIsValid $CUSTOM_REPO_URL/$YUM_REPO/$PACKAGE_FOLDER/Packages/repodata/repomd.xml; then
		log "$CUSTOM_REPO: The package folder is: $PACKAGE_FOLDER. Adding new repo config file, $CLIQR_YUM_CONFIG, with highest priority"
		echo "$CUSTOM_REPO: The package folder is: $PACKAGE_FOLDER. Adding new repo config file, $CLIQR_YUM_CONFIG, with highest priority"
		{ echo "[cloudrepo]"; echo "name=Custom repo for cloud files"; echo "baseurl=$CUSTOM_REPO_URL/$YUM_REPO/$PACKAGE_FOLDER/Packages"; echo "enabled=1"; echo "gpgcheck=0"; echo "priority=1"; echo "skip_if_unavailable=True"; } >> $YUM_CONFIG_REPO

		log "$CUSTOM_REPO: Updated $YUM_CONFIG_REPO"

		chmod +x $YUM_CONFIG_REPO
	else
		log "$CUSTOM_REPO: The custom repo is not supported for the OS: $os, VER: $ver. Skipping custom-repo configuration..."
		echo "$CUSTOM_REPO: The custom repo is not supported for the OS: $os, VER: $ver. Skipping custom-repo configuration..."
	fi
fi

#run update
log "$CUSTOM_REPO: Update packages..."
packageUpdate

if [ $? -ne 0 ]
then
	log "Package update failed"
	echo "Package update failed"
fi

log "Custom Repository configuration done."

echo 0
