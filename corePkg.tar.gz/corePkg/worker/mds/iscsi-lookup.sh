#!/bin/bash

ip=$1
target=$2

logger -t "OSMOSIX" "wait for 301 sec for volume to be ready"
sleep 301

iscsiadm -m discovery -t sendtargets -p $ip -o new
iscsiadm --mode node --portal $ip --login --targetname $target
iscsiadm --mode node --portal $ip --targetname $target -o update -n node.startup -v automatic
iscsiadm --mode node --portal $ip --targetname $target -o update -n node.conn[0].startup -v automatic
iscsiadm --mode node --portal $ip --targetname $target -o update -n node.session.timeo.replacement_timeout -v 420

exit 0
