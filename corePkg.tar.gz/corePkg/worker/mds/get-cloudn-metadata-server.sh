#!/bin/bash

if [ -f /etc/redhat-release ]
then
        METADATA_SERVER_IP=$(cat /var/lib/dhclient/dhclient-eth0.leases | grep dhcp-server-identifier | tail -1 | awk '{print $NF}' | tr -d '\;')
        echo $METADATA_SERVER_IP
else
        DHCP_FOLDERS="/var/lib/dhcp/*"
        file_count=0

        for DHCP_FILE in $DHCP_FOLDERS
        do
                if [ -f $DHCP_FILE ]
                then
                        file_count=$((file_count+1))
                        METADATA_SERVER_IP=$(grep dhcp-server-identifier $DHCP_FILE | tail -1 | awk '{print $NF}' | tr -d '\;')

                        if [ -n $METADATA_SERVER_IP ]
                        then
                                logger -t "OSMOSIX" "Found metadata server $METADATA_SERVER_IP "
                    echo $METADATA_SERVER_IP
                    break;

                        else
                                logger -t "cloud" "Could not find metadata server IP in $DHCP_FILE"
                        fi
                fi
        done
fi