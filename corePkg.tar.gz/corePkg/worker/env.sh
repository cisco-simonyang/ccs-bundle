
export CLIQR_TGZ='osmosix.tgz'

if [ $CLOUD_OS == "ubuntu10" ] 
then
	export CLIQR_TGZ='osmosix.tgz'
fi

if [ $CLOUD_OS == "ubuntu1204" ] 
then
	export CLIQR_TGZ='osmosix.tgz'
fi

NEW_CLOUD_TYPE=$CLOUD_TYPE


if [ $CLOUD_TYPE == "rackspace" ]
then
	NEW_CLOUD_TYPE='rackspace2'
fi


export NEW_CLOUD_TYPE

export COMPONENT_TYPE='worker'

export STARTER_FILE='starter'


if [ $CLOUD_TYPE == "rackspace" ]
then
	export STARTER_FILE='starter_mds'
fi

if [ $CLOUD_TYPE == "IBM" ]
then
	export STARTER_FILE='starter_ibm'
fi

if [ $CLOUD_TYPE == "azure" ]
then
	export STARTER_FILE='starter_azure'
fi

if [ $CLOUD_TYPE == "azurepack" ]
then
	export STARTER_FILE='starter_azurepack'
fi

if [ $CLOUD_TYPE == "vcd" ]
then
	export STARTER_FILE='starter_vcd'
fi

if [ $CLOUD_TYPE == "vmware" ]
then
	export STARTER_FILE='starter_vmware'
fi

if [ $CLOUD_TYPE == "opsource" ]
then
	export STARTER_FILE='starter_mds'
fi

