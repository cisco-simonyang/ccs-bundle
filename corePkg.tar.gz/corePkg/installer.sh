#!/bin/bash


os=$1
arch=$2
cloud=$3
module=$4

root_dir="$( cd "$( dirname $0 )" && pwd )"

export CLOUD_OS=$os
export CLOUD_ARCH=$arch
export CLOUD_TYPE=$cloud
export MODULE=$module

echo "Running Module $module"
echo "Operating system $os on $arch bit"

# Search for an external property file
ext_prop=${root_dir}/../user.prop
if [[ -f ${ext_prop} ]]; then
  echo "Found external property file ${ext_prop} . Sourcing.."
  source ${ext_prop}
fi

# root_dir=`dirname $0`
mod_dir=${root_dir}'/'${module}
 
if [ ! -d $mod_dir ]
then
	echo "Module directory not available"
	exit 1
fi


cd $mod_dir

parse_env () {
	if [ -f 'env.sh' ]
	then
		source ${mod_dir}/env.sh
	else
		echo "Environment file not present for module $module"
	fi
	return 0
}

run_pre () {
	if [ -f 'pre' ]
	then
		bash ${mod_dir}/pre
		if [ $? -ne 0 ]
		then
			echo "Failed running pre script"
			exit 3
		fi
	fi	

	pre_os=${mod_dir}'/pre.'$os'.'$arch
	if [ -f $pre_os ]
	then
		bash $pre_os
		if [ $? -ne 0 ]
		then
			echo "Failed running pre script $pre_os"
			exit 3
		fi
	fi

	return 0
}

run_post () {
	if [ -f 'post' ]
	then
		bash ${mod_dir}/post
		if [ $? -ne 0 ]
		then
			echo "Failed running post script"
			exit 3
		fi
	fi	

	post_os=${mod_dir}'/post.'$os'.'$arch
	if [ -f $post_os ]
	then
		bash $post_os
		if [ $? -ne 0 ]
		then
			echo "Failed running post script $post_os"
			exit 3
		fi
	fi

	return 0
}

install_pkg () {
	package_list=$1
	if [ $os == "ubuntu1804" ] || [ $os == "ubuntu1204" ] || [ $os == "ubuntu1404" ] || [ $os == "ubuntu1604" ] 
	then
		export DEBIAN_FRONTEND=noninteractive
		echo Y | apt-get install -y $package_list
		if [ $? -ne 0 ]	
		then
			echo "Install  of $package_list failed"	
			exit 2
		fi
	elif [ $os == "suse11" ] || [ $os == "suse12" ]
	then
		zypper -n in $package_list
		if [ $? -ne 0 ]	
		then
			echo "Install  of $package_list failed"	
			exit 2
		fi
	elif [ $os == "centos5" ] || [ $os == "centos6" ]  || [ $os == "amazon" ] || [ $os == "oel6" ]  || [ $os == "centos7" ]
	then
		yum install -y $package_list
		if [ $? -ne 0 ]	
		then
			echo "Install  of $package_list failed. Trying with skip brokern option"	
			yum --skip-broken install -y $package_list
			if [ $? -ne 0 ]	
			then
				exit 2
			fi
		fi
	elif [ $os == "rhel5" ]  || [ $os == "rhel6" ]  || [ $os == "rhel7" ]  | [ $os == "rhel8" ]
	then
		yum install -y $package_list
		if [ $? -ne 0 ]	
		then
			echo "Install  of $package_list failed"	
			exit 2
		fi
	fi
	return 0	
}

	
run_main () {
	package_def='packages.list'
	if [ -f $package_def ]
	then
		while read line
		do
			install_pkg "$line" 
		done < $package_def
	fi

	package_os='packages.list.'$os'.'$arch
	if [ -f $package_os  ]
	then
	echo "Installing $line"
		while read line
		do
			install_pkg "$line" 
		done < $package_os
	fi
	
	return 0
}

parse_env
run_pre
run_main
run_post

exit 0
