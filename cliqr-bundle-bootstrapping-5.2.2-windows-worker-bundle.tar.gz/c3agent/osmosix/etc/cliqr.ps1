#########################################################################
#	CliQr Powershell Base Script
#
#	Copyright(c) 2012 CliQr Technologies, Inc., all rights reservced.
#########################################################################

#Last modified: July 4, 2019
$SYSTEM_DRIVE = (Get-WmiObject Win32_OperatingSystem).SystemDrive
$OSMOSIX_CONF_HOME = 'C:\Program Files\osmosix\etc'
$OSMOSIX_LOGS_HOME = 'C:\Program Files\osmosix\logs'
$OSMOSIX_CLOUD_FILE = "$OSMOSIX_CONF_HOME\cloud"
$OSMOSIX_REGION_FILE = "$OSMOSIX_CONF_HOME\region"
$OSMOSIX_COMPONENT_FILE = "$OSMOSIX_CONF_HOME\component"
$OSMOSIX_BUILD_TYPE_FILE = "$OSMOSIX_CONF_HOME\buildtype"
$OSMOSIX_POWERSHELL_LOG = "$OSMOSIX_LOGS_HOME\service.log"

$OSMOSIX_COMPONENT = (cat $OSMOSIX_COMPONENT_FILE)
$OSMOSIX_CLOUD = (cat $OSMOSIX_CLOUD_FILE).ToLower()
$OSMOSIX_REGION = (cat $OSMOSIX_REGION_FILE)

$OSMOSIX_BUILD_TYPE = ""
if ((Test-Path($OSMOSIX_BUILD_TYPE_FILE))) {
    $OSMOSIX_BUILD_TYPE = (cat $OSMOSIX_BUILD_TYPE_FILE)
}

$OSMOSIX_SYS_DRIVE = "C"
$OSMOSIX_NFS_DRIVE = "X"

function Log-Write {
    param ([string]$logstring)
    Add-content $OSMOSIX_POWERSHELL_LOG -value "[$(Get-Date)] $logstring"
}

#hostid file used by : C:\Program Files\nodejs\node_modules\cliqrmds\bin\meta.js
$OSMOSIX_HOSTID_FILE = "C:\Program Files\osmosix\etc\hostid"
if(!(Test-Path($OSMOSIX_HOSTID_FILE))) {
    Log-Write "$OSMOSIX_HOSTID_FILE file does not exist. Populate it using the output of the 'hostname' command"
    hostname >> $OSMOSIX_HOSTID_FILE
}else{
    Log-Write "$OSMOSIX_HOSTID_FILE exists. Will not be populated again with hostid from 'hostname' command"
}
$hostid = (cat $OSMOSIX_HOSTID_FILE)
Log-Write "Hostname of the Node in $OSMOSIX_HOSTID_FILE : $hostid"

if (!(Test-Path($OSMOSIX_LOGS_HOME))) {
    New-Item -Path $OSMOSIX_LOGS_HOME -ItemType directory
}

$OSMOSIX_PACKAGE_DIR = "C:\temp\remoteFiles\appPackage"

##############################
# ZIP Utility Alias
##############################
function Expand-ZIPFile($file, $destination)
{
    Log-Write("Extract ZIP file: $file to $destination...")
    $ZipCommand = "C:\opt\zip\ccc_unarchiver.exe"
    $AltZipCommand = "C:\Program Files\c3agent\osmosix\bin\ccc_unarchiver.exe"
    if(!(Test-Path($ZipCommand))) {
        Log-Write "Unarchiver utility does not exist: $ZipCommand. Use alternate unarchiver utility if it exists: $AltZipCommand"
        $ZipCommand = $AltZipCommand
        if(!(Test-Path($ZipCommand))){
            Log-Write "ERROR: Fallback location for Unarchiver utility also does not exist: $ZipCommand. Skipping extraction of ZIP archive..."
            return
        }else{
            Log-Write "Unarchiver utility to use in this setup: $ZipCommand"
        }
    }else{
        Log-Write "Unarchiver utility to use in this setup: $ZipCommand"
    }
    & $ZipCommand unzip -s $file -t $destination
}

function Expand-TARFile($file, $destination)
{
    Log-Write("Extract TAR/TGZ file: $file to $destination...")
    $ZipCommand = "C:\opt\zip\ccc_unarchiver.exe"
    $AltZipCommand = "C:\Program Files\c3agent\osmosix\bin\ccc_unarchiver.exe"
    if(!(Test-Path($ZipCommand))) {
        Log-Write "Unarchiver utility does not exist: $ZipCommand. Use alternate unarchiver utility if it exists: $AltZipCommand"
        $ZipCommand = $AltZipCommand
        if(!(Test-Path($ZipCommand))){
            Log-Write "ERROR: Fallback location for Unarchiver utility also does not exist: $ZipCommand. Skipping extraction of TAR/TGZ archive..."
            return
        }else{
            Log-Write "Unarchiver utility to use in this setup: $ZipCommand"
        }
    }else{
        Log-Write "Unarchiver utility to use in this setup: $ZipCommand"
    }
    & $ZipCommand untar -s $file -t $destination
}

##############################
# Helper Functions
##############################


function Initialize-Disk {
    param([int]$diskId = 2, [string]$driveLetter="F")
    
    $dpConfig = @"
select disk $diskId
attributes disk clear readonly
online disk
create partition primary
active
format fs=ntfs label="CliQr Data Disk" quick
assign letter=$driveLetter
"@
    
    $dpConfig | diskpart
}

function Write-EventLog {
    param([string]$msg = "Default Message", [string]$type="Information")
    if (![System.Diagnostics.EventLog]::SourceExists("CliQrAgentService")) {
        [System.Diagnostics.EventLog]::CreateEventSOurce("CliQrAgentService","Application")
    }
    
    $log = New-Object System.Diagnostics.EventLog;
    $log.set_log("Application");
    $log.set_source("CliQrAgentService");
    $log.WriteEntry($msg,$type);
    #echo "debug>$msg"
} 

function Unzip-File {
        param (
                [string] $ZipFile = $(throw "ZipFile must be specified."),
                [string] $OutputDir = $(throw "OutputDir must be specified.")
        )
         
        if (!(Test-Path($ZipFile))) {
                throw "Zip filename does not exist: $ZipFile"
                return
        }
         
        Expand-ZIPFile -File $ZipFile -Destination $OutputDir
         
        if (!$?) {
                throw "ccc_unarchiver returned an error unzipping the file."
        }
}

function Untar-File {
        param (
                [string] $TarBallFile = $(throw "TarBallFile must be specified."),
                [string] $OutputDir = $(throw "OutputDir must be specified.")
        )
         
        if (!(Test-Path($TarBallFile))) {
                throw "Tar ball filename does not exist: $TarBallFile"
                return
        }

		if ($TarBallFile.EndsWith('.gz')) {
	       Expand-TARFile -File $TarBallFile -Destination $OutputDir
			Remove-Item $TarBallFile
	    } else {
	       Expand-TARFile -File $TarBallFile -Destination $OutputDir
        }
}

function Get-FireWallRule
{
	Param (
		$name, 
		$direction, 
		$enabled, 
		$protocol, 
		$profile, 
		$action, 
		$grouping
	)
	$Rules=(New-object -comObject HNetCfg.FwPolicy2).rules
	If ($name)      {$rules= $rules | where-object {$_.name     -like $name}}
	If ($direction) {$rules= $rules | where-object {$_.direction  -eq $direction}}
	If ($enabled)   {$rules= $rules | where-object {$_.Enabled    -eq $enabled}}
	If ($protocol)  {$rules= $rules | where-object {$_.protocol  -eq  $protocol}}
	If ($profile)   {$rules= $rules | where-object {$_.Profiles -bAND $profile}}
	If ($Action)    {$rules= $rules | where-object {$_.Action     -eq $Action}}
	If ($Grouping)  {$rules= $rules | where-object {$_.Grouping -Like $Grouping}}
	$rules
}

function Add-FirewallRule {
   param( 
      $name,
      $tcpPorts,
      $appName = $null,
      $serviceName = $null
   )
    $fw = New-Object -ComObject hnetcfg.fwpolicy2 
    $rule = New-Object -ComObject HNetCfg.FWRule
        
    $rule.Name = $name
    if ($appName -ne $null) { $rule.ApplicationName = $appName }
    if ($serviceName -ne $null) { $rule.serviceName = $serviceName }
    $rule.Protocol = 6 #NET_FW_IP_PROTOCOL_TCP
    $rule.LocalPorts = $tcpPorts
    $rule.Enabled = $true
    $rule.Grouping = "@firewallapi.dll,-23255"
    $rule.Profiles = 7 # all
    $rule.Action = 1 # NET_FW_ACTION_ALLOW
    $rule.EdgeTraversal = $false
    
    $fw.Rules.Add($rule)
}

function Add-FirewallPortRule {
   	param( 
    	$name,
      	$protocol,
		$ports,
		$src
   	)
    $FwMgr = New-Object -ComObject HNetCfg.FwMgr
    $FwProfile = $FwMgr.LocalPolicy.CurrentProfile
	
	$rule = New-Object -ComObject HNetCfg.FwOpenPort
    $rule.Name = $name
	switch($Protocol) {
		"tcp" { $rule.Protocol = 6; break }
		"udp" { $rule.Protocol = 17; break }
		"default" { return }
	}
    
    $rule.Port = $ports
    $rule.RemoteAddresses = $src
    $rule.Enabled = $true
	$FwProfile.GloballyOpenPorts.Add($rule)
}

$vmvar = "C:\Program Files\osmosix\bin\vmvar.cmd"
Set-Alias vmvar $vmvar

function Get-VM-Property {
	param (
		[string]$key
	)
	$value = (vmvar $key) 
	$value = $value -replace "`n|`r",""
	return $value
}

function Set-IPAddress {
	param (
		[string]$interfaceName,
		[string]$ipAddr,
		[string]$netmask,
		[string]$gateway
	)
	
	if ($ipAddr -and $netmask) {
		$cmd = "netsh interface ip set address ""$interfaceName"" static $ipAddr $netmask"
		if ($gateway) {
			$cmd = $cmd + " $gateway 1"
		}
        	Log-Write "Configuring interface $interfaceName : $cmd"
		Invoke-Expression $cmd
	}
}

#Compatible method for Powershell V2.0 since only V3.0 has isNullOrWhiteSpace method for String
function StringIsNullOrWhitespace([string] $string)
{
    if ($string -ne $null) {
        $string = $string.Trim()
    }
    return [string]::IsNullOrEmpty($string)
}


############################################################
# Main entry
############################################################

$webclient = New-Object System.Net.WebClient

if (!$OSMOSIX_CLOUD.CompareTo("amazon")) {
    $OSMOSIX_EDISK_DRIVE = "C"
    $OSMOSIX_PDISK_DRIVE = "D"
	$OSMOSIX_PDISK_ID = "1"
} elseif (!$OSMOSIX_CLOUD.CompareTo("azure")) {
    $OSMOSIX_EDISK_DRIVE = "D"
    $OSMOSIX_PDISK_DRIVE = "F"
	$OSMOSIX_PDISK_ID = "2"
} elseif (!$OSMOSIX_CLOUD.CompareTo("azurerm")) {
    $OSMOSIX_EDISK_DRIVE = "D"
    $OSMOSIX_PDISK_DRIVE = "F"
	$OSMOSIX_PDISK_ID = "2"
} elseif (!$OSMOSIX_CLOUD.CompareTo("azurestack")) {
    $OSMOSIX_EDISK_DRIVE = "D"
    $OSMOSIX_PDISK_DRIVE = "F"
	$OSMOSIX_PDISK_ID = "2"
} elseif (!$OSMOSIX_CLOUD.CompareTo("hp")) {
    $OSMOSIX_EDISK_DRIVE = "C"
    $OSMOSIX_PDISK_DRIVE = "F"
	$OSMOSIX_PDISK_ID = "2"
} elseif (!$OSMOSIX_CLOUD.CompareTo("hpcloud")) {
    $OSMOSIX_EDISK_DRIVE = "C"
    $OSMOSIX_PDISK_DRIVE = "F"
    $OSMOSIX_PDISK_ID = "2"
} elseif (!$OSMOSIX_CLOUD.CompareTo("openstack")) {
    $OSMOSIX_EDISK_DRIVE = "C"
    $OSMOSIX_PDISK_DRIVE = "F"
    $OSMOSIX_PDISK_ID = "2"
} elseif (!$OSMOSIX_CLOUD.CompareTo("sce")) {
    $OSMOSIX_EDISK_DRIVE = "C"
    $OSMOSIX_PDISK_DRIVE = "D"
	$OSMOSIX_PDISK_ID = "1"
} elseif (!$OSMOSIX_CLOUD.CompareTo("rackspace2")) {
    $OSMOSIX_EDISK_DRIVE = "C"
    $OSMOSIX_PDISK_DRIVE = "D"
    $OSMOSIX_PDISK_ID = "2"
} elseif (!$OSMOSIX_CLOUD.CompareTo("opsource")) {
    $OSMOSIX_EDISK_DRIVE = "C"
    $OSMOSIX_PDISK_DRIVE = "D"
    $OSMOSIX_PDISK_ID = "2"
} elseif (!$OSMOSIX_CLOUD.CompareTo("vmware")) {
    $OSMOSIX_EDISK_DRIVE = "D"
    $OSMOSIX_PDISK_DRIVE = "E"
    $OSMOSIX_PDISK_ID = "2"
} elseif (!$OSMOSIX_CLOUD.CompareTo("vcd")) {
    $OSMOSIX_EDISK_DRIVE = "D"
    $OSMOSIX_PDISK_DRIVE = "E"
    $OSMOSIX_PDISK_ID = "2"
} elseif (!$OSMOSIX_CLOUD.CompareTo("softlayer")) {
    $OSMOSIX_EDISK_DRIVE = "C"
    $OSMOSIX_PDISK_DRIVE = "F"
    $OSMOSIX_PDISK_ID = "3"
} elseif (!$OSMOSIX_CLOUD.CompareTo("google")) {
    $OSMOSIX_EDISK_DRIVE = "C"
    $OSMOSIX_PDISK_DRIVE = "D"
    $OSMOSIX_PDISK_ID = "1"
} else {
    $OSMOSIX_EDISK_DRIVE = "D"
    $OSMOSIX_PDISK_DRIVE = "E"
	$OSMOSIX_PDISK_ID = "2"
}

$metadataCommand = "C:\temp\ccc_node-metadata.exe"
$altMetadataCommand = "C:\opt\ccc_node-metadata.exe"
if(!(Test-Path($metadataCommand))) {
    Log-Write "Node Metadata utility does not exist: $metadataCommand. Use alternate utility if it exists: $altMetadataCommand"
    $metadataCommand = $altMetadataCommand
    if(!(Test-Path($metadataCommand))){
        Log-Write "ERROR: Fallback location for Node Metadata utility also does not exist: $metadataCommand."
    }else{
        Log-Write "Node Metadata utility to use in this setup: $metadataCommand"
    }
}else{
    Log-Write "Node Metadata utility to use in this setup: $metadataCommand"
}

function getMetadata{
    param ([string]$command)
    $result = & $metadataCommand -command $command
    return $result
}

if (!$OSMOSIX_CLOUD.CompareTo("custom")) {
    Log-Write "Worker cloud type: custom"
    $AGENT_INSTALLED_FILE = "{0}\AGENTINSTALLED" -f $OSMOSIX_CONF_HOME
    if (Test-Path $AGENT_INSTALLED_FILE) {
        $OSMOSIX_SYSTEM_DATA = getMetadata "user-data"
        Log-Write "Agent already installed. Skipping metadata and userdata extraction for the custom worker of custom cloud type"
    }else{
        Log-Write "Agent is not installed"

        $METADATA_OUT_FILE = "C:\temp\metadata.out"
        if (Test-Path $METADATA_OUT_FILE){
            $OSMOSIX_SYSTEM_DATA = getMetadata "user-data"
            Log-Write "$METADATA_OUT_FILE is present indicating bootstrap might already be in progress. Skip metadata/userdata extraction"
        }else{
            Log-Write "Extracting metadata and userdata for the custom worker of custom cloud type"
            $PROGRAM_FILES_PATH = "$SYSTEM_DRIVE\Program Files"
            $METADATA_EXTRACTOR = "$PROGRAM_FILES_PATH\metadata_extractor.ps1"
            $USERDATA_EXTRACTOR = "$PROGRAM_FILES_PATH\userdata_extractor.ps1"
            $RAW_USERDATA = "C:\Temp\raw_userdata.ps1"

            . $METADATA_EXTRACTOR
            . $USERDATA_EXTRACTOR

            if (Test-Path $RAW_USERDATA) {
                Log-Write "Executed $USERDATA_EXTRACTOR to create $RAW_USERDATA. Executing $RAW_USERDATA..."
                . $RAW_USERDATA

                $OSMOSIX_USERDATA_FILE="$OSMOSIX_CONF_HOME\user-data"
                if (Test-Path $OSMOSIX_USERDATA_FILE) {
                    Log-Write "Executed $RAW_USERDATA to create $OSMOSIX_USERDATA_FILE"
                    $OSMOSIX_SYSTEM_DATA = getMetadata "user-data"
                    Log-Write "User Data found: $OSMOSIX_SYSTEM_DATA"
                }else {
                    Log-Write "Executed $RAW_USERDATA but failed to create $OSMOSIX_USERDATA_FILE"
                }
            } else {
                Log-Write "Executed $USERDATA_EXTRACTOR but failed to create $RAW_USERDATA"
            }
        }
    }
} else { 
    while ($true) {
        Try {
            $OSMOSIX_PRIVATE_IP = getMetadata "private-ip"
            $OSMOSIX_PUBLIC_IP =  getMetadata "public-ip"
            $OSMOSIX_SYSTEM_DATA = getMetadata "user-data"
            if ($OSMOSIX_SYSTEM_DATA.length -ne 0) {
                break
            }
        } Catch {
            Log-Write "Failed to acquire user data: $_.Exception.Message"
        }

        if (!$OSMOSIX_CLOUD.CompareTo("vmware")) {
            Start-Service -displayname 'CliQr MDS'
        }

        sleep 10
    }
}

#For old images, set it to False
Try {
	$OSMOSIX_CREDENTIAL_REQUIRED = [System.Convert]::ToBoolean($webclient.DownloadString('http://localhost:5810/cloud-node-metadata/credential/required'))

	if ($OSMOSIX_CREDENTIAL_REQUIRED) {
	    $OSMOSIX_BOOTSTRAP_USERNAME = $webclient.DownloadString('http://localhost:5810/cloud-node-metadata/credential/bootstrap-username')
		$OSMOSIX_BOOTSTRAP_PASSWORD = $webclient.DownloadString('http://localhost:5810/cloud-node-metadata/credential/bootstrap-password')
	}
} Catch {
	$OSMOSIX_CREDENTIAL_REQUIRED = $False
}

# export all environment variables
[Environment]::SetEnvironmentVariable('OSMOSIX_EDISK_DRIVE', $OSMOSIX_EDISK_DRIVE, 'Machine')
[Environment]::SetEnvironmentVariable('OSMOSIX_PDISK_DRIVE', $OSMOSIX_PDISK_DRIVE, 'Machine')
[Environment]::SetEnvironmentVariable('OSMOSIX_PDISK_ID', $OSMOSIX_PDISK_ID, 'Machine')
[Environment]::SetEnvironmentVariable('OSMOSIX_USER_DATA', $OSMOSIX_USER_DATA, 'Machine')
[Environment]::SetEnvironmentVariable('OSMOSIX_PRIVATE_IP', $OSMOSIX_PRIVATE_IP, 'Machine')
[Environment]::SetEnvironmentVariable('OSMOSIX_PUBLIC_IP', $OSMOSIX_PUBLIC_IP, 'Machine')
[Environment]::SetEnvironmentVariable('OSMOSIX_CREDENTIAL_REQUIRED', $OSMOSIX_CREDENTIAL_REQUIRED, 'Machine')

if ($OSMOSIX_CREDENTIAL_REQUIRED) {
	[Environment]::SetEnvironmentVariable('OSMOSIX_BOOTSTRAP_USERNAME', $OSMOSIX_BOOTSTRAP_USERNAME, 'Machine')
	[Environment]::SetEnvironmentVariable('OSMOSIX_BOOTSTRAP_PASSWORD', $OSMOSIX_BOOTSTRAP_PASSWORD, 'Machine')
} else {
    $bundleStoreCredentialFile = "c:\temp\bundleStoreCredential"
    if (Test-Path $bundleStoreCredentialFile) {
        $bundleStoreCredential = Get-Content $bundleStoreCredentialFile
        [Reflection.Assembly]::LoadFile("C:\Program Files\osmosix\lib\Newtonsoft.Json.dll")
        $json = [Newtonsoft.Json.Linq.JObject]::Parse($bundleStoreCredential)
        $OSMOSIX_BOOTSTRAP_USERNAME = $json.Item("bundleStoreUser").ToString()
        $OSMOSIX_BOOTSTRAP_PASSWORD = $json.Item("bundleStorePassword").ToString()
        $OSMOSIX_CREDENTIAL_REQUIRED = $true
        [Environment]::SetEnvironmentVariable('OSMOSIX_BOOTSTRAP_USERNAME', $OSMOSIX_BOOTSTRAP_USERNAME, 'Machine')
        [Environment]::SetEnvironmentVariable('OSMOSIX_BOOTSTRAP_PASSWORD', $OSMOSIX_BOOTSTRAP_PASSWORD, 'Machine')
        [Environment]::SetEnvironmentVariable('OSMOSIX_CREDENTIAL_REQUIRED', $OSMOSIX_CREDENTIAL_REQUIRED, 'Machine')
    }
}
