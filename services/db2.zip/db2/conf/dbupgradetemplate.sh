db2 connect to %cliqrDatabaseName% user db2inst1 using %cliqrDatabaseRootPass%
db2 -tvf %cliqrDBSetupScript%