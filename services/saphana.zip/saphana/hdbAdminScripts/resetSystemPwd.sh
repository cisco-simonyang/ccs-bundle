. /usr/local/osmosix/etc/userenv
. /usr/local/osmosix/service/utils/cfgutil.sh

SAPHANA_CONF="/usr/local/osmosix/service/saphana/conf"
RESET_PWD_SQL_FILE="$SAPHANA_CONF/resetpwd.sql"
USER_ENV="/usr/local/osmosix/etc/userenv";
CLIQR_DB_ROOT_PASS_ENV_VAR="cliqrDatabaseRootPass";
RESET_INDICATOR="/mnt/data/hdb/.resetIndicator";

log() {
	logger -t "OSMOSIX" "[$SVCNAME] $*"
}

replaceToken $RESET_PWD_SQL_FILE "%PASSWD%" $cliqrDatabaseRootPass
  
if `hdbsql -n localhost:30015 -u system -p manager -c ";" -I $RESET_PWD_SQL_FILE`
   then
   log "Successfully reset the root password.";
   if `touch $RESET_INDICATOR`
   then
     log "Successfully created the password reset indicator.";
   else
     log "Error occurred while creating password reset indicator";
   fi
 else
   log "Failed to reset the root password";
   replaceToken $RESET_PWD_SQL_FILE $cliqrDatabaseRootPass %PASSWD%
   exit 127;
fi