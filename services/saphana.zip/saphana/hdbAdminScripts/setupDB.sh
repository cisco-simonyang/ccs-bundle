. /usr/local/osmosix/etc/userenv
. /usr/local/osmosix/service/utils/cfgutil.sh

log() {
	logger -t "OSMOSIX" "[$SVCNAME] $*"
}


USER_ENV="/usr/local/osmosix/etc/userenv";
CLIQR_DB_ROOT_PASS_ENV_VAR="cliqrDatabaseRootPass";
DB_INIT_INDICATOR="/mnt/data/hdb/.dbInitIndicator";


rootPasswd="";

 if [ -z $cliqrDatabaseRootPass ];
 then
   rootPasswd="manager";
 else
   rootPasswd=$cliqrDatabaseRootPass;
 fi

  if `hdbsql -n localhost:30015 -u system -p $rootPasswd -c ";" -I $cliqrDBSetupScript`
  then
    log "Successfully executed the DB Setup script.";
    if `touch $DB_INIT_INDICATOR`
    then
      log "Successfully created the DB Setup indicator";
    else
      log "Error occurred while creating DB Setup indicator";
    fi
  else
   log "Error occurred while running the DB Setup script.";
   exit 127;
 fi
