#!/bin/bash
DOCKER_SVCNAME=nginx
OSSVC_HOME=/usr/local/osmosix/service

. $OSSVC_HOME/utils/docker_util.sh
. $OSSVC_HOME/utils/nosqlutil.sh
. $OSSVC_HOME/utils/cfgutil.sh

DOCKER_IMAGE_NAME=`getDockerImageName $DOCKER_SVCNAME`

installNginxDocker(){
    loadDockerImage $DOCKER_IMAGE_NAME
}

generateNginxDockerConfig() {
    log "[CONFIGURATION] Generating NGINX config file"

    #create the mount point of configration file for docker host
    mkdir -p /etc/nginx/
    cd /etc/nginx/

    log "[CONFIGURATION] Adding directories sites-available and sites-enabled"
    mkdir sites-available sites-enabled

    if [ ! -f /etc/nginx/nginx.conf ]; then
        cp $SVCHOME/nginx.conf /etc/nginx/nginx.conf
    fi

    grep -q -e "^[[:space:]]*include \/etc\/nginx\/sites-enabled\/\*" nginx.conf || sed -i "s/\/etc\/nginx\/conf.d\/\*\.conf;/\/etc\/nginx\/sites-enabled\/\*;/" nginx.conf

    NGINX_CFG="/etc/nginx/sites-available/default"

    cp $SVCHOME/sites-available/default $NGINX_CFG

    ln -s /etc/nginx/sites-available/default /etc/nginx/sites-enabled/default

    log "SVNNAME: $DOCKER_SVCNAME"

    if [ ! -z $CliqrDependencies ]; then
        expandListOfServers $NGINX_CFG $CliqrDependencies
    else
        if [ ! -z $CliqrTier_AppCluster_IP ]; then
                  expandServerList $NGINX_CFG "$CliqrTier_AppCluster_IP"
        elif [ ! -z $CliqrTier_WebServer_IP ]; then
                  expandServerList $NGINX_CFG "$CliqrTier_WebServer_IP"
        fi
     fi


    if [ "$cliqrExternalHttpEnabled" == 1 ]; then

#		httpPortToListen=$(getNextAvailablePort "$(($StartingPort + 1000))" )
#		echo "[DEBUG] - Next available port $httpPortToListen"
        replaceToken $NGINX_CFG "%UN_PRIV_HTTP_PORT%" 80
        uncommentConfig $NGINX_CFG "#HTTP_ENABLED"
#		replaceToken $FIREWALL_RULES "%UN_PRIV_HTTP_PORT%" $httpPortToListen
#		uncommentConfig $FIREWALL_RULES "#HTTP_REDIRECT"
        log "[LISTENING PORT] - Listening on external HTTP port 80"
    fi

    if [ "$cliqrExternalHttpsEnabled" == 1 ]; then
       if [ -r "$cliqrSSLCert" -a -f "$cliqrSSLCert" -a -r "$cliqrSSLKey"  -a -f "$cliqrSSLKey" ];
       then
#	        httpsPortToListen=$(getNextAvailablePort "$(($StartingPort + 2000))" )
#			echo "[DEBUG] - Next available port $httpsPortToListen"
            replaceToken $NGINX_CFG "%UN_PRIV_HTTPS_PORT%" 443
            replaceToken $NGINX_CFG "%SSL_CERT%" $cliqrSSLCert
            replaceToken $NGINX_CFG "%SSL_KEY%" $cliqrSSLKey
            uncommentConfig $NGINX_CFG "#HTTPS_ENABLED"
#			replaceToken $FIREWALL_RULES "%UN_PRIV_HTTPS_PORT%" $httpsPortToListen
#			uncommentConfig $FIREWALL_RULES "#HTTPS_REDIRECT"
            log "[LISTENING PORT] - Listening on external HTTP port 80"
       else
            log "[CONFIGURATION] HTTPS is enabled but certificates are missing or unreadable"
       fi
    fi

    if [ "$cliqrForceHttpRedirect" == 1 ]; then
        uncommentConfig $NGINX_CFG "#FORCE_HTTP_REDIRECT"
        log "[REDIRECT] Forcing HTTPS redirect"
    fi

    log "[CONFIGURATION] Successfully updated the NGINX config file"

}

startNginxDockerService(){
    removeDockerContainer $DOCKER_SVCNAME
    docker run -d --name=$DOCKER_SVCNAME -v /etc/nginx/sites-enabled:/etc/nginx/sites-enabled \
                               -v /etc/nginx/sites-available:/etc/nginx/sites-available \
                               -v /etc/nginx/nginx.conf:/etc/nginx/nginx.conf \
                               -p 80:80 -p 443:443 $DOCKER_IMAGE_NAME;
}
stopNginxDockerService(){
    docker stop $DOCKER_SVCNAME
    docker rm -f $DOCKER_SVCNAME
}
reloadNginxDockerService(){
    docker exec nginx nginx -s reload
}
