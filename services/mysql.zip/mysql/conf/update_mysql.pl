#!/usr/bin/perl

if (-e "/etc/init/mysql.conf") {
    $mysql_file	= "/etc/init/mysql.conf";
    $tmp_conf	= "/tmp/mysql.conf.tmp";
    
    $startup	= "";
    
    open(CONF,"<",$mysql_file) or die "Cannot open $mysql_file : ";
    open(TMPCONF,">",$tmp_conf) or die "Cannot open $tmp_conf file : ";
    
    while($line = <CONF> ) {
    	if ( $line =~ m/^start on/ )  {
    		print TMPCONF "# $line";
    		while ( $line = <CONF> ) {
    			if ( $line =~ m/^stop on/ ) {
    				last;
    			}
    			print TMPCONF "# $line";
    		}
    	}
    	print TMPCONF $line;
    }
    close(CONF);
    close(TMPCONF);
    
    rename ( $tmp_conf,$mysql_file) or die "Cannot move tmp config file to mysql file";
}else {
    print "File : /etc/init/mysql.conf does not exist. Skipping changes to this configuration file.";
}

exit 0;
