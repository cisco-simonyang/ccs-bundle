UPDATE mysql.user SET Password=PASSWORD('cliqrtech') WHERE User='root';
FLUSH PRIVILEGES;
exit;
