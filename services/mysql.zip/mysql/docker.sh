#!/bin/bash

DOCKER_SVCNAME=mysql
ROOT_PWD_DEFAULT='cliqrtech'
HOST_DATA_VOLUME='/data/mysql'
CONTAINER_DATA_VOLUME='/var/lib/mysql'
INIT_SQL_DIR='/sqlinit'
CONTAINER_INIT_SQL_DIR='/docker-entrypoint-initdb.d/'

DB_INIT_INDICATOR="/data/mysql/.dbInitIndicator"

DOCKER_IMAGE_NAME=`getDockerImageName $DOCKER_SVCNAME`

installMySQLDocker() {
    loadDockerImage $DOCKER_IMAGE_NAME
}


startMysqlDockerService() {
    removeDockerContainer $DOCKER_SVCNAME
    docker ps | grep mysql
    if [ $? -eq 0 ]; then
        log "mysql docker service already started."
        return
    fi

    #set root password
    rootPWD=$ROOT_PWD_DEFAULT
    if [ -z $cliqrDatabaseRootPass ]; then
        log "No root password provided, use default: cliqrtech."
    else
        rootPWD=$cliqrDatabaseRootPass
    fi

    #set initialize sql file if exist
    mkdir -p $INIT_SQL_DIR

    if [ ! -f $DB_INIT_INDICATOR ]; then
        if [ ! -z $cliqrDBSetupScript ]; then
            log "use db init script: $cliqrDBSetupScript"
            cp $cliqrDBSetupScript $INIT_SQL_DIR
        fi
    else
        log "db initialized, do not use db init script: $cliqrDBSetupScript"
        rm -f $INIT_SQL_DIR/*
    fi

    cmd="docker run -d -p 3306:3306 -e MYSQL_ROOT_PASSWORD=$rootPWD"
    cmd="$cmd -v $INIT_SQL_DIR:$CONTAINER_INIT_SQL_DIR "
    cmd="$cmd -v $HOST_DATA_VOLUME:$CONTAINER_DATA_VOLUME "
    cmd="$cmd --name $DOCKER_SVCNAME $DOCKER_IMAGE_NAME"

    log "running command: $cmd"

    result=$($cmd 2>&1)

    if [ $? -eq 0 ]; then
        touch $DB_INIT_INDICATOR
        log "container started successfully. "
    else
        log "container start failed. "
    fi
    log $result

    log "sleep 10 seconds for mysql to complete init"
    sleep 10
}

stopMysqlDockerService() {
    docker stop $DOCKER_SVCNAME
    log "remove mysql docker container"
    docker rm -f $DOCKER_SVCNAME
}

restartMysqlDockerService() {
    stopMysqlDockerService
    startMysqlDockerService
}

upgradeMysqlDockerService() {
    rm $DB_INIT_INDICATOR
    restartMysqlDockerService
}

