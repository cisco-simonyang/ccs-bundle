#########################################################################
#	Powershell Service Script
#
#	Supported services:
#		- SQL Server 2012
#
#	Copyright(c) 2012 CliQr Technologies, Inc., all rights reserved.
#########################################################################

. 'c:\Program Files\osmosix\etc\cliqr.ps1'

$CLIQR_SQL_CONNECTION_TIMEOUT = 30
$CLIQR_DEFAULT_DB_PATH = "{0}:\MSSQL" -f $OSMOSIX_PDISK_DRIVE
$CLIQR_DEFAULT_DOTNET_VERSION = '4.0'
$CLIQR_DEFAULT_SQLEXPRESS_DB_PATH = 'C:\Program Files\Microsoft SQL Server\MSSQL11.SQLEXPRESS\MSSQL\DATA'
$CLIQR_SQL_INSTANCE = 'localhost'
$CLIQR_SQL_SERVICE_NAME = 'MSSQLSERVER'
$CLIQR_DEFAULT_SQL_PASS = 'ca$hc0w'
$CLIQR_DEFAULT_CONFIG_FILE_TYPES = '*.xml,*.conf'
$FIRSTRUN = $true
$STARTED_FLAG_FILE = 'c:\temp\started'
$CLIQR_DEFAULT_DB_CONFIG = 'config.xml'
$DBNODENAME = 'dbnode'

###################################
# SQLSERVER 2012 Service Routines
###################################
function init_sqlps2012_env {
    $ErrorActionPreference = "Stop"
    if ( Test-Path "HKLM:\SOFTWARE\Microsoft\PowerShell\1\ShellIds\Microsoft.SqlServer.Management.PowerShell.sqlps110" ) {  
	$sqlpsreg="HKLM:\SOFTWARE\Microsoft\PowerShell\1\ShellIds\Microsoft.SqlServer.Management.PowerShell.sqlps110" 
    } 
    else { 
	$sqlpsreg="HKLM:\SOFTWARE\Microsoft\PowerShell\1\ShellIds\Microsoft.SqlServer.Management.PowerShell.sqlps120" 
     }
    if (Get-ChildItem $sqlpsreg -ErrorAction "SilentlyContinue") {
        throw "SQL Server Powershell is not installed."
    }
    else {
        $item = Get-ItemProperty $sqlpsreg
        $sqlpsPath = [System.IO.Path]::GetDirectoryName($item.Path)
    }

    $assemblylist =
    "Microsoft.SqlServer.Smo",
    "Microsoft.SqlServer.Dmf ",
    "Microsoft.SqlServer.SqlWmiManagement ",
    "Microsoft.SqlServer.ConnectionInfo ",
    "Microsoft.SqlServer.SmoExtended ",
    "Microsoft.SqlServer.Management.RegisteredServers ",
    "Microsoft.SqlServer.Management.Sdk.Sfc ",
    "Microsoft.SqlServer.SqlEnum ",
    "Microsoft.SqlServer.RegSvrEnum ",
    "Microsoft.SqlServer.WmiEnum ",
    "Microsoft.SqlServer.ServiceBrokerEnum ",
    "Microsoft.SqlServer.ConnectionInfoExtended ",
    "Microsoft.SqlServer.Management.Collector ",
    "Microsoft.SqlServer.Management.CollectorEnum"

    foreach ($asm in $assemblylist) {
        $asm = [Reflection.Assembly]::LoadWithPartialName($asm)
    }

    # Set variables that the provider expects (mandatory for the SQL provider)
    Set-Variable -scope Global -name SqlServerMaximumChildItems -Value 0
    Set-Variable -scope Global -name SqlServerConnectionTimeout -Value 30
    Set-Variable -scope Global -name SqlServerIncludeSystemObjects -Value $false
    Set-Variable -scope Global -name SqlServerMaximumTabCompletion -Value 1000

    # Load the snapins, type data, format data
    Push-Location
    cd $sqlpsPath
}

function mssql_reset_password {
    if (!$ENV:cliqrDatabaseRootPass -or ($ENV:cliqrDatabaseRootPass -ceq $CLIQR_DEFAULT_SQL_PASS)) {
        return
    }
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
    $sql = new-object('Microsoft.SqlServer.Management.Smo.Server') "$CLIQR_SQL_INSTANCE"
    $sql.ConnectionContext.LoginSecure = $false
    $sql.ConnectionContext.set_login('sa')
    $oldPass = ConvertTo-SecureString $CLIQR_DEFAULT_SQL_PASS -AsPlainText -Force
    $sql.ConnectionContext.set_SecurePassword($oldPass)
    $user = $sql.Logins | ? {$_.Name -eq "sa"}
    $user.ChangePassword($ENV:cliqrDatabaseRootPass)
}

function mssql_attach_db {
	Log-Write "Processing attach DB files $ENV:cliqrSqlAttachDBZip"

	Try {
		if ($ENV:cliqrSQLExpressMode) {
			$dbPath = $CLIQR_DEFAULT_SQLEXPRESS_DB_PATH
		} else {
			if ($ENV:cliqrSqlDBPath) {
		        $dbPath = $ENV:cliqrSqlDBPath
		    } else {
		        $dbPath = $CLIQR_DEFAULT_DB_PATH
		    }

		    if (!(Test-Path $dbPath)) {
				mkdir $dbPath
		    }
		}

		if ($FIRSTRUN) {
			Unzip-File $ENV:cliqrSqlAttachDBZip $dbPath
		}

	    $s = new-object ('Microsoft.SqlServer.Management.Smo.Server') "$CLIQR_SQL_INSTANCE"
	    $s.ConnectionContext.LoginSecure = $false
	    $s.ConnectionContext.set_login('sa')
	    $passwd = ConvertTo-SecureString $ENV:cliqrDatabaseRootPass -AsPlainText -Force
	    $s.ConnectionContext.set_SecurePassword($passwd)

		$DB_CONFIG = "{0}\{1}" -f $dbPath, $CLIQR_DEFAULT_DB_CONFIG
		if (Test-Path $DB_CONFIG) {
			Log-Write "Database config file found"
			$dbxml = [xml](get-content $DB_CONFIG)
			foreach ($db in $dbxml.config.databases.database) {
				$mdbFileFullPath = "{0}\{1}" -f $dbPath, $db.mdb
				$ldbFileFullPath = "{0}\{1}" -f $dbPath, $db.ldb
				$dbname = $db.name
				Log-Write "Attaching database $dbname, mdb=$mdbFileFullPath, ldb=$ldbFileFullPath"
				$sc = new-object System.Collections.Specialized.StringCollection
				$sc.Add($mdbFileFullPath)
				$sc.Add($ldbFileFullPath)
				$s.AttachDatabase($dbname, $sc)
			}
		} else {
			Log-Write "Database config file not found"
			ForEach ($mdb in (Get-ChildItem $dbPath -Filter *.mdf)) {
				if (($mdb.Name.CompareTo('master.mdf')) -and ($mdb.Name.CompareTo('model.mdf')) -and ($mdb.Name.CompareTo('MSDBData.mdf')) -and ($mdb.Name.CompareTo('tempdb.mdf'))) {
					$mdbName = $mdb.BaseName
					Log-Write "Attaching database $mdbName"
					$sc = new-object System.Collections.Specialized.StringCollection
					$mdbFileFullPath = "{0}\{1}" -f $dbPath, $mdb.Name
					$sc.Add($mdbFileFullPath)

					$ldb = "{0}_log.ldf" -f $mdbName
					$ldbFileFullPath = "{0}\{1}" -f $dbPath, $ldb
					if (Test-Path $ldbFileFullPath) {
						$sc.Add($ldbFileFullPath)
					}

					$s.AttachDatabase($mdbName, $sc)
				}
			}
		}
	} Catch {
		$ErrorMessage = $_.Exception.Message
		$FailedItem = $_.Exception.ItemName
		Log-Write "Failed to process item $FailedItem when attaching DB files. The error message was $ErrorMessage."
	}
}

function mssql_create_user {
    if (!$ENV:cliqrSqlDBUserName -or !$ENV:cliqrSqlDBPassword) {
		return
	}
    Log-Write "Creating db user $userName"
    $conn=new-object System.Data.SqlClient.SQLConnection
    $ConnectionString = "Server={0};Integrated Security=False;Connect Timeout={1};uid=sa;pwd=$ENV:cliqrDatabaseRootPass" -f "$CLIQR_SQL_INSTANCE", 30
    $conn.ConnectionString = $ConnectionString
    $conn.Open()
    $Query = "CREATE LOGIN [$ENV:cliqrSqlDBUserName] WITH PASSWORD = '$ENV:cliqrSqlDBPassword' ,CHECK_POLICY = OFF"
    $cmd=new-object system.Data.SqlClient.SqlCommand($Query,$conn)
    $cmd.CommandTimeout=$QueryTimeout
    $cmd.ExecuteNonQuery()
    $conn.Close()
}

function msql12_run_query {
    if (!$ENV:cliqrDBSetupScript -or $ENV:cliqrDBSetupScript -eq 'x:\app\') {
        return
    }

    Log-Write "Processing SQL queries: $ENV:cliqrDBSetupScript"
    if ($ENV:cliqrSqlDBName) {
        $dbName = $ENV:cliqrSqlDBName
    } else {
        $dbName = $CLIQR_DEFAULT_DB_NAME
    }

    $sqlArray = @()
    ForEach ($sq in ($ENV:cliqrDBSetupScript.split(";"))) {
        if (!$sq) {
            continue
        }

        Log-Write "Processing sql script/path: $sq"
        if ((Get-Item "$sq").PsIsContainer) {
            ForEach ($sql in (Get-ChildItem $sq -filter *.sql)) {
                $sqlArray += "$sq\$sql"
            }
        } else {
            $sqlArray += $sq
        }

    }

    $env:PSExecutionPolicyPreference = "bypass"
    import-module "sqlps"

    ForEach ($sqlfile in $sqlArray) {
        Log-Write "Invoke-Sqlcmd -inputfile $sqlfile -serverinstance $CLIQR_SQL_INSTANCE -Username sa -Password '$ENV:cliqrDatabaseRootPass'"
        Invoke-Sqlcmd -inputfile $sqlfile -serverinstance "$CLIQR_SQL_INSTANCE" -Username sa -Password $ENV:cliqrDatabaseRootPass
    }
}

function mssql12_init_db {

	if ($ENV:cliqrSqlDBPath) {
        $dbPath = $ENV:cliqrSqlDBPath
    } else {
        $dbPath = $CLIQR_DEFAULT_DB_PATH
    }
    
    if (!(Test-Path $dbPath)) {
		mkdir $dbPath
    }

    Log-Write "Default dbPath in init db is set to $dbPath"

    $s = New-Object Microsoft.SqlServer.Management.Smo.Server("$CLIQR_SQL_INSTANCE")
	
	# change default database locations
	$s.Properties['DefaultFile'].Value = $dbPath
	$s.Properties['DefaultLog'].Value = $dbPath
	$s.Properties["BackupDirectory"].Value = $dbPath
	$s.Alter()
	Stop-Service $CLIQR_SQL_SERVICE_NAME
	sleep 10
	Start-Service $CLIQR_SQL_SERVICE_NAME
	sleep 10	
	# reset password

    $s = New-Object Microsoft.SqlServer.Management.Smo.Server("$CLIQR_SQL_INSTANCE")
	$s.ConnectionContext.LoginSecure = $false
    $s.ConnectionContext.set_login('sa')
    $passwd = ConvertTo-SecureString $ENV:cliqrDatabaseRootPass -AsPlainText -Force
   	$s.ConnectionContext.set_SecurePassword($passwd)

    if (Test-Path $dbPath\*.mdf) {
        # attach existing database
        $sc = new-object System.Collections.Specialized.StringCollection
        $fileList = (Get-childitem $dbPath | where-object {$_.extension -eq ".mdf"}).basename
        foreach($file in $fileList){
            $sysDbName = $dbPath + '\' + $file + '.mdf'
                $dbLogName = $dbPath + '\' + $file + '_log.ldf'
                $sc.Add($sysDbName)
                $sc.Add($dbLogName)
                $s.AttachDatabase($file, $sc)

        }
    } 
}


function sqlserver2k12_handler([string] $cmd) {
    Log-Write "Entering SQL Server 2012 Standard $cmd handler"
	Start-Service $CLIQR_SQL_SERVICE_NAME	
	init_sqlps2012_env
	
	switch ($cmd) 
    {
        "start" {
        	if (Test-Path $STARTED_FLAG_FILE) {
                Log-Write "Service already started, exit now"
                return
            }
            Log-Write "Starting service [$ENV:OSSVC_CONFIG]"
            New-Item $STARTED_FLAG_FILE -type file

			$pdiskRoot = "{0}:\" -f $OSMOSIX_PDISK_DRIVE
			if (!(Test-Path $pdiskRoot)) {
				Initialize-Disk $OSMOSIX_PDISK_ID $OSMOSIX_PDISK_DRIVE 
				$FIRSTRUN = $true
			} elseif (!(Test-Path $CLIQR_DEFAULT_DB_PATH)) {
				$FIRSTRUN = $true
			} else {
				$FIRSTRUN = $false
			}

			mssql_reset_password
			mssql12_init_db
	     	mssql_attach_db    		
        	mssql_create_user
			if ($FIRSTRUN) {
				msql12_run_query				
			}
            
        	break
        }
        "stop"  {
            Log-Write "Stopping service [$ENV:OSSVC_CONFIG]"
			Stop-Service $CLIQR_SQL_SERVICE_NAME
            break
        }
    }

    Log-Write "Leaving sql server $cmd handler"
}


#######################
# Main service routines
#######################

function main([string] $cmd) {

	if (Test-Path 'c:\temp\userenv.ps1') {
		. 'c:\temp\userenv.ps1'
	} else {
		Log-Write "Missing user environment variables, service script exit"
		$host.SetShouldExit(0)
		return
	}
	
	if ($ENV:cliqrSQLExpressMode) {
		$CLIQR_SQL_INSTANCE = 'localhost\sqlexpress'		
		$CLIQR_SQL_SERVICE_NAME = 'MSSQL$SQLEXPRESS'
	}

	switch ($cmd) 
    {
        "start" { sqlserver2k12_handler "start"; break }
        "stop"  { sqlserver2k12_handler "stop"; break }
    }
}

main $args
