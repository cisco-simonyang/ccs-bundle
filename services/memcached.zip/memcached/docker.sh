#!/bin/bash

DOCKER_SVCNAME='memcached'
DOCKER_IMG_NAME=`getDockerImageName $DOCKER_SVCNAME`

installMemcachedDocker() {
    loadDockerImage $DOCKER_IMG_NAME
}

startMemcachedDocker() {
    removeDockerContainer $DOCKER_SVCNAME
    cmd="docker run -d \
        -p 11211:11211 \
        --name $DOCKER_SVCNAME $DOCKER_IMG_NAME"

    log "running command: $cmd"
    result=$($cmd 2>&1)

    if [ $? -eq 0 ]; then
        log "container started successfully. "
    else
        log "container start failed. "
    fi

    log $result
}

stopMemcachedDocker() {
    docker stop $DOCKER_SVCNAME
    log "stopping container $DOCKER_SVCNAME"
    docker rm -f $DOCKER_SVCNAME
}

restartMemcachedDocker() {
    stopMemcachedDocker
    startMemcachedDocker
}

