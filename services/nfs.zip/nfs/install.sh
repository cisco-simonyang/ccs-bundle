#!/bin/bash

. /usr/local/osmosix/service/utils/os_info_util.sh
. /usr/local/osmosix/service/utils/cfgutil.sh

username=`getUserName`
accessmode="_ACCESS_MODE"

echo "User Name is - $username"


serverMntPath=/data

if [ -z "$clientMntPoint" ]; then
	clientMntPoint=/shared
fi

if [ "$os" == "Ubuntu" ]; then
	apt-get -y -qq install nfs-common
elif [ "$os" == "CentOS" ] || [ "$os" == "RHEL" ]; then
	yum -y install nfs-utils nfs-utils-lib
else
	yum -y install nfs-utils nfs-utils-lib
fi

[ -d $clientMntPoint ] || mkdir -p -m 0755 $clientMntPoint
chown $username:$username $clientMntPoint

case $accessmode in
rw)
        opt='rw'
        ;;
r)
        opt='ro'
        ;;
*)
        exit 1
esac


mount -o $opt NODE_IP:$serverMntPath $clientMntPoint
