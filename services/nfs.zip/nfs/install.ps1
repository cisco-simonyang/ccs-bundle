# Setup the registry keys: userid and groupid
# USER_ID be dynamically replaced at NFS server, i.e. NFS server assign the user privilege to client
New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\ClientForNFS\CurrentVersion\Default -Name "AnonymousUid" -PropertyType "DWord" -Value USER_ID
New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\ClientForNFS\CurrentVersion\Default -Name "AnonymousGid" -PropertyType "DWord" -Value USER_ID

# start Client for NFS
Restart-Service -DisplayName "Client for NFS"

# mount NFS server share /data to drive x:
New-PSDrive -Name x -PSProvider FileSystem -Persist -Root \\NODE_IP\data
