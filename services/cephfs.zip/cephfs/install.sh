#!/bin/bash

. /usr/local/osmosix/service/utils/os_info_util.sh
. /usr/local/osmosix/service/utils/cfgutil.sh
. /usr/local/osmosix/service/utils/install_util.sh

username=`getUserName`

echo "User Name is - $username"

#get information about the current os : name, version, arch
currentOsInfo=$(getCurrentOSInfo);
IFS='|' read -ra os_info <<< "$currentOsInfo";

for i in "${os_info[@]}"; do
    IFS='=' read -a resultMap <<< "$i"
    if [ "${resultMap[0]}" == "OS" ]; then
        os="${resultMap[1]}";
    elif [ "${resultMap[0]}" == "VER" ]; then
        ver="${resultMap[1]}";
    fi
done

createCephAdminKey() {
        cat > /etc/ceph/ceph.client.admin.keyring <<EOF
[client.admin]
        key = $1
        auid = 0
        caps mds = "allow"
        caps mon = "allow *"
        caps osd = "allow *"
EOF
}

installCephFS() {
    if [ $os == "Ubuntu" ]; then
        wget -q -O- 'https://ceph.com/git/?p=ceph.git;a=blob_plain;f=keys/release.asc' | sudo apt-key add -
        echo deb http://ceph.com/debian-hammer/ $(lsb_release -sc) main | sudo tee /etc/apt/sources.list.d/ceph.list
        rm -rf /etc/apt/sources.list.d/semiosis-ubuntu-glusterfs-3_4-precise.list
        sudo apt-get update && sudo apt-get -y install ceph
    else
        uname -mrs | grep el7 
        if [ $? -eq 0 ]; then
            su -c 'rpm -Uvh http://download.ceph.com/rpm-hammer/el7/noarch/ceph-release-1-1.el7.noarch.rpm'    
        else 
            su -c 'rpm -Uvh http://ceph.com/rpm-hammer/el6/noarch/ceph-release-1-1.el6.noarch.rpm'
        fi
        yum -y install ceph-fuse
    fi
}

installWget
installCephFS
createCephAdminKey CEPH_ADMIN_KEY

if [ -z "$clientMntPoint" ]; then
    clientMntPoint=/shared
fi

mkdir $clientMntPoint
chown $username:$username $clientMntPoint
ceph-fuse -m NODE_IP $clientMntPoint
