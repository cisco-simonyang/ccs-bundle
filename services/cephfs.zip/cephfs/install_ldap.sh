#!/bin/bash

#*******************************************************************************
#  LDAP client initialization script
#
#  Copyright (c) 2011 Osmosix, Inc., all rights reserved.
#*******************************************************************************

. /usr/local/osmosix/etc/.osmosix.sh
. /usr/local/osmosix/etc/userenv

patch_ldap_config() {
    config=$1
    ldapserverurl=$2
    oldserver=`cat $config | grep "^uri ldaps://" | cut -b "13-" | awk -F ":" '{print $1}'`

    # remove rootbinddn
    sed -i "s,rootbinddn,#rootbinddn,g" $config

    # fix basedn
    sed -i "s/base  dc=osmosix,dc=com/base $cliqrExternalLdapBaseDN/g" $config

    if [ "$oldserver" == "" ]; then
        echo "adding [uri $ldapserverurl] to $config"
		echo "uri $ldapserverurl" >> $config
	else
		oldserverurl="ldaps://$oldserver:636"
		echo "patching $config to replace old LDAP server $oldserverurl with current LDAP server $ldapserverurl"
		sed -i "s,$oldserverurl,$ldapserverurl,g" $config
	fi
}

LDAPCONFIG=/usr/local/osmosix/service/nfs/ldap.conf
LDAPUSERKEY="ldapuser"
LDAPSERVERKEY="ldapserver"

echo "processing system initial string: [$OSMOSIX_SYSTEM_DATA]"
ldapconfig=`echo $OSMOSIX_SYSTEM_DATA | tr -d '"' | awk -F "{" '{print $2}' | awk -F "}" '{print $1}'`
echo $ldapconfig | awk 'BEGIN {FS=","} {x=1; while (x < NF) { print $x; x++} print $NF}' > $LDAPCONFIG

ldapserver=`cat $LDAPCONFIG | grep "$LDAPSERVERKEY:" | awk -F ":" '{print $2}' | tr -d ' '`
ldapuser=`cat $LDAPCONFIG | grep "$LDAPUSERKEY:" | awk -F ":" '{print $2}' | tr -d ' '`

if [ -z "$ldapserver" ]; then
	echo "LDAP is not configured"
fi

if [ -f /etc/ldap.conf ]; then
	patch_ldap_config /etc/ldap.conf $cliqrExternalLdapServer
fi

if [ -f /etc/libnss-ldap.conf ]; then
        patch_ldap_config /etc/libnss-ldap.conf $cliqrExternalLdapServer
fi

# For CentOS 6
if [ -f /etc/pam_ldap.conf ]; then
        patch_ldap_config /etc/pam_ldap.conf $cliqrExternalLdapServer
fi

if [ -f /etc/nslcd.conf ]; then
	patch_ldap_config /etc/nslcd.conf $cliqrExternalLdapServer
	# nslcd daemon won't be able to launch so just kick it off
	if [ ! -d /var/run/nslcd ]; then
		mkdir /var/run/nslcd
	fi
	service nslcd restart
fi




