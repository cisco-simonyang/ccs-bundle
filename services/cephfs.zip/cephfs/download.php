<?php

include '../elfinder/php/cliqr.php';


if (isset($_GET['ident'])) {
    error_log(sprintf("ident = %s", $_GET['ident']));
    $permission = getPermission($_GET['ident'], '_ALLOWED_GROUPS', '_LAUNCH_VENDOR_ID', '_LAUNCH_USER_NAME');
    error_log(sprintf("access mode: %s", $permission));
    $file = $_GET['file'];
    error_log(sprintf("file requested: %s", $file));

    $root = realpath($_SERVER["DOCUMENT_ROOT"]);
    $filename = "$root/files/$file";
    error_log(sprintf("file full path: %s", $filename));

    if (!file_exists($filename)) {
        header('HTTP/1.0 404 Not Found');
        echo "Requested file not exist";
        exit;
    }

    $content = file_get_contents($filename);
    $content = str_replace('_ACCESS_MODE', $permission, $content);
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header(sprintf("Content-Disposition: attachment; filename=\"%s\"", $file));
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');
    header(sprintf("Content-Length: %d", strlen($content)));
    echo $content;
}
