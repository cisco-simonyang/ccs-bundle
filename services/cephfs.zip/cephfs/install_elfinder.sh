#!/bin/bash
# Elfinder installer

OSSVC_HOME=/usr/local/osmosix/service
SVCHOME="$OSSVC_HOME/nfs"

. /usr/local/osmosix/etc/userenv
. $OSSVC_HOME/utils/cfgutil.sh
. $OSSVC_HOME/utils/nosqlutil.sh
. $OSSVC_HOME/utils/install_util.sh
. $OSSVC_HOME/utils/os_info_util.sh

root_dir="$( cd "$( dirname $0 )" && pwd )"
echo Root dir $root_dir

SVCNAME=apache2
BASE_APP_DIR=/usr/local/apps
BASE_DEPLOY_DIR=/var/www
APACHE_USER=www-data
USER_ENV=/usr/local/osmosix/etc/userenv
PHP_INI=/etc/php5/apache2/php.ini
LDAP_CONF=/etc/ldap.conf
username=`getUserName`

echo "User Name is - $username"

# force https
cliqrExternalHttpsEnabled=1

if ([ $os == "CentOS" ] || [ $os == "RHEL" ])
then
    SVCNAME=httpd
    APACHE_USER=apache
    PHP_INI=/etc/php.ini
    LDAP_CONF=/etc/pam_ldap.conf
fi
installUnzip
if [ $? -ne 0 ]
then
    log "[ERROR] Failed to install unzip"
    exit 1
fi

# A map of os-name to installation-package
declare -A apache2Packages=(
    ["Ubuntu"]="2.2.*"
    ["CentOS"]="httpd-2.2.*"
    ["RHEL"]="httpd-2.2.*"
)
if [ ! -z $CUSTOM_REPO_URL ]; then
    apache2Packages["Ubuntu"]="2.2.22-1ubuntu1.7"
    apache2Packages["CentOS"]="httpd-2.2.15-39.el6.centos"
    apache2Packages["RHEL"]="httpd-2.2.15-39.el6.centos"
    if ([[ $ver =~ [[:space:]]+7. ]])
    then
        apache2Packages["CentOS"]="httpd-2.4.6"
        apache2Packages["RHEL"]="httpd-2.4.6"
    fi
fi

updateElfinderConfig() {
	if [ -z "$parentJobId" ]; then
		echo "[ERROR] Missing envvar parentJobId"
		exit 100
	fi
	if [ ! -f /usr/local/osmosix/etc/.ccm ]; then
		echo "[ERROR] Missing ccm address file"
		echo 100
	fi
	CCM_ADDR=`cat /usr/local/osmosix/etc/.ccm`
	if [ -z "$CCM_ADDR" ]; then
		echo "[ERROR] Missing ccm address configuration"
	fi

	if [ ! -z "$samlAuthDomain" ]; then
		CCM_ADDR=$samlAuthDomain
		replaceToken /var/www/elfinder.php _SAML_MODE_ TRUE
	else
		replaceToken /var/www/elfinder.php _SAML_MODE_ FALSE
	fi

	host=`hostname`
	tierPublicIpName="CliqrTier_${cliqrAppTierName}_PUBLIC_IP"
	myip=`echo ${!tierPublicIpName} |  awk 'BEGIN {FS=","} {x=1; while (x < NF) { print $x; x++} print $NF}'  | sed "${host#node}q;d"`

	replaceToken /var/www/elfinder.php _JOB_ID_ $parentJobId
	replaceToken /var/www/elfinder.php _MY_IP_ $myip
	replaceToken /var/www/elfinder.php _CCM_ADDR_ $CCM_ADDR
	replaceToken /var/www/elfinder.php _ALLOWED_GROUPS "$cliqrStorageAllowedGroups"
	replaceToken /var/www/elfinder.php _LAUNCH_VENDOR_ID $launchVendorId
	replaceToken /var/www/elfinder.php _LAUNCH_USER_NAME $launchUserName
	replaceToken /var/www/elfinder/php/connector.php _SSO_MODE_ true
	ln -s /home/cliqruser/.ssh/cliqruserKey /usr/local/osmosix/etc/.user.key
	openssl rsa -in /usr/local/osmosix/etc/.user.key -outform PEM -pubout -out /usr/local/osmosix/etc/.user.pub
	chown cliqruser:cliqruser /usr/local/osmosix/etc/.user.pub
}

addHttpRepoVhost() {
	if [ "$cliqrHttpRepo" == "true" ]; then
		echo "Adding HTTP repo vhost"
		cp /etc/$SVCNAME/sites-available/default-ssl /etc/$SVCNAME/sites-available/repo-ssl
		sed -i "s,DocumentRoot /var/www,DocumentRoot /storage,g" /etc/$SVCNAME/sites-available/repo-ssl
		sed -i "s,<Directory /var/www/>,<Directory /storage>,g" /etc/$SVCNAME/sites-available/repo-ssl
		sed -i "s/443/8080/g" /etc/$SVCNAME/sites-available/repo-ssl
		ln -s /etc/$SVCNAME/sites-available/repo-ssl /etc/$SVCNAME/sites-enabled/repo-ssl
		cp /usr/local/osmosix/service/cephfs/etc/ports.conf.repo /etc/$SVCNAME/ports.conf
	fi
}

installApache() {
    echo "[INSTALL] Starting $SVCNAME installation"
    preInstall "package-update"
    install $SVCNAME "$(declare -p apache2Packages)"

    . ${root_dir}/post_install
    if [ $? -ne 0 ]
    then
            echo "[ERROR] Failed to install $SVCNAME"
            exit 1
    fi
    
    echo "[CONFIGURATION] Starting Apache configuration"
    . ${root_dir}/conf/apache_config
    if [ $? -ne 0 ]
    then
        echo "[CONFIGURATION] Failed to configure $SVCNAME"
        exit 1
    else
        echo "[CONFIGURATION] $SVCNAME configuration was successful"
    fi

    return 0
}

installElfinderUbuntu() {
	apt-get -y install apache2
	update-rc.d -f apache2 remove

	apt-get -y install php5
	apt-get -y install libapache2-mod-auth-mysql php5-mysql
	apt-get -y install perl libapache2-mod-perl2
	apt-get -y install python libapache2-mod-python
	a2enmod ssl
	/etc/init.d/apache2 restart

	sed -i "s,Indexes FollowSymLinks MultiViews,FollowSymLinks MultiViews,g" /etc/apache2/sites-available/default
	sed -i "s,Indexes FollowSymLinks MultiViews,FollowSymLinks MultiViews,g" /etc/apache2/sites-available/default-ssl
	sed -i "s,upload_max_filesize = 2M,upload_max_filesize = 1024M,g" /etc/php5/apache2/php.ini
	sed -i "s,post_max_size = 8M,post_max_size = 1024M,g" /etc/php5/apache2/php.ini

	mkdir /usr/local/osmosix/elfinder
	cd /usr/local/osmosix/elfinder
	tar xzvf /usr/local/osmosix/service/cephfs/elfinder2x.tar.gz
	cd /var/www
	rm -rf *
	ln -s /usr/local/osmosix/elfinder elfinder
	ln -s /storage .

	if [ -f elfinder/elfinder-sso.php ]; then
		rm -rf elfinder/elfinder.php
		mv elfinder/elfinder-sso.php elfinder.php
	else
		mv elfinder/elfinder.php .
	fi

	if [ -z "$cliqrStorageUIPasswd" ]; then
		cliqrStorageUIPasswd="welcome2cliqr"
	fi
	sed -i "s,mypassword,$cliqrStorageUIPasswd,g" elfinder.php

	cat /etc/ldap.conf |grep "^uri ldap" > /dev/null 2>&1
	if [ $? -eq 0 ]; then
	    if [ -f /usr/local/osmosix/etc/ldap.conf ]; then
	        ldapuser=`cat /usr/local/osmosix/etc/ldap.conf |grep ldapuser | awk -F ":" '{print $2}'`
	    else
	        ldapuser=$launchUserName
	    fi
	fi

	if [ -z "$ldapuser" ]; then
	    ldapuser=$username
	fi

	chown $ldapuser:$ldapuser  /storage
	chown $ldapuser:$ldapuser  /var/www/elfinder.php
	chown $ldapuser:$ldapuser  /var/lib/php5
	sed -i "s,www-data,$ldapuser,g" /etc/apache2/envvars
	if [ ! -s /etc/apache2/sites-enabled/default-ssl ]; then
	    ln -s /etc/apache2/sites-available/default-ssl /etc/apache2/sites-enabled/default-ssl
	fi

	# enable https redirect
	a2enmod rewrite
	cat > /etc/apache2/sites-available/default <<EOF
<VirtualHost 0.0.0.0:80>
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule (.*) https://%{HTTP_HOST}%{REQUEST_URI}
</VirtualHost>
EOF
	
	sed -i "s,DirectoryIndex index.html index.cgi index.pl index.php index.xhtml index.htm,DirectoryIndex elfinder.php,g" /etc/apache2/mods-enabled/dir.conf
	/etc/init.d/apache2 stop
	sleep 2
	rm -rf /var/lock/apache2
	sleep 2
	updateElfinderConfig
	addHttpRepoVhost
	/etc/init.d/apache2 restart
}

installElfinder() {
	echo "Installing elfinder components"
	sed -i "s,upload_max_filesize = 2M,upload_max_filesize = 1024M,g" $PHP_INI
	sed -i "s,post_max_size = 8M,post_max_size = 1024M,g" $PHP_INI

	mkdir /usr/local/osmosix/elfinder
	cd /usr/local/osmosix/elfinder
	tar xzvf /usr/local/osmosix/service/nfs/elfinder2x.tar.gz
	cd /var/www
	rm -rf *
	ln -s /usr/local/osmosix/elfinder elfinder
	ln -s /storage .
	
	if [ -f elfinder/elfinder-sso.php ]; then
		rm -rf elfinder/elfinder.php
		mv elfinder/elfinder-sso.php elfinder.php
	else
		mv elfinder/elfinder.php .
	fi
	
	if [ -z "$cliqrStorageUIPasswd" ]; then
		cliqrStorageUIPasswd="welcome2cliqr"
	fi
	sed -i "s,mypassword,$cliqrStorageUIPasswd,g" elfinder.php

	cat $LDAP_CONF |grep "^uri ldap" > /dev/null 2>&1
	if [ $? -eq 0 ]; then
	    if [ -f /usr/local/osmosix/etc/ldap.conf ]; then
	        ldapuser=`cat /usr/local/osmosix/etc/ldap.conf |grep ldapuser | awk -F ":" '{print $2}'`
	    else
	        ldapuser=$launchUserName
	    fi
	fi

	if [ -z "$ldapuser" ]; then
	    ldapuser=$username
	fi

	# fix storage & session path permission
	chown $ldapuser:$ldapuser  /storage
	chown $ldapuser:$ldapuser  /var/www/elfinder.php
	chown $ldapuser:$ldapuser  /var/lib/php/session

	if ([ $os == "CentOS" ] || [ $os == "RHEL" ]); then
		sed -i "s,User apache,User $ldapuser,g" /etc/httpd/conf/httpd.conf
		sed -i "s,Group apache,Group $ldapuser,g" /etc/httpd/conf/httpd.conf
		which systemctl > /dev/null 2>&1
		if [ $? -eq 0 ]; then
			sed -i "s,DirectoryIndex index.html,DirectoryIndex elfinder.php,g" /etc/httpd/conf/httpd.conf
		else
			sed -i "s,DirectoryIndex index.html index.html.var,DirectoryIndex elfinder.php,g" /etc/httpd/conf/httpd.conf
		fi
	else
		sed -i "s,www-data,$ldapuser,g" /etc/$SVCNAME/envvars
		sed -i "s,DirectoryIndex index.html index.cgi index.pl index.php index.xhtml index.htm,DirectoryIndex elfinder.php,g" /etc/apache2/mods-enabled/dir.conf
	fi

	# enable https redirect
	if [ $os == "Ubuntu" ]; then
		a2enmod rewrite
		cat > /etc/$SVCNAME/sites-available/default <<EOF
<VirtualHost 0.0.0.0:80>
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule (.*) https://%{HTTP_HOST}%{REQUEST_URI}
</VirtualHost>
EOF

		cat >> /etc/apache2/apache2.conf <<EOF
<Files ~ "^\install.*">
  Order allow,deny
  Deny from all
</Files>
EOF
	else
		cat >> /etc/httpd/conf/httpd.conf <<EOF
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule (.*) https://%{HTTP_HOST}%{REQUEST_URI}
EOF

		cat >> /etc/httpd/conf/httpd.conf <<EOF
<Files ~ "^\install.*">
  Order allow,deny
  Deny from all
</Files>
EOF
	fi



	updateElfinderConfig
	addHttpRepoVhost
	service $SVCNAME restart
}

if [ $os == "Ubuntu" ]; then
	installElfinderUbuntu
else
	installApache
	installElfinder
fi




