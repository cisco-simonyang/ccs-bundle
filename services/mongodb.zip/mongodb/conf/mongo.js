use admin
db.addUser( { user: "%DB_USER%", pwd: "%DB_PASS%", roles: [ "userAdminAnyDatabase","readWriteAnyDatabase", "dbAdminAnyDatabase", "clusterAdmin" ]  }  )
db.auth("%DB_USER%","%DB_PASS%")
use %DB_NAME%
db.addUser({ user: "%DB_USER%", pwd: "%DB_PASS%", roles: [ "readWrite", "dbAdmin", "userAdmin" ]});