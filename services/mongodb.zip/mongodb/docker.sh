#!/bin/bash

DOCKER_SVCNAME=mongodb;
MONGO_DOCKER_CONF_DIR="/etc/mongoconf";
MONGO_DOCKER_CONF_FILE="$MONGO_DOCKER_CONF_DIR/mongodb.conf";
DOCKER_SETUP_USER_FILE="$MONGO_DOCKER_CONF_DIR/mongo_docker.js";
MONGO_DOCKER_LOG_DIR="/var/log/mongodb";
MONGO_DOCKER_LOG_FILE="$MONGO_DOCKER_LOG_DIR/mongod.log";
DOCKER_SVCHOME="$OSSVC_HOME/$DOCKER_SVCNAME";
DB_DIR="/data/mongodb";

. $OSSVC_HOME/utils/docker_util.sh
. $OSSVC_HOME/utils/nosqlutil.sh
. $OSSVC_HOME/utils/cfgutil.sh

DOCKER_IMAGE_NAME=`getDockerImageName $DOCKER_SVCNAME`

installMongoDocker(){
    loadDockerImage $DOCKER_IMAGE_NAME
}

waitForDockerAppStart() {
    for EACH in `seq 1 20`
    do
        echo "Wait for mongod.log ... "
        grep -i 'waiting for connections'  $MONGO_DOCKER_LOG_FILE
        if [ $? -eq 0 ]
        then
            break
        fi
        sleep 15
    done
}

runMongoDockerConfig(){
    if [ ! -d $MONGO_DOCKER_CONF_DIR ]; then
        mkdir -p $MONGO_DOCKER_CONF_DIR;
    fi

    cp $DOCKER_SVCHOME/mongodb.conf $MONGO_DOCKER_CONF_FILE
    cp $DOCKER_SVCHOME/conf/mongo_docker.js $DOCKER_SETUP_USER_FILE

    if [ ! -d $MONGO_DOCKER_LOG_DIR ];then
        mkdir -p $MONGO_DOCKER_LOG_DIR
        chmod a+w $MONGO_DOCKER_LOG_DIR -R
    fi

    perl -pi -e 's/dbPath:.*$/dbPath: \/data\/mongodb/' $MONGO_DOCKER_CONF_FILE
    perl -pi -e 's/bindIp:.*$/bindIp: 0.0.0.0/' $MONGO_DOCKER_CONF_FILE


    if [ -z $cliqrNoSqlDatabaseUser ];
    then
        uncommentConfig $MONGO_DOCKER_CONF_FILE "#AUTH_ENABLED"
        replaceToken $MONGO_DOCKER_CONF_FILE "%AUTH%" "disabled"
        log "[DB-INIT] No DB UserName provided, Authentication disabled";
        if [ -f $MONGO_LOCK_FILE ];
        then
            rm -rf $MONGO_LOCK_FILE;
        fi

    else
        uncommentConfig $MONGO_DOCKER_CONF_FILE "#AUTH_ENABLED"
        replaceToken $MONGO_DOCKER_CONF_FILE "%AUTH%" "enabled"
        log "[DB-INIT] DB UserName provided, Authentication enabled";

        if [ -f $DB_INIT_INDICATOR ];
        then
            if [ -f $MONGO_LOCK_FILE ];
            then
                rm -rf $MONGO_LOCK_FILE;
            fi
            log "[DB-INIT] DB Setup has already been run.";
            return;
        else
            rootPasswd="";
            if [ -z $cliqrNoSqlDatabaseRootPass ];
            then
                rootPasswd="cliqrtech";
            else
                rootPasswd=$cliqrNoSqlDatabaseRootPass;
            fi

            replaceToken $DOCKER_SETUP_USER_FILE "%DB_NAME%" $cliqrNoSqlDatabaseName
            replaceToken $DOCKER_SETUP_USER_FILE "%DB_USER%" $cliqrNoSqlDatabaseUser
            replaceToken $DOCKER_SETUP_USER_FILE "%DB_PASS%" $rootPasswd
        fi
    fi

}

runMongoDockerUserCreate(){
    log "trying to run user create script";
    if [ -f $DB_INIT_INDICATOR ];
    then
        log "[USER-CREATE] User Create Script run already";
    else
        if [ -z $cliqrNoSqlDatabaseUser ];
        then
            log "[USER-CREATE] DB and DBUser creation skipped";
        else
            docker exec $DOCKER_SVCNAME mongo $DOCKER_SETUP_USER_FILE
            if [ $? -eq 0 ]
            then
                log "[USER-CREATE] Successfully Created DB and its User.";
                if `touch $DB_INIT_INDICATOR`
                then
                    log "[USER-CREATE] Successfully created the DB init indicator";
                else
                    log "[USER-CREATE] Error occurred while creating DB Setup indicator";
                fi
            else
                log "[USER-CREATE] Error occurred while running the User Setup script.";
                exit 127;
            fi
        fi
    fi
}

startMongoDockerService(){
    removeDockerContainer $DOCKER_SVCNAME
    if [ -f $MONGO_DOCKER_LOG_FILE ];then
        rm -rf $MONGO_DOCKER_LOG_FILE;
    fi
    docker run -d --name=$DOCKER_SVCNAME -v $MONGO_DOCKER_CONF_DIR:$MONGO_DOCKER_CONF_DIR \
                                         -v $DB_DIR:$DB_DIR \
                                         -v $MONGO_DOCKER_LOG_DIR:$MONGO_DOCKER_LOG_DIR \
                                         -p 27017:27017 $DOCKER_IMAGE_NAME mongod --config $MONGO_DOCKER_CONF_FILE

    log "wait for app start";
    waitForDockerAppStart
}
stopMongoDockerService(){
    docker stop $DOCKER_SVCNAME
    docker rm -f $DOCKER_SVCNAME
}
restartMongoDockerService(){
    stopMongoDockerService
    startMongoDockerService
}