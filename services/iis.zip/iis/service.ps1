#########################################################################
#	Powershell Service Script
#
#	Supported services:
#		- IIS 7.x
#
#	Copyright(c) 2012 CliQr Technologies, Inc., all rights reserved.
#########################################################################

. 'c:\Program Files\osmosix\etc\cliqr.ps1'

# Install web server role
Import-Module ServerManager
Add-WindowsFeature Web-Server
Install-WindowsFeature web-Server

# Grant permission to the folder c:\temp
# New-Item -type directory -path C:\temp
#$Acl = Get-Acl "C:\temp"
#$Ar = New-Object  system.security.accesscontrol.filesystemaccessrule("IIS_IUSRS","FullControl","ContainerInherit, ObjectInherit", "None","Allow")
#$Acl.SetAccessRule($Ar)
#Set-Acl "C:\temp" $Acl

& 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\aspnet_regiis.exe' /iru
Install-WindowsFeature Web-Asp-Net45

$driveOP = get-psdrive | ? { $_.Name -eq "$OSMOSIX_EDISK_DRIVE" } | ? { $_.Free -ne $null }
if ( $driveOP -eq $null ) {
 $OSMOSIX_EDISK_DRIVE = (get-location).Drive.Name
}

$CLIQR_DEFAULT_WEBSITE_PATH = "{0}:\WebSite" -f $OSMOSIX_EDISK_DRIVE
$CLIQR_DEFAULT_APP_POOL_NAME = 'DefaultAppPool'
$CLIQR_DEFAULT_DOTNET_VERSION = '4.0'
$WEBPICMD = "c:\tools\webpicmd.exe"
$CLIQR_DEFAULT_CONFIG_FILE_TYPES = '*.xml,*.conf'
$FIRSTRUN = $true
$STARTED_FLAG_FILE = 'c:\temp\started'
$DBNODENAME = 'dbnode'

################################
# IIS/ASP.NET Service Routines
################################

function iis_webpicmd_install {
    if ($ENV:cliqrWebpiComponents) {
        Log-Write "Executing Web Platform components with webpicmd: $ENV:cliqrWebpiComponents"
        ForEach ($wc in ($ENV:cliqrWebpiComponents.split(";"))) {
            $component, $feed = ($wc.Split("@"))
            Log-Write "Installing $component with command: $WEBPICMD /AcceptEula /SuppressReboot /UseRemoteDatabase /Install $component@$feed"
            & $WEBPICMD /AcceptEula /SuppressReboot /UseRemoteDatabase /Install $component@$feed
        }
    }
}

function iis_deploy_webapp {
	Import-Module ServerManager
	Install-WindowsFeature Web-Server

    Import-Module WebAdministration

    if ($ENV:cliqrIISDOTNETVER) {
        $dotNetVer = $ENV:cliqrIISDOTNETVER
    } else {
        $dotNetVer = $CLIQR_DEFAULT_DOTNET_VERSION
    }

    if ($ENV:cliqrIISPoolName) {
        $appPoolName = $ENV:cliqrIISPoolName
        
    } else {
        $appPoolName = $CLIQR_DEFAULT_APP_POOL_NAME
    }
	
	if ($appPoolName -eq 'Classic .NET AppPool' -or $appPoolName -eq 'ASP.NET v4.0' -or $appPoolName -eq 'ASP.NET v4.0 Classic' -or $appPoolName -eq 'DefaultAppPool') {
		Log-Write "Using application pool $appPoolName"
	} else {
		Log-Write "Creating application pool $appPoolName"
		New-Item "IIS:\AppPools\$appPoolName"
		Set-ItemProperty "IIS:\AppPools\$appPoolName" managedRuntimeVersion "v$dotNetVer"
	}

	Log-Write "Extracting IIS package $ENV:cliqrIISAppPkg"
	Try {
		if (!(Test-Path($CLIQR_DEFAULT_WEBSITE_PATH))) {
			mkdir $CLIQR_DEFAULT_WEBSITE_PATH
		}
		Unzip-File $ENV:cliqrIISAppPkg $CLIQR_DEFAULT_WEBSITE_PATH
	} Catch {
		$ErrorMessage = $_.Exception.Message
		$FailedItem = $_.Exception.ItemName
		Log-Write "Failed to process item $FailedItem. The error message was $ErrorMessage."
		return
	}
	
	Log-Write "Setting up security descriptor for web site root directory $CLIQR_DEFAULT_WEBSITE_PATH"
    $acl = Get-Acl 'c:\Temp'
     $Ar = New-Object  system.security.accesscontrol.filesystemaccessrule("IIS_IUSRS","FullControl","ContainerInherit, ObjectInherit", "None","Allow")
     $acl.SetAccessRule($Ar)
    Set-Acl $CLIQR_DEFAULT_WEBSITE_PATH $acl
    # Remove temp acl 
	$acl.RemoveAccessRule($Ar)
    Set-Acl "C:\temp" $acl
	# set database node hosts entry
	"$ENV:CliqrTier_Database_IP  $DBNODENAME" | Out-File -encoding "UTF8" -append  'c:\windows\system32\drivers\etc\hosts'
	
	Log-Write "Replacing tokens to config files: $ENV:cliqrIisConfigFiles"
	ForEach ($cfile in ($ENV:cliqrIisConfigFiles.split(";"))) {
	    if (!$cfile) {
        	continue
    	}
		Log-Write "Processing config file $cfile"
		$configFile = "{0}\{1}" -f $CLIQR_DEFAULT_WEBSITE_PATH, $cfile
        $bakFile = "$configFile.!bk"
		Ren $configFile -NewName $bakFile
    	Get-Content $bakFile | %{$_  -creplace '%DB_TIER_IP%', $DBNODENAME} | %{$_  -creplace '%NOSQLDB_TIER_IP%', $ENV:CliqrTier_NoSQLDatabase_IP} | %{$_  -creplace '%MB_TIER_IP%', $ENV:CliqrTier_MsgBus_IP} | %{$_  -creplace '%BC_TIER_IP%', $ENV:CliqrTier_BackendCache_IP} | %{$_  -creplace '%USER_PARAM1%', $ENV:cliqrUserParam1} | %{$_  -creplace '%USER_PARAM2%', $ENV:cliqrUserParam2} | %{$_  -creplace '%USER_PARAM3%', $ENV:cliqrUserParam3} | Set-Content $configFile
		Del $bakFile
        $list = (Get-Childitem env:)
        ForEach ($item in $list) {
            $key = $item.Key
            if ($key -match "$CliqrTier_(.*)_IP") {
                $tier = ($key -split "_")[1]
                Log-Write "> Tier name: $tier"
                $macro = "%{0}_TIER_IP%" -f $tier
                Log-Write "> Macro name: $macro"
                Ren $configFile -NewName $bakFile
                $value = [Environment]::GetEnvironmentVariable($key, "Machine")
                Log-Write "> Macro value is: $value" 
                Get-Content $bakFile | %{$_  -creplace $macro, $value} |Set-Content $configFile
                Del $bakFile
            }
        }
	}

	Log-Write "Setting up application $ENV:cliqrIISAppAlias in IIS pool $appPoolName"
    New-Item "IIS:\Sites\Default Web Site\$ENV:cliqrIISAppAlias" -Type Application -PhysicalPath $CLIQR_DEFAULT_WEBSITE_PATH
    Set-ItemProperty "IIS:\sites\Default Web Site\$ENV:cliqrIISAppAlias" -Name applicationPool -Value $appPoolName
}

function iis_handler([string] $cmd) {
    Log-Write "Entering IIS $cmd handler"
    
    Import-Module WebAdministration
	switch ($cmd) 
    {
        "start" {
            if (Test-Path $STARTED_FLAG_FILE) {
                Log-Write "Service already started, exit now"
                return
            }
            Log-Write "Starting service [$ENV:OSSVC_CONFIG]"
            New-Item $STARTED_FLAG_FILE -type file
            iis_deploy_webapp
            break
        }
        "stop"  {
            Log-Write "Stopping service [$ENV:OSSVC_CONFIG]"
            break
        }
    }
    
    Log-Write "Leaving IIS $cmd handler"
}

#######################
# Main service routines
#######################

function main([string] $cmd) {

	if (Test-Path 'c:\temp\userenv.ps1') {
		. 'c:\temp\userenv.ps1'
	} else {
		Log-Write "Missing user environment variables, service script exit"
		$host.SetShouldExit(0)
		return
	}
	
	switch ($cmd)
    {
        "start" { iis_handler "start"; break }
        "stop"  { iis_handler "stop"; break }
    }
}

main $args
