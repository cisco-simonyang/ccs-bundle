#!/bin/bash

root_dir="$( cd "$( dirname $0 )" && pwd )"
REGISTRY_SETUP_DONE=$OSSVC_HOME/utils/.registrySetupDone

useDocker() {
	#check if docker is enabled 
	docker info > /dev/null 2>&1
	if [ $? -ne 0 ]; then
		log "docker not enabled in this VM. does not use docker to launch service"
		return 1
	else
		setupRegistry
		return 0
	fi
}

getImageWithRegistry(){
	registryHost=`getDockerRegistryHost`
	if [ -z $registryHost ]; then
		log "registryHost not provided, use docker hub to load image $1"
		echo $1
	else
		log "load image $1 from $registryHost"
		echo $registryHost/$1
	fi
}


loadDockerImage(){
	#imgUrl=`getImageWithRegistry $1`
	docker pull $1

	if [ $? -ne 0 ]; then
		log "failed to pull image $1"
	fi
}

loginDocker() {
	docker exec -it $1 bash
}

setupRegistry() {
	if [ -f $REGISTRY_SETUP_DONE ]; then
		log "registry already setup"
		return
	fi

	touch $REGISTRY_SETUP_DONE

	if [ -z "$cliqrDockerRegistry" ]; then
		log "no registry provided, use default docker hub"
		return
	fi

	#if registry start with http, setup in-secure registry
	if [[ $cliqrDockerRegistry == http://* ]]; then
		log "setup InSecure Registry"
		setupInSecureRegistry
		return
	fi

	#if registry start with https, check if provided ca.crt
	if [[ $cliqrDockerRegistry == https://* ]]; then
		if [ -z "cliqrDockerRegistryCaCert" ]; then
			log "https registry without cacert provided, no special setting"
			return
		else
			log "setup Registry With CaCert"
			setupRegistryWithCaCert
		fi
	fi
}

getDockerRegistryHost(){
	registryHost=`echo $cliqrDockerRegistry | cut -d '/' -f 3`
	echo $registryHost
}

setupInSecureRegistry(){
	registryHost=`getDockerRegistryHost`
	if [ -z "$registryHost" ]; then
		log "Error: failed to get registry host"
		return
	fi

	if ([ $os == "CentOS" ] || [ $os == "RHEL" ])
	then
		confDir="/etc/systemd/system/docker.service.d"
		mkdir -p $confDir
		cp $OSSVC_HOME/utils/docker.conf $confDir
		replaceToken $confDir/docker.conf %REGISTRY% $registryHost

		systemctl daemon-reload
		systemctl restart docker
	elif [ $os == "Ubuntu" ]
	then
		log "configure insecure registry for Ubuntu"
		grep -q -e "^DOCKER_OPTS" /etc/default/docker
		if [ $? -ne 0 ];then
			echo "DOCKER_OPTS=\"--insecure-registry $registryHost\"" >> /etc/default/docker
		else
			sed -i "s/^\(DOCKER_OPTS=.*\)\"/\1 --insecure-registry $registryHost\"/" /etc/default/docker
		fi
		restart docker
	else
		log "Error: insecure registry only supports centos, rhel, ubuntu14 for now"
		return
	fi
}

setupRegistryWithCaCert() {
	if [ -z "$cliqrDockerRegistryCaCert" ]; then
		log "no cacert provided."
		return
	fi

	registryHost=`getDockerRegistryHost`
	cacertDir="/etc/docker/certs.d/$registryHost"

	mkdir -p $cacertDir
	wget $cliqrDockerRegistryCaCert -O $cacertDir/ca.crt
	if [ $? -ne 0 ]; then
		curl -o $cacertDir/ca.crt $cliqrDockerRegistryCaCert
	fi

	if [ $? -ne 0 ]; then
		log "failed to download cacert: $cliqrDockerRegistryCaCert"
		return 1
	else
		log "download cacert $cliqrDockerRegistryCaCert to $cacertDir"
	fi
	systemctl daemon-reload
	systemctl restart docker
}

getDockerImageName(){
	service=$1
	image=`cat $OSSVC_HOME/utils/docker_image_list | grep $service | cut -d '=' -f 2`

	if [ -z $image ]; then
		log "Error: no image available for $service service "
		return
	fi

	imgUrl=`getImageWithRegistry $image`
	echo $imgUrl
}

removeDockerContainer(){
	service=$1
	docker stop $service
	docker rm -f $service
}
