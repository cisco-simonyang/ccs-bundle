$OS_FLAVOR  = (gwmi win32_operatingsystem).caption
$OS_VERSION = (gwmi win32_operatingsystem).version
$OS_ARCH    = (gwmi win32_operatingsystem).osarchitecture
$COMP_NAME  = (gwmi win32_operatingsystem).pscomputername
$OS_BUILD   = (gwmi win32_operatingsystem).buildnumber

Write-Host "$OS_FLAVOR"
Write-Host "$OS_VERSION"
Write-Host "$OS_ARCH"
Write-Host "$COMP_NAME"
Write-Host "$OS_BUILD"
