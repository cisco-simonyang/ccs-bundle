$envPath = 'C:\temp\userenv.ps1'
if (!(Test-Path $envPath)) {
    exit 0;
}

. 'C:\Program Files\osmosix\etc\cliqr.ps1'
. $envPath

$svc = $args[0]
$symbol = $args[1]
$action = $args[2]


$envvar = 'cliqr' + $svc + $symbol + $action + 'Action'

if(!(Test-Path ('Env:\{0}' -f $envvar))) {
    exit 0
}

$actionExec = Invoke-Expression ('$ENV:{0}' -f $envvar)

if($actionExec) {
    Log-Write "Executing $svc $symbol-$action action: $actionExec"
    [Environment]::SetEnvironmentVariable("scriptKey", $envvar, "Machine")
    iex $actionExec
}

$foldername = ((get-item (Invoke-Expression ('$ENV:{0}' -f $envvar))).Directory.Name)
if($foldername -match $envvar){
    rm $actionExec
}