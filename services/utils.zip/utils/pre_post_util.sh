#!/bin/bash

exec 2>&1
ENVFILE=/usr/local/osmosix/etc/userenv
[ -f $ENVFILE ] || exit 0
. $ENVFILE

svc=`echo ${1:0:1} | tr  '[:lower:]' '[:upper:]'``echo ${1:1}`
symbol=`echo ${2:0:1} | tr  '[:lower:]' '[:upper:]'``echo ${2:1} | tr '[:upper:]' '[:lower:]'`
action=`echo ${3:0:1} | tr  '[:lower:]' '[:upper:]'``echo ${3:1} | tr '[:upper:]' '[:lower:]'`

log() {
	logger -t "OSMOSIX" "[service] $*"
}

env="cliqr${svc}${symbol}${action}Action"
actionExec=${!env}
[ -z "$actionExec" ] && exit 0
scriptfile="`echo $actionExec | awk '{print $1}'`"
log "executing service $SVC $SYMBOL $ACTION script: $scriptfile"
chmod +x $scriptfile
export scriptKey=$env
eval "$actionExec"

echo $scriptfile | grep -i $env
if [ $? -eq 0 ]; then
	rm -f $scriptfile
fi
exit 0
