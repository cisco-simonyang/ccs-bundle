#!/bin/bash

USER_ENV="/usr/local/osmosix/etc/userenv";
APP_MIG_DUMP_FOLDER="/shared/app/appMigrationDump";
OSMOSIX_HOME="/usr/local/osmosix";

if [ "$usePublicIP" == "true" ];
then
	for i in $(echo $CliqrDependencies | tr "," "\n") ;
	do
		if [ $i != "" ];
		then
			token='echo $CliqrTier_'$i"_IP";
			privIP=`eval $token`;
			token='echo $CliqrTier_'$i"_PUBLIC_IP";
			publicIp=`eval $token`;
			privtoken='export CliqrTier_'$i"_PRIVATE_IP=$privIP";
			pubtoken='export CliqrTier_'$i"_IP=$publicIp";
			eval $privtoken
			eval $pubtoken
			echo $privtoken >> $USER_ENV
			echo $pubtoken >> $USER_ENV
		fi;
	done
fi;

expandServerList() {
	serverList=""
	for i in $(echo $2 | tr "," "\n")
	do
		if [ $i != "" ]; then
			server="server $i;\n"
			serverList="$serverList$server"
		fi
	done
	sed -i "s,%SERVERS%,$serverList,g" $1
}

executeScriptsFromFileInOrder(){
	while read line ;do
		if [[ ! "$line" == "#"* ]];
		then
			#echo $line
			array=(${line//|/ })
			RUN=${array[0]}
			RUN_TYPE=${array[1]}
			SCRIPT=${array[2]}
			if [[ "$RUN" == "Y" ]];
			then
				case "$RUN_TYPE" in
					E) echo "Executing script: $SCRIPT"
						if [ -x $SCRIPT ];then
							$SCRIPT
						else
							echo "$SCRIPT is either not found or not executable"
						fi
						;;
					S) echo "Sourcing script: $SCRIPT"
						if [ -x $SCRIPT ];then
							source $SCRIPT
						else
							echo "$SCRIPT is either not found or not executable"
						fi
						;;
					B) echo "Executing script: $SCRIPT in non-blocking mode"
						if [ -x $SCRIPT ];then
							$SCRIPT &
						else
							echo "$SCRIPT is either not found or not executable"
						fi
						;;
					*) echo "Executing script: $SCRIPT"
						if [ -x $SCRIPT ];then
							$SCRIPT
						else
							echo "$SCRIPT is either not found or not executable"
						fi
						;;
				esac
			fi
		fi
	done < $1
}

preSetup(){
	PRE_SETUP_SCRIPT_FILE="$OSSVC_HOME/$SVCNAME/scr/pre-setup.lst"
	if [ -f "$PRE_SETUP_SCRIPT_FILE" ];
	then
		executeScriptsFromFileInOrder $PRE_SETUP_SCRIPT_FILE
	fi
}

postSetup(){
	POST_SETUP_SCRIPT_FILE="$OSSVC_HOME/$SVCNAME/scr/post-setup.lst"
	if [ -f "$PRE_SETUP_SCRIPT_FILE" ];
	then
		executeScriptsFromFileInOrder $POST_SETUP_SCRIPT_FILE
	fi
}

expandListOfServers() {
	serverList=""

	for j in $( echo $2 | tr "," "\n" )
	do
		dependentTier=CliqrTier_${j}_IP
		if [ "$cliqrExternalHttpsEnabled" == 1 ]; then
			dependentTier="CliqrTier_${j}_IP"
		fi

		dependentTierIPs=${!dependentTier}

		if [ ! -z $dependentTierIPs ]; then
			commaSeperatedIPs=$(echo $dependentTierIPs | tr "," "\n");               
			ipList=`echo $commaSeperatedIPs | tr "," "\n"`;
			for i in $ipList
			do
				if [ $i != "" ]; then
					server="server $i;\n"                         
					serverList="$serverList$server"
				fi
			done
		fi
	done
	sed -i "s/%SERVERS%/$serverList/g" $1    
}

getNextAvailablePort(){
	StartingPort=$1
	for (( port=$StartingPort; port<= $(($StartingPort + 500 )); port++ ))
	do
		procOfPort=`lsof -i :"$port"|grep -v PID|awk '{print $2}'`
		if [ -z "$procOfPort" ]; then
			echo $port
			return
		fi
	done
	if [ "$port" -eq $(($StartingPort + 500)) ]; then
		echo "Ports are not available from $StartingPort $(($StartingPort + 500))"
		exit 1;
	fi
}

expandListOfContentServers() {

	#TODO -- handle cluster case, for multiple IPs

	serverList=""

	for j in $( echo $2 | tr "," "\n" )
	do
		dependentTier=CliqrTier_${j}_IP
		if [ "$cliqrExternalHttpsEnabled" == 1 ]; then
			dependentTier="CliqrTier_${j}_IP"
		fi

		dependentTierIPs=${!dependentTier}

		if [ ! -z $dependentTierIPs ]; then
			commaSeperatedIPs=$(echo $dependentTierIPs | tr "," "\n");               
			ipList=`echo $commaSeperatedIPs | tr "," "\n"`;
			for i in $ipList
			do
				if [ $i != "" ]; then
					#currently using only one IP -- needs to be extended to handle cluster 
					serverList="$i"
				fi
			done
		fi
	done
	sed -i "s/%CONTENT_SERVER%/$serverList/g" $1    
}

generateIptableRule() {
	ethName="$1"
	srcPort="$2"
	targetPort="$3"
	rule=" -A PREROUTING -i $ethName -p tcp -m tcp --dport $srcPort -j REDIRECT --to-ports $targetPort"

	echo "$rule"
}

getAllEthIfaces() {
	echo `ip -o link show | awk -F': ' '{print $2}' | grep -v lo`
}

generateIptableRuleForAllEth() {
	srcPort="$1"
	targetPort="$2"
	eths=`getAllEthIfaces`
	rules=""

	IFS=$' ' read -ra ETHS <<< "$eths"
	for eth in "${ETHS[@]}"
	do
		rules=$rules`generateIptableRule $eth $srcPort $targetPort`"\n"
	done

	echo "$rules"
}

uncommentConfig() {
	lines=$(cat -n $1 | grep "$2" | awk '{print $1}')
	i=0
	for line in $lines
	do
		i=$(( i+1 ))
		if [ $i == 1 ]; then
			start=$(( line+1 ))
		elif [ $i == 2 ]; then
		end=$(( line-1 ))
	fi
done;

range="$start,$end"
sed -i "$range s/#//g" $1
}

uncommentXml() {
	sed -i "/$2/d" $1
}

replaceToken() {
	sed -i "s,$2,$3,g" $1
}

replaceTierIpToken() {
	# sed -i "s, .*%\(.*\)_TIER_IP%.*,\$Cliqr\1IP,g" $1        
	# sed -i "s/%\(.*\)_TIER_IP%/\$Cliqr\1IP/g" $1

	# replace any token in the format %XYZ_TIER_IP% with $CliqrTier_XYZ_IP
	for token in `grep -oh %[^%]*_TIER_IP% $1`
	do
		temp1=$token

		# The below logic for replacing Ip from file in shared storage is for Clustered Databases.   
		tierName=`echo $temp1 | sed "s/%\(.*\)_TIER_IP%/\1/g"`
		SEED_IPLIST="/shared/output/$parentJobId/$tierName/ClusterConnectList"
		if [ -f $SEED_IPLIST ];
		then
			seedIp=`head -1 $SEED_IPLIST`
			sed -i "s/$token/$seedIp/g" $1
		else
			temp2=$`echo $temp1 | sed "s/%\(.*\)_TIER_IP%/CliqrTier_\1_IP/g"`
			temp3=`eval "echo $temp2"`           
			if [ ! -z $temp3 ]
			then
				sed -i "s/$token/$temp3/g" $1
			fi
		fi         

	done
}

rm_userenv_entries() {
	#remove entries from userenv
	sed -i "/appMigrating/d" $USER_ENV
	#sed -i "/cliqrDatabaseRootPass/d" $USER_ENV
	sed -i "/sqlDumpFileName/d" $USER_ENV
}

exit_error() {
	rm_userenv_entries;
	exit 127;
}

# deprecated method, no longer maintained
runMigrationRestoreScript() {
	return 0;
}

getFile() {
	url=$1
	destDir=$2
	depName=$3
	[ -d $destDir ] || mkdir -p $destDir
	curl $url > $destDir/$depName
}

#TODO - move it to appropriate file
mountSharedStorages(){

	sharedVolumePath="/shared";
	if [ -z "$SharedStorageMount" ]; then
		sharedVolumePath=$SharedStorageMount;
	fi

	if  mount -l|grep "on ${sharedVolumePath} type" > /dev/null
	then
		log "[STORAGE] Shared storage is already mounted."
	else
		source /usr/local/osmosix/etc/node.conf
		if [ -z $storageId ]; then
			log "[STORAGE] Node is not configued to have storage"
		else
			log "[STORAGE] shared storage is not mounted. Mounting now"
			mount -t glusterfs gluster1:/global /global
			if [ $? -ne 0 ]; then
				log "[STORAGE] Error while mounting global storage."
			else
				log "[STORAGE] Successfully mounted global storage"
			fi

			mount -t glusterfs gluster1:/$storageId $sharedVolumePath
			if [ $? -ne 0 ]; then
				log "[STORAGE] Error while mounting shared storage."
			else
				log "[STORAGE] Successfully mounted shared storage"
			fi
		fi
	fi
}

getUserName(){
	if [ -f "$OSMOSIX_HOME/etc/.user.name" ]
	then
		echo `cat $OSMOSIX_HOME/etc/.user.name`
	fi
}
