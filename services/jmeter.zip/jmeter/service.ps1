﻿#########################################################################
#	Powershell Service Script
#
#	Supported services:
#		- SQL Server 2008 R2 & SQL Server 2012
#		- IIS 7.x
#
#	Copyright(c) 2012 CliQr Technologies, Inc., all rights reserved.
#########################################################################

. 'c:\Program Files\osmosix\etc\cliqr.ps1'

$JMETER_TEST_PLAN_FILE=$testPlan
$JMETER_TEST_PLAN="c:\tmp\JmeterTestPlan.jmx";
$JMETER_LOG_FILE="c:\tmp\jmeter_log.jtl";
$JMETER_OUTPUT_FILE="c:\tmp\jmeterOutput.log";

##################################
# Service Routines
##################################


#######################
# Main service routines
#######################

function start_cmd {
		# Removing the preceding http/https for JMeter to work correctly
		BENCH_URL=$(echo $benchURL | % { $_ -replace "http://","" })
		BENCH_URL=$(echo $BENCH_URL | % { $_ -replace "https://","" })

        Log-Write "Replacing tokens with values"
		Copy-Item $JMETER_TEST_PLAN_FILE $JMETER_TEST_PLAN
    	Get-Content JMETER_TEST_PLAN | %{$_  -creplace '%BENCH_URL%', $BENCH_URL} | %{$_  -creplace '%NUM_USERS%', $jmeterNoOfUsers} | %{$_  -creplace '%RAMP_TIME%', $jmeterRampUpTime} | Set-Content $JMETER_TEST_PLAN
    	
    	log "Running the benchmark command"
		jmeter -n -t $JMETER_TEST_PLAN -l $JMETER_LOG_FILE
		log "Extracting the required info from the JMeter output file"
        Remove-Item $JMETER_OUTPUT_FILE -Recurse -Force
		Get-Content .\jmeter_log.jtl | %{ [int]$total+=$_.Split(',')[1]; } ; Write-Output "TotalTime: $total/1000" | Out-file -append $JMETER_OUTPUT_FILE
		Get-Content .\jmeter_log.jtl | %{ [int]$total+=$_.Split(',')[8]; } ; Write-Output "Bytes: $total" | Out-file -append $JMETER_OUTPUT_FILE
		Get-Content .\jmeter_log.jtl | %{ [int]$total+=$_.Split(',')[9]; } ; Write-Output "Latency: $total/1000" | Out-file -append $JMETER_OUTPUT_FILE
	}
}

function main([string] $cmd) {

	if (Test-Path 'c:\temp\userenv.ps1') {
		. 'c:\temp\userenv.ps1'
	} else {
		Log-Write "Missing user environment variables, service script exit..."
		$host.SetShouldExit(0)
		return
	}
	
	switch ($cmd) 
    {
        "start" { start_cmd; break }
    }
}

main $args
