export PATH=$PATH:/sbin:/usr/sbin
# cp -r /usr/local/osmosix/service/oracledb/dbscripts /tmp/
# dos2unix /usr/local/osmosix/service/oracledb/dbscripts/*

chmod 0777 /usr/local/osmosix/service/oracledb/dbscripts/*

chmod 0777 -R /usr/local/database

. /usr/local/osmosix/etc/userenv

. /usr/local/osmosix/etc/.osmosix.sh

export SID=$cliqrDatabaseSID

if [ -z $SID ];
        then
                log "No valid SID found via script";
                exit 0;
fi

export FolName=`echo $SID | tr '[:upper:]' '[:lower:]'`
export Uname=oracle
export Gname=oinstall
groupadd $Gname
useradd -g $Gname $Uname

privateIP=$OSMOSIX_PRIVATE_IP
export DBPORT=$cliqrDatabasePort
export DBPASS=$cliqrDatabaseRootPass


if [ -z $privateIP ];
	then
		log "No valid private Ip found via script";
		exit 127;
fi

replaceToken() {
        sed -i "s,$2,$3,g" $1
}

mkdir -p /usr/local/$FolName/oracle/product/112
mkdir -p /data/oracledb/data
mkdir -p /usr/local/$FolName/log
mkdir -p /data/oracledb/arch

chown -R $Uname:$Gname /usr/local/$FolName/
chown -R $Uname:$Gname /data/oracledb
export DB_HOME=/usr/local/$FolName/oracle/product/112
export DB_BASE=/usr/local/$FolName/log
export INSDB_RSP=/usr/local/osmosix/service/oracledb/dbscripts/installDb.rsp
export INS_DB=/usr/local/osmosix/service/oracledb/dbscripts/installDB.sh
export ORAINST=/usr/local/osmosix/service/oracledb/dbscripts/oraInst.loc

replaceToken $ORAINST "%Uname%" $Uname
replaceToken $ORAINST "%Gname%" $Gname
mv $ORAINST /etc/

replaceToken $INSDB_RSP "%Uname%" $Uname
replaceToken $INSDB_RSP "%Gname%" $Gname
replaceToken $INSDB_RSP "%DB_HOME%" $DB_HOME
replaceToken $INSDB_RSP "%DB_BASE%" $DB_BASE
replaceToken $INSDB_RSP "%SID%" $SID

unset DISPLAY
su $Uname -c "sh $INS_DB"
sh /usr/local/$FolName/oracle/product/112/root.sh

export BASHRC=/usr/local/osmosix/service/oracledb/dbscripts/bashrc
replaceToken $BASHRC "%FolName%" $FolName
replaceToken $BASHRC "%SID%" $SID
cat $BASHRC >> /home/$Uname/.bashrc

export NET_RSP=/usr/local/osmosix/service/oracledb/dbscripts/netca.rsp
export NETCA=/usr/local/osmosix/service/oracledb/dbscripts/netca.sh
replaceToken $NET_RSP "%DBPORT%" $DBPORT
su $Uname -c "sh $NETCA"

export DBCA=/usr/local/osmosix/service/oracledb/dbscripts/dbca.sh
su $Uname -c "sh $DBCA"

export RESET=/usr/local/osmosix/service/oracledb/dbscripts/reset.sh
replaceToken $RESET %cliqrDatabaseRootPass% $DBPASS
su $Uname -c "sh $RESET"

rm -rf /usr/local/database
exit 0
