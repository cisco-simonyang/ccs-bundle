source /home/$Uname/.bashrc
cd $ORACLE_HOME/bin
./netca /orahome $ORACLE_HOME /instype custom /inscomp client,oraclenet,javavm,server,ano /insprtcl tcp,tcps /cfg local /authadp NO_VALUE /nodeinfo NO_VALUE /responseFile $NET_RSP /silent