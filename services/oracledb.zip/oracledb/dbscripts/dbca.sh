source /home/$Uname/.bashrc
cd $ORACLE_HOME/bin
./dbca -silent -createDatabase -templateName General_Purpose.dbc -gdbName $SID -sid $SID -datafileJarLocation $ORACLE_HOME/assistants/dbca/templates -datafileDestination /data/oracledb/data -recoveryAreaDestination /data/oracledb/arch -responseFile NO_VALUE -characterset WE8ISO8859P1 -passwordDialog false -obfuscatedPasswords false -sysPassword $DBPASS -systemPassword $DBPASS -dbsnmpPassword $DBPASS -sysmanPassword $DBPASS -emConfiguration NONE
