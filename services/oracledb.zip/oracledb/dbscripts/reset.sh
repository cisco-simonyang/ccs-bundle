source /home/$Uname/.bashrc
echo "alter user system identified by %cliqrDatabaseRootPass%;" | sqlplus / as sysdba
exit