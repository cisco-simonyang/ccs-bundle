source /home/$Uname/.bashrc

echo startup | sqlplus / as sysdba
lsnrctl start
echo "alter user system identified by %DB_PASS%;" | sqlplus / as sysdba

exit
