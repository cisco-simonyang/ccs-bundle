source /home/$Uname/.bashrc
cd /usr/local/database
unset DISPLAY
./runInstaller -silent -ignoreSysPrereqs -nowait -waitForCompletion -noconfig -invPtrLoc /etc/oraInst.loc -responseFile $INSDB_RSP ORACLE_BASE=$DB_BASE oracle.install.db.InstallEdition=EE oracle.install.option=INSTALL_DB_SWONLY DECLINE_SECURITY_UPDATES=true  FROM_LOCATION=/usr/local/database/stage/products.xml ORACLE_HOME=$DB_HOME ORACLE_HOME_NAME=DB_HOME
