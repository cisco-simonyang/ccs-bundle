source /home/oracle/.bashrc

echo startup | sqlplus / as sysdba
lsnrctl start

exit
