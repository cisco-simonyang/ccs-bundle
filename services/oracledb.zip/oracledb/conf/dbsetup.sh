source /home/oracle/.bashrc

sqlplus system/%cliqrDatabaseRootPass% @%cliqrDBSetupScript%

exit
