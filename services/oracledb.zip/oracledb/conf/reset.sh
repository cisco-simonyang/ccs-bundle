source /home/oracle/.bashrc

echo "alter user system identified by %cliqrDatabaseRootPass%;" | sqlplus / as sysdba

exit
