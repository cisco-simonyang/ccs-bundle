source /home/oracle/.bashrc

echo shutdown | sqlplus / as sysdba
lsnrctl stop

exit