param (
    [string]$action = "migrate",
    [string]$brokerHost = "$env:brokerHost",
    [string]$brokerPort = "$env:brokerPort",
    [string]$brokerUser = "$env:brokerUser",
    [string]$brokerPassword = "$env:brokerPassword",
    [string]$bundleUser = "$env:bundleUser",
    [string]$bundlePassword = "$env:bundlePassword",
    [string]$agentBundlePath = "$env:agentBundlePath",
    [string]$cloudFamily = "$env:cloudFamily",
    [string]$agentMode = "$env:agentMode",
    [string]$vHost = "$env:vHost"
)

$TRANSCRIPT_FILE="C:\opt\agent_migrate_transcript.txt"
$AGENT_MIGRATE_LOG_FILE="C:\opt\agent_migrate.log"
#Writes to Log file and also echoes it to standard output
function WriteToMigrateLog([string] $logstring)
{
    Add-content $AGENT_MIGRATE_LOG_FILE -value "[$(Get-Date)] $logstring"
    #Don't use echo because it causes encoding issues
    #echo "$string" >> $AGENT_MIGRATE_LOG_FILE
    Write-Host "$logstring"
}

Start-Transcript -path $TRANSCRIPT_FILE -Append
WriteToMigrateLog 'Executing Agent-lite migration script'

$SERVICE_NAME = "AgentService"
$SYSTEM_DRIVE = (Get-WmiObject Win32_OperatingSystem).SystemDrive
. "$SYSTEM_DRIVE\temp\userenv.ps1"


##############################
# ZIP Utility Alias
##############################
function Unzip-File($file, $destination)
{
    $shell = new-object -com shell.application
    $zip = $shell.NameSpace($file)
    foreach($item in $zip.items())
    {
        $shell.Namespace($destination).copyhere($item,0x14)
    }
}

function extractProperty($propertyName)
{
    if(Test-Path $SYSTEM_DRIVE'\Program Files\agentlite\config\config.json') {
        $json = Get-Content $SYSTEM_DRIVE'\Program Files\agentlite\config\config.json' | Out-String | ConvertFrom-Json
        return $json.$propertyName
    }
    else {
        $json = Get-Content $SYSTEM_DRIVE'\opt\agentlite\config\config.json' | Out-String | ConvertFrom-Json
        return $json.$propertyName
    }

}

if ($brokerHost -eq 0 -or $brokerHost -eq $null -or $brokerHost -eq "") {
    WriteToMigrateLog "Variable brokerHost available in the env file"
    exit 1
}

if ($brokerPort -eq 0 -or $brokerPort -eq $null -or $brokerPort -eq "") {
    WriteToMigrateLog "Variable brokerPort available in the env file"
    exit 2
}

if ($brokerUser -eq 0 -or $brokerUser -eq $null -or $brokerUser -eq "") {
    WriteToMigrateLog "Variable brokerUser not available in the env file"
    exit 3
}

if ($brokerPassword -eq 0 -or $brokerPassword -eq $null -or $brokerPassword -eq "") {
    WriteToMigrateLog "Variable brokerPassword not available in the env file"
    exit 4
}

if ($cloudFamily -eq 0 -or $cloudFamily -eq $null -or $cloudFamily -eq "") {
    WriteToMigrateLog "Variable cloudFamily not available in the env file, extracting it from json"
    $cloudFamily = extractProperty("cloudFamily");
}

if ($agentMode -eq 0 -or $agentMode -eq $null -or $agentMode -eq "") {
    WriteToMigrateLog "Variable agentMode not available in the env file, defaulting it to greenfield"
    $agentMode = "greenfield";
}

if ($agentBundlePath -eq 0 -or $agentBundlePath -eq $null -or $agentBundlePath -eq "") {
    WriteToMigrateLog "Variable agentBundlePath not available in the env file"
    exit 6
}

if ($vHost -eq 0 -or $vHost -eq $null -or $vHost -eq "") {
    WriteToMigrateLog "Variable vHost not available in the env file"
    exit 7
}

if ($bundleUser -eq 0 -or $bundleUser -eq $null -or $bundleUser -eq "") {
    WriteToMigrateLog "Variable bundleUser not available in the env file"
}

if ($bundlePassword -eq 0 -or $bundlePassword -eq $null -or $bundlePassword -eq "") {
    WriteToMigrateLog "Variable bundlePassword not available in the env file"
}

if ($nodeId -eq 0 -or $nodeId -eq $null -or $nodeId -eq "") {
    WriteToMigrateLog "Variable nodeId not available in the env file defaulting it from the old config.json file"
    $nodeId = extractProperty("NodeId");
}

$SYSTEM_DRIVE = (Get-WmiObject Win32_OperatingSystem).SystemDrive
$AGENTGO_PARENT_DIR = "$SYSTEM_DRIVE\opt"
$AGENTGO_STAGE_PARENT_DIR="$SYSTEM_DRIVE\opt\cliqrstage\"

WriteToMigrateLog "Check if AgentGo Parent directory exists. If not create it: '$AGENTGO_PARENT_DIR'"
if (-not (Test-Path $AGENTGO_PARENT_DIR)) {
    WriteToMigrateLog "Create $AGENTGO_PARENT_DIR..."
    mkdir $AGENTGO_PARENT_DIR
}
else {
    WriteToMigrateLog "$AGENTGO_PARENT_DIR already exists."
}

WriteToMigrateLog "Check if Cliqr Stage directory exists. If not create it: '$AGENTGO_STAGE_PARENT_DIR'"
if (-not (Test-Path $AGENTGO_STAGE_PARENT_DIR)) {
    WriteToMigrateLog "Create $AGENTGO_STAGE_PARENT_DIR..."
    mkdir $AGENTGO_STAGE_PARENT_DIR
}
else {
    WriteToMigrateLog "Delete and recreate $AGENTGO_STAGE_PARENT_DIR"
    rm -force -recurse $AGENTGO_STAGE_PARENT_DIR
    mkdir $AGENTGO_STAGE_PARENT_DIR
}

$AGENT_BUNDLE_FILE = 'agent-lite-windows-bundle.zip'
$AGENT_BUNDLE_TEMP_PATH = "$SYSTEM_DRIVE\temp"

if (-not (Test-Path $AGENT_BUNDLE_TEMP_PATH)) {
    WriteToMigrateLog "Create $AGENT_BUNDLE_TEMP_PATH..."
    mkdir $AGENT_BUNDLE_TEMP_PATH
}

$AGENT_BUNDLE_DOWNLOAD_FLAG_FILE = "{0}\downloaded" -f $AGENT_BUNDLE_TEMP_PATH
$AGENT_INSTALLED_FILE = "{0}\Program Files\osmosix\etc\AGENTINSTALLED" -f $SYSTEM_DRIVE
$AGENT_APP_FILE = "{0}\opt\agentlite\.cliqrAppInstalled" -f $SYSTEM_DRIVE
$BOOTSTRAP_RESPONSE_FILE = "{0}\opt\agentlite\.bootstrapResponseQueue" -f $SYSTEM_DRIVE

$target = "{0}\{1}" -f $AGENT_BUNDLE_TEMP_PATH, $AGENT_BUNDLE_FILE

$client = New-Object System.Net.WebClient
if ($bundleUser -ne 0 -or $bundleUser -ne $null -or $bundleUser -ne "") {
    $client.Credentials = New-Object System.Net.Networkcredential($bundleUser, $bundlePassword)
}

if (Test-Path $AGENT_INSTALLED_FILE -PathType Any ) {
    WriteToMigrateLog "Delete $AGENT_INSTALLED_FILE file "
    rm -r $AGENT_INSTALLED_FILE
}

if (Test-Path $AGENT_APP_FILE -PathType Any ) {
    WriteToMigrateLog "Delete $AGENT_APP_FILE file "
    rm -r $AGENT_APP_FILE
}

if (Test-Path $BOOTSTRAP_RESPONSE_FILE -PathType Any ) {
    WriteToMigrateLog "Delete $BOOTSTRAP_RESPONSE_FILE file "
    rm -r $BOOTSTRAP_RESPONSE_FILE
}

if (Test-Path $AGENT_BUNDLE_DOWNLOAD_FLAG_FILE -PathType Any ) {
    WriteToMigrateLog "Delete $AGENT_BUNDLE_DOWNLOAD_FLAG_FILE file "
    rm -r $AGENT_BUNDLE_DOWNLOAD_FLAG_FILE
}

for ($i = 0; $i -lt 10; ++$i) {
    try {
        WriteToMigrateLog "Downloading agent bundle; attempt number: $i"
        $client.DownloadFile($agentBundlePath, $target)
        echo "" > $AGENT_BUNDLE_DOWNLOAD_FLAG_FILE
        break
    } catch [System.Exception] {
        WriteToMigrateLog "Error trying to download. Sleep for 10 seconds and retry till maximum retry limit of 10 is not reached"
        sleep 10
    }
}

if (Test-Path $AGENT_BUNDLE_DOWNLOAD_FLAG_FILE) {
    WriteToMigrateLog "Agent bundle download completed"
} else {
    WriteToMigrateLog "Agent bundle download timeout"
}

if (Test-Path $target) {
    WriteToMigrateLog "Agent bundle downloaded successfully"
} else {
    WriteToMigrateLog "Failed to download agent bundle, program exiting now"
    $host.SetShouldExit(1)
    return
}

$AGENTGO_PARENT_DIR = $AGENTGO_STAGE_PARENT_DIR

WriteToMigrateLog "Extracting agent bundle..."
Unzip-File $target $AGENTGO_PARENT_DIR

$AGENT_CONFIG_TEMPLATE="{0}\agentlite\config\config.template.json" -f $AGENTGO_PARENT_DIR
$confJson = Get-Content $AGENT_CONFIG_TEMPLATE | Out-String | ConvertFrom-Json
$confJson.AmqpUsername = "$brokerUser"
$confJson.AmqpPassword = "$brokerPassword"
$confJson.AmqpVHost = "$vHost"
$confJson.NodeId = "$nodeId"
$confJson.AmqpAddress = "$($brokerHost):$($brokerPort)"
$confJson.CloudFamily = "$cloudFamily"
$confJson.AgentInstallMode = "$agentMode"
$confJson | ConvertTo-Json | Set-Content $AGENT_CONFIG_TEMPLATE

$agent_version=(cat $AGENTGO_PARENT_DIR\agentlite\version)
$AGENT_INSTALLED_FILE_STAGE = "$AGENTGO_PARENT_DIR\agentlite\etc\AGENTINSTALLED"

WriteToMigrateLog "Initiate migrate for $agentMode ..."
if( $agentMode -eq "brownfield") {
    WriteToMigrateLog "Brownfield migration starting..."
    cp $AGENT_CONFIG_TEMPLATE $AGENTGO_PARENT_DIR\agentlite\config\config.json
    if(-not (Test-Path $AGENTGO_PARENT_DIR\agentlite\log)){
        mkdir $AGENTGO_PARENT_DIR\agentlite\log
    }
    $AGENT_UPGRADE_HOME="{0}\opt\agentlite-upgrade" -f $SYSTEM_DRIVE
    if(-not (Test-Path $AGENT_UPGRADE_HOME)){
        mkdir $AGENT_UPGRADE_HOME
    }
    echo $null >> $AGENT_UPGRADE_HOME\upgrade.log
    echo $null >> $AGENT_UPGRADE_HOME\upgrade.prop
    cp $AGENTGO_PARENT_DIR\agentlite\bin\agent-upgrade.bat $AGENTGO_PARENT_DIR
    $AGENT_SERVICE_NAME="AgentService"

    echo "Stop-Service $AGENT_SERVICE_NAME" > $AGENTGO_PARENT_DIR\exec.ps1
    echo "cmd /C `"$AGENTGO_PARENT_DIR\agent-upgrade.bat -actionExecutionId=$env:actionExecutionId -agentUpgradeStageDir=$AGENTGO_PARENT_DIR -actionResourceId=$env:actionResourceId -cloudResourceUniqueId=$env:cloudResourceUniqueId `"" >> $AGENTGO_PARENT_DIR\exec.ps1
    echo Start-Process -filepath `"powershell`" -argumentlist `"-executionpolicy bypass -noninteractive -file ```"$AGENTGO_PARENT_DIR\exec.ps1``
    Start-Process -filepath "powershell" -argumentlist "-executionpolicy bypass -noninteractive -file `"$AGENTGO_PARENT_DIR\exec.ps1`""
}
else{
    WriteToMigrateLog "Greenfield migration starting..."
    $USER_DATA_FILE = "{0}\Program Files\osmosix\etc\user-data" -f $SYSTEM_DRIVE
    $USER_DATA_FILE_PRE_MIG_BAKUP = "{0}\Program Files\osmosix\etc\user-data.pre-mig.bak" -f $SYSTEM_DRIVE
    WriteToMigrateLog "Backup the user-data file before modifying it. Copy it from $USER_DATA_FILE to $USER_DATA_FILE_PRE_MIG_BAKUP..."
    Copy-item -path $USER_DATA_FILE -destination $USER_DATA_FILE_PRE_MIG_BAKUP -force

    WriteToMigrateLog "Update the user-data with new values of vHost: $vHost and broker IP-Port: $($brokerHost):$($brokerPort)..."
    $userDataJson = Get-Content $USER_DATA_FILE | Out-String | ConvertFrom-Json
    $userDataJson.brokerClusterAddresses = "$($brokerHost):$($brokerPort)"
    $userDataJson.brokerVirtualHost = "$vHost"
    $userDataJson | ConvertTo-Json | Set-Content $USER_DATA_FILE

    echo ""> $AGENT_INSTALLED_FILE
    echo ""> $AGENT_INSTALLED_FILE_STAGE
    echo Start-Process -filepath `"powershell`" -argumentlist `"-executionpolicy bypass -noninteractive -file ```"$AGENTGO_PARENT_DIR\agentlite\bin\install.ps1```" -brokerHost $brokerHost -brokerPort $brokerPort -cloudFamily $cloudFamily -nodeId $nodeId -agentMode $agentMode -action migrate -brokerVHost ''`"
    Start-Process -filepath "powershell" -argumentlist "-executionpolicy bypass -noninteractive -file `"$AGENTGO_PARENT_DIR\agentlite\bin\install.ps1`" -brokerHost $brokerHost -brokerPort $brokerPort -cloudFamily $cloudFamily -nodeId $nodeId -agentMode $agentMode -action migrate -brokerVHost ''"
}


WriteToMigrateLog "Agent migration started"
Stop-Transcript
