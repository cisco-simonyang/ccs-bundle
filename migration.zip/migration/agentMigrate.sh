#!/bin/bash

#Write to system log as well as to terminal
logWrite()
{
	msg=$1
	echo "$(date) ${msg}"
	logger -t "OSMOSIX" "${msg}"
	return 0
}


logWrite "Starting agent migrate..."

env_file="/usr/local/osmosix/etc/userenv"
if [ -f $env_file ];
then
	logWrite "Source the userenv file..."
	. $env_file
fi

export action="migrate"

if [ -z $nodeId ];
then
	logWrite "NodeId is not passed as action parameter defaulting it from the existing config.json"
	export nodeId=$(cat /usr/local/agentlite/config/config.json | grep -i nodeId | awk -F \" '{print $4}' 2>/dev/null)
	if [ -z $nodeId ];
	then
	    logWrite "Couldn't get the nodeId value from existing config"
	    exit 2;
	fi
fi

if [ -z $brokerHost ];
then
	logWrite "Broker Host / Rabbit Server Ip not passed as action parameter"
	exit 3;
fi

if [ -z $brokerPort ];
then
	logWrite "Broker Port / Rabbit Server Port not passed as action parameter, defaulting it to 5671"
	export brokerPort="5671"
fi

if [ -z $brokerUser ];
then
	logWrite "Broker User / Rabbit Username not passed as action parameter"
	exit 4;
fi

if [ -z $brokerPassword ];
then
	logWrite "Broker User brokerPassword / Rabbit User's Password not passed as action parameter"
	exit 5;
fi

if [ -z $agentBundlePath ];
then
	logWrite "Agent Bundle complete path is not passed as action parameter"
	exit 6;
fi

if [ -z $agentMode ];
then
    logWrite "Agent Mode is not passed defaulting it to greenfield"
    export agentMode="greenfield";
fi

if [ -z $bundleUser ] || [ -z $bundlePassword ];then
    logWrite "No credentials provided for bundle store."
else
    logWrite "Consuming the given bundle credentials"
    OSMOSIX_CURL_CREDENTIAL="-u $bundleUser:$bundlePassword"
    OSMOSIX_WGET_CREDENTIAL="--user $bundleUser:$bundlePassword"
fi

if [ -z $cloudFamily ];
then
	logWrite "Cloud Family is not passed as action parameter defaulting it from the CloudFamily value in /usr/local/agentlite/config/config.json file"
	export cloudFamily=$(cat /usr/local/agentlite/config/config.json | grep -i cloudFamily | awk -F \" '{print $4}' 2>/dev/null)

fi

cleanupOldJavaAgent(){
	logWrite "Stop any existing c3agent service and remove agent installed marker..."
	if [ -f /etc/init.d/c3agent ]; then
		logWrite "Stopping c3agent..."
		/etc/init.d/c3agent stop
		rm -f $AGENT_INSTALLED_FILE
	fi
	logWrite "Stop any existing jetty service..."
	if [ -f /etc/init.d/jetty ]; then
		logWrite "Stopping jetty..."
		/etc/init.d/jetty stop
		rm -f $AGENT_INSTALLED_FILE
	fi
}

createWatchmeScript() {
	logWrite "Creating watchme script"

	echo "#!/bin/bash" > $WATCHME_SCRIPT
	echo "while true; do" >> $WATCHME_SCRIPT
	echo "    sleep 60" >> $WATCHME_SCRIPT
	echo "    if [ -f /root/.done ]; then" >> $WATCHME_SCRIPT
	echo "        exit 0" >> $WATCHME_SCRIPT
	echo "    fi" >> $WATCHME_SCRIPT
	echo "    pid=\`ps aux | grep \"$WATCHME_REGEX\" | grep -v \"grep\" | awk '{print \$2}'\`" >> $WATCHME_SCRIPT
	echo "    kill -9 \$pid" >> $WATCHME_SCRIPT
	echo "    rm -rf $AGENT_BUNDLE_FILE" >> $WATCHME_SCRIPT
	echo "    $AGENT_BUNDLE_DOWNLOAD_CMD" >> $WATCHME_SCRIPT
	echo "    touch /root/.done" >> $WATCHME_SCRIPT
	echo "done" >> $WATCHME_SCRIPT

	chmod +x $WATCHME_SCRIPT
	$WATCHME_SCRIPT &
}

replaceUserdataValue() {
	key=$1
	value=$2

	if [ -z $key ] || [ -z $value ];
	then
		logWrite "Command line arguments missing to update user-data file, key: $key, value:$value"
		return
	fi

	USER_DATA_FILE="/usr/local/osmosix/etc/user-data"
	if [ -f $USER_DATA_FILE ];
	then
		json_content=`cat $USER_DATA_FILE`
		old_value=`echo $json_content | awk -F $key '{print $2}' | awk -F \" '{print $3}'`
		sed  -i 's@'"$old_value"'@'"$value"'@g'  $USER_DATA_FILE
	fi

}

export AGENT_HOME="/usr/local/agentlite"
export STAGE_DIR='/usr/local/cliqrstage'

if [ -d $STAGE_DIR ];
then
	logWrite "AgentLite Staging directory ${STAGE_DIR} already exists, removing it"
	rm -rf $STAGE_DIR
fi

AGENTGO_UPGRADE_INPUT_FILE=${STAGE_DIR}/agentlite/bin/agentgo_upgrade_input
SYS_OSMOSIX_DIR='/usr/local/agentlite'
AGENT_INSTALLED_FILE=${SYS_OSMOSIX_DIR}/etc/.AGENTINSTALLED
isAgentFlavorLite="true"

cleanupOldJavaAgent

AGENT_BUNDLE_URL=${agentBundlePath}
logWrite "Agent Bundle URL is : $AGENT_BUNDLE_URL"

AGENT_BUNDLE_FILE=/root/osmosix-agent.tar.gz

if [ -f $AGENT_BUNDLE_FILE ];
then
	logWrite "Moving the existing agent bundle to .bkp file"
	mv -f $AGENT_BUNDLE_FILE $AGENT_BUNDLE_FILE.bkp
fi

AGENT_BUNDLE_DOWNLOAD_CMD=''
AGENT_BUNDLE_DOWNLOAD_CURL_CMD="curl ${OSMOSIX_CURL_CREDENTIAL} -o ${AGENT_BUNDLE_FILE} ${AGENT_BUNDLE_URL}"
AGENT_BUNDLE_DOWNLOAD_WGET_CMD="wget ${OSMOSIX_WGET_CREDENTIAL} -O ${AGENT_BUNDLE_FILE} ${AGENT_BUNDLE_URL}"

WATCHME_SCRIPT=/root/watchme.sh
WATCHME_REGEX=''
WATCHME_REGEX_WGET="wget.* -O $AGENT_BUNDLE_FILE"
WATCHME_REGEX_CURL="curl.* -o $AGENT_BUNDLE_FILE"

logWrite "Check and choose curl or wget based on availability..."
if [ -x "$(command -v curl)" ]; then
	logWrite "cURL will be used to download Agent Bundle..."
	AGENT_BUNDLE_DOWNLOAD_CMD=${AGENT_BUNDLE_DOWNLOAD_CURL_CMD}
	WATCHME_REGEX=${WATCHME_REGEX_CURL}
elif [ -x "$(command -v wget)" ]; then
	logWrite "wget will be used to download Agent Bundle..."
	AGENT_BUNDLE_DOWNLOAD_CMD=${AGENT_BUNDLE_DOWNLOAD_WGET_CMD}
	WATCHME_REGEX=${WATCHME_REGEX_WGET}
else
	logWrite "No curl or wget found. Cannot install Agent because $AGENT_BUNDLE_URL can't be downloaded."
	logWrite "Use an image which has cURL or wget available."
	exit 1
fi

createWatchmeScript
logWrite "Downloading bundle: [${AGENT_BUNDLE_URL}] using command: [${AGENT_BUNDLE_DOWNLOAD_CMD}]"
AGENT_BUNDLE_URL="${AGENT_BUNDLE_URL#"${AGENT_BUNDLE_URL%%[![:space:]]*}"}"   # remove leading whitespace
AGENT_BUNDLE_URL="${AGENT_BUNDLE_URL%"${AGENT_BUNDLE_URL##*[![:space:]]}"}"   # remove trailing whitespace

logWrite "Downloading bundle, post removing whitespaces in URL: ${AGENT_BUNDLE_URL} using command: ${AGENT_BUNDLE_DOWNLOAD_CMD}"
${AGENT_BUNDLE_DOWNLOAD_CMD}  &>/root/checkDown.txt

#/root/.done is tracked by the watchme() thread
if [ $? -eq 0 ]; then
	touch /root/.done
else
	while true; do
		if  [ -f /root/.done ]; then
			break
		fi
		sleep 3
	done
fi

#Check Agent Bundle has size > 0
if [ ! -s $AGENT_BUNDLE_FILE ]; then
	logWrite "Downloaded empty bundle file $AGENT_BUNDLE_FILE ..Aborting"
	exit 1
fi

#Check File Type is tar.gz
fileType=$(file -b ${AGENT_BUNDLE_FILE})
echo $fileType
if [[ $fileType == "gzip compressed data"*  ]];then
    echo "Agent bundle is a valid tar.gz file"
else
    echo "ERROR: Agent bundle is not a valid tar.gz file"
    exit 1
fi


extractBundleInstallAgent () {

	logWrite "Extract Agent Bundle and invoke install/upgrade script"

	if [[ ! -d ${STAGE_DIR} ]]; then
	  mkdir -p ${STAGE_DIR}
	fi
	logWrite "Change directory to the Stage directory: ${STAGE_DIR}..."
	cd ${STAGE_DIR}

	currDir=$(pwd)
	logWrite "Extract Agent Bundle file: $AGENT_BUNDLE_FILE in current directory (stage directory): $currDir"
	tar xzf $AGENT_BUNDLE_FILE > /root/bunextract.txt
	logWrite "Agent Bundle extracted. Check output in /root/bunextract.txt"

	# We create agent install marker prior to calling agent start script
	# to avoid a race condition where agent install may be called twice
	touch $AGENT_INSTALLED_FILE

	export OSMOSIX_CLOUD=${cloudFamily}
	export AGENT_VERSION=$(cat agentlite/version 2>/dev/null)

	AGENT_STAGE_DIR=${STAGE_DIR}/agentlite
	AGENT_STAGE_CONFIG_FILE_TEMPLATE=$AGENT_STAGE_DIR/config/config.template.json

	logWrite "Agent Migration: Action: $action, AgentVersion: $AGENT_VERSION, Cloud Family: $OSMOSIX_CLOUD"
	logWrite "Update the Config file of the staged new agent with BrokerUser: ${brokerUser}, BrokerPassword, AmqpVHost: ${vHost}, NodeID: ${nodeId}..."
	sed -i '/AmqpUsername/c\    "AmqpUsername": "'"${brokerUser}"'",' ${AGENT_STAGE_CONFIG_FILE_TEMPLATE}
	sed -i '/AmqpPassword/c\    "AmqpPassword": "'"${brokerPassword}"'",' ${AGENT_STAGE_CONFIG_FILE_TEMPLATE}
	sed -i '/AmqpVHost/c\    "AmqpVHost": "'"${vHost}"'",' ${AGENT_STAGE_CONFIG_FILE_TEMPLATE}
	sed -i '/NodeId/c\    "NodeId": "'"${nodeId}"'",' ${AGENT_STAGE_CONFIG_FILE_TEMPLATE}

	logWrite "Delete existing bootstrap response queue: /usr/local/agentlite/.bootstrapResponseQueue ..."
	rm -f /usr/local/agentlite/.bootstrapResponseQueue

	if [[ "$agentMode" == "brownfield" ]];
	then
		logWrite "Brownfield migrate case: Upgrade the agent..."
		sed -i '/AmqpAddress/c\    "AmqpAddress": "'"${brokerHost}:${brokerPort}"'",' ${AGENT_STAGE_CONFIG_FILE_TEMPLATE}
		sed -i '/CloudFamily/c\    "CloudFamily": "'"${OSMOSIX_CLOUD}"'",' ${AGENT_STAGE_CONFIG_FILE_TEMPLATE}
		sed -i '/AgentInstallMode/c\    "AgentInstallMode": "'"${agentMode}"'",' ${AGENT_STAGE_CONFIG_FILE_TEMPLATE}
		cp ${AGENT_STAGE_CONFIG_FILE_TEMPLATE} ${AGENT_STAGE_DIR}/config/config.json
		cp ${AGENT_STAGE_DIR}/bin/agent-upgrade.sh ${STAGE_DIR}
		mkdir -p ${AGENT_STAGE_DIR}/log

		mkdir -p /usr/local/agentlite-upgrade
		touch /usr/local/agentlite-upgrade/upgrade.log
		touch /usr/local/agentlite-upgrade/upgrade.prop

		logWrite "Brownfield case: Create execute.sh which will be executed to upgrade the agent post a 90 sec sleep..."
		echo "echo \"Sleep 90 sec...\"" > execute.sh
		echo "sleep 90" >> execute.sh
		echo "/usr/local/agentlite/bin/agent-stop.sh" >> execute.sh
		echo "${STAGE_DIR}/agent-upgrade.sh $actionExecutionId ${STAGE_DIR} $actionResourceId $cloudResourceUniqueId" >> execute.sh
		chmod a+x execute.sh
		nohup bash execute.sh  > /dev/null 2>&1 &
	else
		logWrite "Greenfield migrate case"

		#logWrite "Delete existing App installed marker file : /usr/local/agentlite/.cliqrAppInstalled ..."
		#rm -f /usr/local/agentlite/.cliqrAppInstalled

		USER_DATA_FILE="/usr/local/osmosix/etc/user-data"
		USER_DATA_FILE_PRE_MIG_BAKUP="/usr/local/osmosix/etc/user-data.pre-mig.bak"
		logWrite "Backup the user-data file before modifying it. Copy it from $USER_DATA_FILE to $USER_DATA_FILE_PRE_MIG_BAKUP..."
		cp $USER_DATA_FILE $USER_DATA_FILE_PRE_MIG_BAKUP

		logWrite "Update the user-data with new values of vHost: ${vHost} and broker IP-Port: $brokerHost:$brokerPort..."
		replaceUserdataValue "brokerVirtualHost" "$vHost"
		replaceUserdataValue "brokerClusterAddresses" "$brokerHost:$brokerPort"

		c3agent_init_script='agentlite/bin/install'
		logWrite "Init script to be used: ${STAGE_DIR}/$c3agent_init_script"
		chmod 755 ${c3agent_init_script}

		logWrite "Create execute.sh which will be executed to upgrade the agent post a 90 sec sleep..."
		echo "echo \"Sleep 90 sec...\"" > execute.sh
		echo "sleep 90" >> execute.sh
		logWrite "Execute the Install agent using values: ${c3agent_init_script}, ${brokerHost}, ${vHost}, ${nodeId}, ${OSMOSIX_CLOUD}, ${agentMode}, ${action}"
		echo "echo \"Woke up. Execute the Install agent using values: ${c3agent_init_script}, ${brokerHost}, ${vHost}, ${nodeId}, ${OSMOSIX_CLOUD}, ${agentMode}, ${action}\"" >> execute.sh
		echo "${c3agent_init_script} -bh ${brokerHost} -bp ${brokerPort} --brokerVHost ${vHost} -n ${nodeId} -c ${OSMOSIX_CLOUD} -m ${agentMode} -a ${action} -S " >> execute.sh
		chmod a+x execute.sh
		nohup bash execute.sh  > /dev/null 2>&1 &
		logWrite $(ls -la /usr/local/agentlite/)
	fi
	logWrite "Started execution of migrate action asynchronously..."
	return 0
}


logWrite "Extract Agent bundle and start installation..."
extractBundleInstallAgent

logWrite "Create marker file: $AGENT_INSTALLED_FILE"
touch $AGENT_INSTALLED_FILE

logWrite "Agent Migrate script executed. Track agent installation via system/agent logs and process list.."
logWrite "Exit agentMigrate action script"
exit 0
