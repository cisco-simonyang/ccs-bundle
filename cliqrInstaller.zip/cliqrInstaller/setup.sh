#!/bin/bash



get_final_os () {


  echo $os | grep centos6 >> /dev/null
  if [[ $? -eq 0 ]]; then
    os_ver=$(echo $os | sed 's/centos//')
    if [[ $os_ver == '6' ]];then
      os_ver='6.5'
    fi
    os='centos6'
  fi

  echo $os | grep centos8 >> /dev/null
  if [[ $? -eq 0 ]]; then
    os_ver=$(echo $os | sed 's/centos//')
    if [[ $os_ver == '8' ]];then
      os_ver='8.0'
    fi
    os='centos8'
  fi

  echo $os | grep centos7 >> /dev/null
  if [[ $? -eq 0 ]]; then
    os_ver=$(echo $os | sed 's/centos//')
    if [[ $os_ver == '7' ]];then
      os_ver='7.0'
    fi
    os='centos7'
  fi

  echo $os | grep centos5 >> /dev/null
  if [[ $? -eq 0 ]]; then
    os_ver=$(echo $os | sed 's/centos//')
    if [[ $os_ver == '5' ]];then
      os_ver='5.10'
    fi
    os='centos5'
  fi

  echo $os | grep rhel5 >> /dev/null
  if [[ $? -eq 0 ]]; then
    os_ver=$(echo $os | sed 's/rhel//')
    if [[ $os_ver == '5' ]];then
      os_ver='5.10'
    fi
    os='rhel5'
  fi

  echo $os | grep rhel6 >> /dev/null
  if [[ $? -eq 0 ]]; then
    os_ver=$(echo $os | sed 's/rhel//')
    if [[ $os_ver == '6' ]];then
      os_ver='6.5'
    fi
    os='rhel6'
  fi

  echo $os | grep rhel7 >> /dev/null
  if [[ $? -eq 0 ]]; then
    os_ver=$(echo $os | sed 's/rhel//')
    if [[ $os_ver == '7' ]];then
      os_ver='7.0'
    fi
    os='rhel7'
  fi

  echo $os | grep rhel8 >> /dev/null
  if [[ $? -eq 0 ]]; then
    os_ver=$(echo $os | sed 's/rhel//')
    if [[ $os_ver == '8' ]];then
      os_ver='8.0'
    fi
    os='rhel8'
  fi

  echo $os | grep oel5 >> /dev/null
  if [[ $? -eq 0 ]]; then
    os_ver=$(echo $os | sed 's/oel//')
    if [[ $os_ver == '5' ]];then
      os_ver='5.10'
    fi
    os='oel5'
  fi

  echo $os | grep oel6 >> /dev/null
  if [[ $? -eq 0 ]]; then
    os_ver=$(echo $os | sed 's/oel//')
    if [[ $os_ver == '6' ]];then
      os_ver='6.5'
    fi
    os='oel6'
  fi

  echo $os | grep suse12 >> /dev/null
    if [[ $? -eq 0 ]]; then
      os_ver=$(echo $os | sed 's/suse//')
      if [[ $os_ver == '12' ]];then
        os_ver='12'
      fi
      os='suse12'
    fi

     echo $os | grep suse11 >> /dev/null
    if [[ $? -eq 0 ]]; then
      os_ver=$(echo $os | sed 's/suse//')
      if [[ $os_ver == '11' ]];then
        os_ver='11'
      fi
      os='suse11'
    fi

}

usage() {
    echo "Usage: worker_installer.bin <OS> <Cloud> <Module-type>"
    echo "Supported OS     : rhel6 | rhel7 | rhel8 | oel6 | centos6 | centos7 | ubuntu1404 | ubuntu1604 | ubuntu1804 | amazon | suse11| suse12 "
    echo "Supported Cloud  : alibaba | amazon |  azurerm | azurepack | azurestack | custom | google | hpcloud | opsource | openstack  | rackspace | softlayer | vmware | vcd"
    echo "Supported Modules: worker1 | worker_basic | <file with custom list of modules>"
    echo "Custom Cloud Type: <requires /usr/local/metadata_extractor.sh; /usr/local/userdata_extractor.sh; scripts>"
    exit 1
}

# main

if [[ $# -ne 3 ]]; then
    usage
fi

os=$1
cloud=$2
module_type=$3

if [[ ${cloud} == "azureclassic" ]]; then
  cloud=azure
fi

if [[ ${cloud} == "custom" ]]; then
  METADATA_EXTRACTOR="/usr/local/metadata_extractor.sh"
  USERDATA_EXTRACTOR="/usr/local/userdata_extractor.sh"

  if [[ ! -f "$METADATA_EXTRACTOR" || ! -f "$USERDATA_EXTRACTOR" ]]; then
    usage
  fi
fi

if [[ -z $CUSTOM_REPO ]]; then
  CUSTOM_REPO=default
else
  # Remove trailing slash
  CUSTOM_REPO=$(echo $CUSTOM_REPO | sed 's?/$??')
  echo $CUSTOM_REPO | grep  'https\?://' >> /dev/null 2>&1
  if [[ $? -ne 0 ]]; then
    echo "Provide http or https as protocol argument to CUSTOM_REPO"
    exit 1
  fi
fi

if [[ -z $BINARY_REPO ]]; then
  BINARY_REPO=default
else
  # Remove trailing slash
  BINARY_REPO=$(echo $BINARY_REPO | sed 's?/$??')
  echo $BINARY_REPO | grep  'https\?://' >> /dev/null 2>&1
  if [[ $? -ne 0 ]]; then
    echo "Provide http or https as protocol argument to BINARY_REPO"
    exit 1
  fi
fi

export CUSTOM_REPO
export BINARY_REPO
export arch='64'
os_ver=''

get_final_os
export os
export os_ver

if  [ $os != "rhel5" ] && [ $os != "centos6" ] && [ $os != "centos5" ] && [ $os != "amazon" ] &&  [ $os != "rhel6" ]  && [ $os != "oel6" ] && [ $os != "centos7" ] && [ $os != "ubuntu1404" ] &&  [ $os != "rhel7" ] && [ $os != "ubuntu1604" ] && [ $os != "ubuntu1804" ] && [ $os != "suse11" ] && [ $os != "suse12" ] && [ $os != "rhel8" ]
then
    usage
fi


root_dir="$( cd "$( dirname $0 )" && pwd )"
tmp_dir='/tmp'
module_info='/etc/cliqr_modules.conf'
if [[ ! -f ${module_info} ]]; then
  touch ${module_info}
fi



##FUNCTION###############################
# name - check_error
# 	 Check for exit status
# 	 Error out if failure
###########################################
check_error()
{
	status=$1
	msg=$2
	exit_status=$3

	if [ $status -ne 0 ]
	then
		echo -e "\033[31m 	$msg \033[0m"
		exit $exit_status
	fi

	return 0
}


##FUNCTION################################################################
# name - install_module
##########################################################################
install_module () {
	module=$1
	module_dir=${root_dir}'/modules/'$module
	# module_log=${tmp_dir}'/cliqr_modules.log'
	module_log='/root/cliqr_modules.log'

        grep -w ${module} ${module_info} > /dev/null 2>&1
        if [[ $? -eq 0 ]]; then
	  echo -e "\033[36m 	Module already installed: $module \033[0m"
	  return 0
	fi

	bash installer.sh $os $arch $cloud $module >> $module_log 2>&1
	status=$?
	check_error $status  "Failed in $module. Check /root/cliqr_modules.log for more info" 1
	echo $module >> ${module_info}

	return 0
}

##FUNCTION################################################################
# name - run_modules
# 	 Iterate over modules listed in the image type file
# 	 Call installer to install the modules
##########################################################################
run_modules () {

	module_list=${root_dir}'/'${module_type}'.list'
	if  [ $module_type != "gateway" ] && [ $module_type  != "gluster" ] && [ $module_type != "worker0" ] && [ $module_type != "worker1" ] &&  [ $module_type != 'nfs' ] && [ $module_type != "mgmtserver" ] && [ $module_type != "worker_basic" ] 
	then
		module_list=../$module_type
		module_type="Custom Module"
	fi


	export MODULE_TYPE=${module_type}

	if [ ! -f $module_list ]
	then
		echo "Modules list not found for type $module_type"
		exit 1
	fi

  	# Do not do cleanup till explicitly asked for
  	if [[ $cleanup_module == "true" ]]; then
	   export cleanup_module=true
	else
	  export cleanup_module=false
	fi


	for each_mod in `cat $module_list`
	do
		module_enabled=$(eval echo \$${each_mod}_module)
	 	if [[ $module_enabled == "false" ]]; then
		  echo -e "\033[36m 	Skipping Module: $each_mod \033[0m"
  		else
		  echo -e "\033[32m 	Installing Module: $each_mod \033[0m"
		  install_module "$each_mod"
		fi
	done


	return 0
}


##FUNCTION################################################################
# name - restore_repo
# 	 Restore repo files backed up during install with custom repo
##########################################################################
restore_repo () {
  if [[ $CUSTOM_REPO == default ]]; then
    return 0
  fi

  if [[ -d /etc/yum.repos.d/backup_cliqr ]]; then
    cd  /etc/yum.repos.d/
    mv backup_cliqr/* .
    rmdir backup_cliqr
  fi

  # Remove repo file so that cloudrepo is not considered for
  # package installs
  if [[ -f  /etc/yum.repos.d/cloudrepo.repo ]]; then
    rm -f /etc/yum.repos.d/cloudrepo.repo
  fi

}

run_modules
restore_repo

exit 0
