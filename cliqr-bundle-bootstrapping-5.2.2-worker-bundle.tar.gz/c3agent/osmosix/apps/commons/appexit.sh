#!/bin/bash

ExitOnFinish=$1
ExitFile=$2

if [ "$ExitOnFinish" == true ]; then
	exit 0
fi

while true; do
	if [ -f "$ExitFile" ]; then
		break
	fi
	sleep 5
done
