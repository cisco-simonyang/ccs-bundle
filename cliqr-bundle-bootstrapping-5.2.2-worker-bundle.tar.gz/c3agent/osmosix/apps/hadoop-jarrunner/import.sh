#!/bin/bash

LocalInputPath=$1
HadoopInputPath=$2

if [ "$DataImportExport" == "false" ]; then
	logger -t "OSMOSIX" "[hadoop] data import skipped"
	exit 0
fi

#[ "`cat /tmp/hadoop.role`" != "mgmt" ] && exit 0
logger -t "OSMOSIX" "[hadoop] importing local path $LocalInputPath to hadoop path $HadoopInputPath"
hadoop fs -rm -r $HadoopInputPath
hadoop fs -mkdir $HadoopInputPath
hadoop fs -put $LocalInputPath/* $HadoopInputPath
logger -t "OSMOSIX" "[hadoop] importing completed"

