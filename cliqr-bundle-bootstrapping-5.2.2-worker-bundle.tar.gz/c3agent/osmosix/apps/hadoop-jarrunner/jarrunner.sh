#!/bin/bash

#[ "`cat /tmp/hadoop.role`" != "mgmt" ] && exit 0
logger -t "OSMOSIX" "[hadoop jarrunner] executing hadoop command: jar $*"
hadoop jar $*
logger -t "OSMOSIX" "[hadoop jarrunner] done"
