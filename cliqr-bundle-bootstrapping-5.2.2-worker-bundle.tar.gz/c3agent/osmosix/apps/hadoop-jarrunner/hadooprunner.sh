#!/bin/bash

###########################################################
# Hadoop Command Runner
#
# Copyright(c) 2012 Osmosix, Inc., All rights reserved.
###########################################################

HadoopExecType=$1
shift

case "HadoopExecType" in
	Jar)
		cmd="hadoop jar $@"
		;;
	Pig)
		cmd="pig $@"
		;;
	Streaming)
		cmd="hadoop jar /usr/lib/hadoop/contrib/streaming/hadoop-streaming*.jar $@"
		;;
	Hive)
		cmd="hive $@"
		;;
	*)
		exit 1
		;;
esac

retStr=`eval $cmd`
exitVal=`echo $?`

logger -t "OSMOSIX" "command executed: $cmd [1/3]"
logger -t "OSMOSIX" "Exit code: $exitValue [2/3]"
logger -t "OSMOSIX" "Command line return: $retStr [3/3]"

if [ "$exitVal" != "0" ]; then
	exit 2
fi
