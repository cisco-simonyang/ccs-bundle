#!/bin/bash

. /usr/local/osmosix/etc/userenv

#Port
httpPort=5815
agentRootPath=http://localhost:$httpPort/agent

download() {
    if [ -z $2 ]; then
        path=$1
        request="$agentRootPath/repository/download?path=$path"
    else
        path=$1
        paramName=$2
        mappedName=`mapToSystemKey $paramName`
        [ ! -z $mappedName ] && paramName=$mappedName
        request="$agentRootPath/repository/$paramName/download?path=$path"
    fi
    logger -t "OSMOSIX" "Download: $request"
    curl -f "$request" 2>/dev/null
    if [ $? != 0 ]; then
        echo "Failed to download: $request"
        exit 127
    fi
}

uploadFile() {
    path=$1
    paramName=$2
    mappedName=`mapToSystemKey $paramName`
    [ ! -z $mappedName ] && paramName=$mappedName
    localFile=$3
    request="$agentRootPath/repository/$paramName/upload?path=$path&localFile=$localFile"

    curl -f "$request" 2>/dev/null

    if [ $? != 0 ]; then
        echo "Failed to upload to $path"
        exit 127
    fi
}

restoreFile() {
    path=$1
    request="$agentRootPath/repository/restore?path=$path"

    curl -f "$request" 2>/dev/null

    if [ $? != 0 ]; then
        echo "Failed to restore $path"
        exit 127
    fi
}

backupFile() {
    path=$1
    localFile=$2

    if [ $JOB_EXPORT_REQUEST_ID ]; then
        request="$agentRootPath/repository/export?path=$path&localFile=$localFile&jobExportRequestId=$JOB_EXPORT_REQUEST_ID"
    else 
        request="$agentRootPath/repository/backup?path=$path&localFile=$localFile"
    fi

    curl -f "$request" 2>/dev/null

    if [ $? != 0 ]; then
        echo "Failed to backup $localFile to remote repository"
        exit 127
    fi
}

getStorageServerPasscode() {
    request=$agentRootPath/storage/passcode
    curl -f "$request" 2>/dev/null
    if [ $? != 0 ]; then
        echo "Failed to get storage server passcode"
        exit 127
    fi
}

mapToSystemKey() {
    svc=`echo ${OSSVC_CONFIG:0:1} | tr [:lower:] [:upper:]``echo ${OSSVC_CONFIG:1} | tr [:upper:] [:lower:]`
    acceptKeys=(prestart poststart prestop poststop)
    systemKeys=(cliqr${svc}PreStartAction cliqr${svc}PostStartAction cliqr${svc}PreStopAction cliqr${svc}PostStopAction)
    userKey=`echo $1 | tr [:upper:] [:lower:]`
    for index in ${!acceptKeys[*]}
    do
        if [ ${acceptKeys[$index]} == $userKey ]; then
            echo ${systemKeys[$index]}
        fi
    done
}
