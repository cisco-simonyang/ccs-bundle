#!/bin/bash -x
#*******************************************************************************
#  Copyright (c) 2010-2014 Osmosix, Inc., all rights reserved.
#*******************************************************************************

logger -t "OSMOSIX" "Executing .osmosix.sh ..."

export OSMOSIX_PROD_HOME=/usr/local/osmosix
export OSMOSIX_CONF_HOME=$OSMOSIX_PROD_HOME/etc
export OSMOSIX_LOGS_HOME=$OSMOSIX_PROD_HOME/logs
export OSMOSIX_COLLECTION_HOME=$OSMOSIX_PROD_HOME/collections
export OSMOSIX_COLLECTION_CONFIG=$OSMOSIX_COLLECTION_HOME/config
export OSMOSIX_COLLECTION_FILES=$OSMOSIX_COLLECTION_HOME/files
export SECTORFS_HOME=$OSMOSIX_PROD_HOME/dfs/sector-sphere
export GLUSTERFS_HOME=$OSMOSIX_PROD_HOME/dfs/glusterfs
export FHGFS_HOME=$OSMOSIX_PROD_HOME/dfs/fhgfs
export OSMOSIX_NODE_CONF=$OSMOSIX_CONF_HOME/node.conf
export OSMOSIX_FSKEY=$OSMOSIX_CONF_HOME/fskey
export OSMOSIX_INJECT=/tmp/.inject
export OSMOSIX_USERDATA=$OSMOSIX_INJECT/userdata
export OSMOSIX_CLOUD_FILE=$OSMOSIX_CONF_HOME/cloud
export OSMOSIX_COMPONENT_FILE=$OSMOSIX_CONF_HOME/component
export OSMOSIX_HOSTID_FILE=$OSMOSIX_CONF_HOME/hostid
export OSMOSIX_DFS_HOSTLIST=$OSMOSIX_INJECT/dfshostlist
export OSMOSIX_DFS_INI_FILE=$OSMOSIX_INJECT/dfs.ini
export OSMOSIX_DFS_INI=$OSMOSIX_CONF_HOME/dfs.ini
export OSMOSIX_GETIP=$OSMOSIX_PROD_HOME/bin/getip
export OSMOSIX_USERDATA_FILE=$OSMOSIX_PROD_HOME/etc/user-data
export OSMOSIX_PACKAGE_DIR=/opt/remoteFiles/appPackage

export OSAPP_HOME=/

if [ ! -d $OSMOSIX_INJECT ]; then
	mkdir -p $OSMOSIX_INJECT
	chmod 0777 $OSMOSIX_INJECT
fi

if [ ! -f $OSMOSIX_CLOUD_FILE ]; then
    logger -t "OSMOSIX" "$OSMOSIX_CLOUD_FILE not found. Set 'amazon' as the default value and create $OSMOSIX_CLOUD_FILE..."
    echo "amazon" > $OSMOSIX_CLOUD_FILE
fi

export OSMOSIX_COMPONENT=`cat $OSMOSIX_COMPONENT_FILE`
# component specific parameters
###


export OSMOSIX_COMPONENT=`cat $OSMOSIX_COMPONENT_FILE`
export OSMOSIX_CLOUD=`cat $OSMOSIX_CLOUD_FILE | tr '[:upper:]' '[:lower:]'`
logger -t "OSMOSIX" "Exported OSMOSIX_COMPONENT=${OSMOSIX_COMPONENT}, OSMOSIX_CLOUD=${OSMOSIX_CLOUD}"

#Trims Leading and Trailing whitespace characters
trim() {
    local var="$*"
    var="${var#"${var%%[![:space:]]*}"}"
    var="${var%"${var##*[![:space:]]}"}"
    echo -n "$var"
}

# create host id file (need to generate instance persistent data including hostid on EBS volume,
# for now we just use host name as host id)
if [ ! -f "$OSMOSIX_HOSTID_FILE" ]; then
	hostname > $OSMOSIX_HOSTID_FILE
fi
export OSMOSIX_HOSTID=`cat $OSMOSIX_HOSTID_FILE`
logger -t "OSMOSIX" "Exported OSMOSIX_HOSTID=${OSMOSIX_HOSTID}"

# setup and start vnc server
osStartVncServer() {
	ldapuser=$1
	ldapgroup=$2

	chmod 0600 /usr/local/osmosix/etc/vnc/passwd
	mkdir /home/$ldapuser/.vnc
	chown $ldapuser:$ldapgroup /home/$ldapuser/.vnc
	chmod 0700 /home/$ldapuser/.vnc
	cp /usr/local/osmosix/etc/vnc/* /home/$ldapuser/.vnc
	echo ". /usr/local/osmosix/etc/userenv" > /home/$ldapuser/.vnc/.xsessionrc
	chown -R $ldapuser:$ldapgroup /home/$ldapuser/.vnc/
	su - $ldapuser -c vncserver :1
	logger -t "OSMOSIX" "starting vnc server, result: $?"
}

METAKEY_HOME="/root"
vmGetCustomValue() {
	local key=$1
	keyFile="$METAKEY_HOME/.$key"
	if [ ! -f $keyFile ]; then
		vmtoolsd --cmd "info-get guestinfo.cliqr.$key" > $keyFile 2>/dev/null
	fi
	cat "$keyFile"
}

# Get vmware esx metadata
osGetEsxMetadata() {
	local key=$1
	local value=`vmGetCustomValue $key`
	local count=0
	logger -t "OSMOSIX" "Initial attempt raw user data value: $value"
	while [ $count -le 400 -a "$value" == "" ]; do
	    logger -t "OSMOSIX" "Sleep for 5 seconds"
		sleep 5s
		let count=count+1
		value=$(vmtoolsd --cmd "info-get guestinfo.cliqr.$key")
		logger -t "OSMOSIX" "Trial Num: $count , Userdata : $value"
	done
	echo "$value"
}

# Get vcd metadata property
osGetVcdMetadata() {
	local key=$1
        local len=${#key}
        let "vcdp = 46 + len"
        vmtoolsd --cmd 'info-get guestinfo.ovfenv' | grep "cliqr.$key" |cut -b $vcdp- |rev | cut -b 4- | rev | sed "s/&quot;/\"/g"
}

# extract bootstrap URL
extractAgentBundleURL() {
	json="$1"
	temp=`echo "$json" | sed 's/\\\\\//\//g' | sed 's/[{}]//g' | awk -v k="text" '{n=split($0,a,","); for (i=1; i<=n; i++) print a[i]}' | sed 's/\"\:\"/\|/g' | sed 's/[\,]/ /g' | sed 's/\"//g' | grep -w agentBundleURL`
	echo ${temp##*|}
}


checkDiskPartitionsMounted() {
    resultDevice=''
    disk="$1"
    blockDevices="$2"

    diskLabel=${disk#"/dev/"}
    filteredBlockDevices=$(echo "$blockDevices" |  grep "$diskLabel")
    #echo "Filtered Devices : filteredBlockDevices"

    devs=`echo "$filteredBlockDevices" | tr -d =\" | tr ' ' '\n'`
    diskAttribs=( $devs )
    #echo "Number of Disk attributes using the diskAttribs array : ${#diskAttribs[@]}"

    len="${#diskAttribs[@]}"
    if [ "$len" -gt 0 ]; then
        mountCount=0
        for (( i=0; i<$len; i=i+2 )); do
            #diskName=${diskAttribs[$i]}
            #diskName=${diskName#NAME}

            mountPoint=${diskAttribs[$i+1]}
            mountPointVal=${mountPoint#MOUNTPOINT}

            #echo "$diskName $mountPointVal"

            if [ ! -z "$mountPointVal" ]; then
                mountCount=1
                break
            fi
        done
        if [ "$mountCount" -eq 0 ]; then
            resultDevice="$disk"
        fi
    fi
    echo "$resultDevice"
}


getLastNPersistentDisks() {
    disks=$(echo "$1" | tac)
    . /usr/local/osmosix/etc/userenv

    persistDisks=""
    if [ -z "$cliqrNoOfVolumes" ]; then
        count=0
    else
        count=$cliqrNoOfVolumes
    fi

    #All Block Devices in flattened format instead of tree output format
    blockDevices=`lsblk -o NAME,MOUNTPOINT -P`
    #Reverse Order of the listed Block devices as generally based on order of attachment the disks are listed and we want to process disks  added later as attachments
    blockDevices=$(echo "$blockDevices" | tac)

    for disk in $disks; do
        if [ -L $deviceName ]; then
            disk=`readlink -f $disk`
        fi

        if [ "$count" -le 0 ]; then
            break
        else
            result=$(checkDiskPartitionsMounted "$disk" "$blockDevices")

            #echo "Result from checkDevicePartitionsMounted call : $result"
            if [ ! -z "$result" ] && [ "$result" == "$disk"  ]; then
                if [ -z "$persistDisks" ]; then
                    persistDisks=$disk
                else
                    persistDisks="$persistDisks $disk"
                fi
                let "count -= 1"
            fi
        fi
    done

    echo "$persistDisks"
}

checkVcdPartitionsMounted() {
    resultDevice=''
    disk="$1"
    blockDevices="$2"

    diskLabel=${disk#"/dev/"}
    filteredBlockDevices=$(echo "$blockDevices" |  grep "$diskLabel")

    devs=`echo "$filteredBlockDevices" | tr '=' '\n' | tr ' ' '\n' `
    diskAttribs=( $devs )

    len="${#diskAttribs[@]}"

    if [ "$len" -gt 0 ]; then
        mountCount=0
        for (( i=0; i<$len; i=i+4 )); do
            #diskName=${diskAttribs[$i]}
            #diskName=${diskName#NAME}

            mountPoint=`echo "${diskAttribs[$i+1]}" | tr -d '\"'`
            mountPointVal=`echo "${diskAttribs[$i+3]}" | tr -d '\"'`

            if [ ! -z "$mountPointVal" ]; then
                mountCount=1
                break
            fi
        done

        if [ "$mountCount" -eq 0 ]; then
            resultDevice="$disk"

        fi
    fi
    echo "$resultDevice"
}

getVcdLastNPersistentDisks() {
    disks=$(echo "$1" | tac)
    . /usr/local/osmosix/etc/userenv

    persistDisks=""
    if [ -z "$cliqrNoOfVolumes" ]; then
        count=0
    else
        count=$cliqrNoOfVolumes
    fi

    #All Block Devices in flattened format instead of tree output format
    blockDevices=`lsblk -o NAME,MOUNTPOINT -P`

    #Reverse Order of the listed Block devices as generally based on order of attachment the disks are listed and we want to process disks  added later as attachments
    blockDevices=$(echo "$blockDevices" | tac)

    for disk in ${disks[@]}; do

        if [ -L $deviceName ]; then
            disk=`readlink -f $disk`
        fi

        if [ "$count" -le 0 ]; then
            break
        else
            result=$(checkVcdPartitionsMounted "$disk" "$blockDevices")

            if [ ! -z "$result" ] && [ "$result" == "$disk"  ]; then
                if [ -z "$persistDisks" ]; then
                    persistDisks=$disk
                else
                    persistDisks="$persistDisks $disk"
                fi
                let "count -= 1"
            fi
        fi
    done

    logger -t "OSMOSIX" "Persistent Disks identified are "$persistDisks" "
    echo "$persistDisks"
}

getPersistentDisks() {
	disklist=""

    if [ "$OSMOSIX_CLOUD" == "opsource" -o "$OSMOSIX_CLOUD" == "vmware" -o "$OSMOSIX_CLOUD" == "vcd" -o  "$OSMOSIX_CLOUD" == "amazon" -o "$OSMOSIX_CLOUD" == "azure"  -o "$OSMOSIX_CLOUD" == "azurerm" -o "$OSMOSIX_CLOUD" == "google" -o "$OSMOSIX_CLOUD" == "rackspace2" -o "$OSMOSIX_CLOUD" == "softlayer" -o "$OSMOSIX_CLOUD" == "azurepack" -o "$OSMOSIX_CLOUD" == "azurestack" -o "$OSMOSIX_CLOUD" == "nutanix" ]; then

        if [ "$OSMOSIX_CLOUD" == "vcd" ]; then
            logger -t "OSMOSIX" " Rescan for any attached independent disks not yet detected."
            host=`ls -l /sys/class/scsi_host/ | grep -v total | awk '{print $9}' | awk -F"host" '{print $2}'`
            for i in $host; do
               logger -t "OSMOSIX" "Rescanning scsi host $i"
                echo "- - -" > /sys/class/scsi_host/host$i/scan
            done
            logger -t "OSMOSIX" "SCSI Rescan complete."

            ls -l /dev/xvd? >> /dev/null 2>&1
            if [ $? -eq 0 ]; then
                xvds="$(ls /dev/xvd? | awk '{print $NF}')"
		        xvds=($xvds)
            fi

            ls -l /dev/sd? >> /dev/null 2>&1
            if [ $? -eq 0 ]; then
                sdds=$(ls /dev/sd?  | awk '{print $NF}')
                sdds=($sdds)
            fi

            disks=("${xvds[@]}" "${sdds[@]}")

        else
            ls -l /dev/sd? >> /dev/null 2>&1
            if [ $? -eq 0 ]; then
                disks=$(ls -l /dev/sd? | awk '{print $NF}')
                echo $disks |grep xvd > /dev/null
                if [ $? -eq 0 ]; then
                    disks=$(ls -l /dev/xvd? | awk '{print $NF}')
                fi
            else
                disks=$(ls -l /dev/xvd? | awk '{print $NF}')
            fi
        fi
    #get persistant disk list by checking ls of sd?, xvd? and vd? in that order
    elif [ "$OSMOSIX_CLOUD" == "custom" ]; then
        ls -l /dev/sd? >> /dev/null 2>&1
        if [ $? -eq 0 ]; then
            disks=$(ls -l /dev/sd? | awk '{print $NF}')
        else
            ls -l /dev/xvd? >> /dev/null 2>&1
            if [ $? -eq 0 ]; then
                disks=$(ls -l /dev/xvd? | awk '{print $NF}')
            else 
                disks=$(ls -l /dev/vd? | awk '{print $NF}')
            fi
        fi
    else
        #for cloudstack, advanced zone is /dev/xvd*, basic zone is /dev/vd* so we try both
        disks=$(ls -l /dev/vd? | awk '{print $NF}')
        if [ -z "$disks" -a "$OSMOSIX_CLOUD" == "cloudstack" ]; then
            disks=$(ls -l /dev/xvd? | awk '{print $NF}')
        fi
    fi

	#special handling for vmware and amazon
    if [ "$OSMOSIX_CLOUD" == "vmware" -o "$OSMOSIX_CLOUD" == "amazon" ]; then
        disklist=$(getLastNPersistentDisks "$disks")
    #special handling for custom cloud type
    elif [ "$OSMOSIX_CLOUD" == "custom" ]; then
        disklist=$(getLastNPersistentDisks "$disks")
    elif [ "$OSMOSIX_CLOUD" == "vcd" ]; then
        disklist=$(getVcdLastNPersistentDisks "${disks[@]}")
    else
        logger -t "OSMOSIX" "disks: $disks"
        for disk in $disks; do
            logger -t "OSMOSIX" "processing disk $disk"
            # skip root disk except for cloudn which uses /dev/sda for root disks and /dev/vda for attached
    #		if [ "$OSMOSIX_CLOUD" != "cloudn" -a "$OSMOSIX_CLOUD" != "cloudstack" ]; then
    #                        [ "$disk" == "/dev/vda" ]&& continue
    #                fi
                    [ "$disk" == "/dev/vda" ]&& continue

                    # skip google/vmware/opsource root disk
                    # bracket volumes are sda, sdb etc, so if bracket and sda, will not conitnue
                    if [ "$OSMOSIX_CLOUD" == "bracket" ];then
                        [ "$disk" == "/dev/xvda" ]&& continue
                        [ "$disk" == "/dev/xvdb" ]&& continue
                        [ "$disk" == "/dev/xvdc" ]&& continue
                    fi
                    if [ "$OSMOSIX_CLOUD" != "bracket" ];then
                        [ "$disk" == "/dev/sda" ]&& continue
                    fi

            # skip vmware/opsource ephemeral disk
                    if [  "$OSMOSIX_CLOUD" == "vmware" -o "$OSMOSIX_CLOUD" == "vcd" ]; then
                           [ "$disk" == "/dev/sdb" ]&& continue
                    fi
		    # Core 19216 - temp mount fix for opsource
                    if [  "$OSMOSIX_CLOUD" == "opsource" ]; then
			   umount /mnt
                    fi

            if [  "$OSMOSIX_CLOUD" == "rackspace2" ]; then
                [ "$disk" == "/dev/xvda" ]&& continue
                [ "$disk" == "/dev/xvdc" ]&& continue
            fi

            # skip ephemeral disks
            [ "`df -h | grep "^$disk"`" ] && continue

            # skip ephemeral disks in openstack based cloud systems
            edev=$(ls -al /dev/disk/by-label/ephemeral0 2>/dev/null| awk '{print $NF}' | awk -F "/" '{print $NF}' 2>/dev/null)
            if [[ "$edev" == vd? ]]; then
                [ "$disk" == "/dev/$edev" ]&& continue
            fi

            # skip google ephemeral disks
            googlescratchdev=$(ls -al /dev/disk/by-id 2>/dev/null| grep "google.*scratch")
            if [ ! -z "$googlescratchdev" ]; then
                googleedev=$(ls -al /dev/disk/by-id/google*scratch* 2>/dev/null| awk '{print $NF}' | awk -F "/" '{print $NF}' 2>/dev/null)
                if [[ "$googleedev" == sd? ]]; then
                    [ "$disk" == "/dev/$googleedev" ]&& continue
                fi
            fi

            #skip softlayer stuff
            if [ "$OSMOSIX_CLOUD" == "softlayer" ]; then
                [ "$disk" == "/dev/xvda" ]&& continue
                [ "$disk" == "/dev/xvdb" ]&& continue
                [ "$disk" == "/dev/xvdh" ]&& continue
            fi

            #skip vmware ephemeral stuff
            if [ "$OSMOSIX_CLOUD" == "vmware" ]; then
                [ "$disk" == "/dev/sda" ]&& continue
                [ "$disk" == "/dev/sdb" ]&& continue
                [ "$disk" == "/dev/sdc" ]&& continue
            fi

            #skip amazon ephemeral stuff
            if [ "$OSMOSIX_CLOUD" == "amazon" ]; then
                if [ "$numEphemerals" -gt "0" ]; then
                    let "numEphemerals -= 1"
                    continue
                fi
            fi

            logger -t "OSMOSIX" "device Name $deviceName"
            if [ -L "$deviceName" ]; then
                disk=`readlink -f $disk`
            fi
            disklist="$disklist $disk"
        done
    fi
	echo "$disklist"
}

getPersistenceDevice() {
    disks=`getPersistentDisks`
	deviceName=$(echo "$disks" | awk '{print $1;}')
	echo "$deviceName"
}

getLogicalVolumes() {
	local disks=""
	# setup LVM with all available persistent disks
	if [ "$OSMOSIX_CLOUD" == "google" ]; then
		disks=$(ls /dev/disk/by-id/google-*)
	elif [ "$OSMOSIX_CLOUD" == "vmware" -o "$OSMOSIX_CLOUD" == "azure" -o "$OSMOSIX_CLOUD" == "azurerm" -o "$OSMOSIX_CLOUD" == "azurepack" -o "$OSMOSIX_CLOUD" == "opsource" -o "$OSMOSIX_CLOUD" == "azurestack" -o "$OSMOSIX_CLOUD" == "nutanix" ]; then
		disks=$(ls -l /dev/sd? | awk '{print $NF}')
	elif [ "$OSMOSIX_CLOUD" == "hp" -o "$OSMOSIX_CLOUD" == "hpcloud" -o "$OSMOSIX_CLOUD" == "hplegacy" ]; then
		# wait until volumes become available
		while true; do
			if [ ! -f /tmp/volumes ]; then
				sleep 3
				continue
			fi

			vols=$(cat /tmp/volumes)
			/usr/local/osmosix/bin/chkvol $vols > /dev/null 2>&1
			if [ $? -eq 0 ]; then
				break
			fi
			sleep 10
		done

		disks=$(ls -l /dev/vd? | awk '{print $NF}')
	elif [ "$OSMOSIX_CLOUD" == "rackspace2" ]; then
		disks=$(ls -l /dev/xvd? | awk '{print $NF}')
	else
		disks=$(ls -l /dev/vd? | awk '{print $NF}')
	fi

	local volumes=""
	for disk in $disks; do
		logger -t "OSMOSIX" "processing disk $disk"
		# skip root disk
		[ "$disk" == "/dev/vda" ]&& continue

		# skip rackspace open cloud root and ephemeral disks
		[ "$disk" == "/dev/xvda" ]&& continue
		[ "$disk" == "/dev/xvdb" ]&& continue
		[ "$disk" == "/dev/xvdc" ]&& continue

		# skip vmware/azure root disk and ephemeral disk
		[ "$disk" == "/dev/sda" ]&& continue
		[ "$disk" == "/dev/sdb" ]&& continue

		# skip google ephemeral disk and root disk
		hostname=`hostname`
		[[ $disk == /dev/disk/by-id/*$hostname* ]]&& continue
		[[ $disk == *-part? ]]&& continue

                # skip ephemeral disks
                [ "`df -h | grep "^$disk"`" ] && continue

		# skip disks with partition
		if [ -b "$disk"1 ]; then
		      continue
	     	fi

		# skip disks with partition on GCE
		if [ -b $disk"-part1" ]; then
			continue
		fi

  		fdisk $disk < $FEEDFDISK > /dev/null 2>&1
		_check_result
		if [ "$OSMOSIX_CLOUD" == "google" ]; then
			volume=$disk"-part1"
		else
			volume="$disk"1
		fi
		pvcreate $volume > /dev/null 2>&1
		_check_result
		volumes="$volumes $volume"
	done

	echo $volumes
}

isRunningNewStorage() {
	echo $OSMOSIX_SYSTEM_DATA | awk 'BEGIN {FS=","} {x=1; while (x < NF) { print $x; x++} print $NF}' > /tmp/userdata.tmp
	cat /tmp/userdata.tmp | grep -i "^replica=" > /dev/null 2>&1
	if [ $? -eq 0 ]; then
		echo true
	else
		echo false
	fi
}

detectVpnMode() {
	echo $OSMOSIX_SYSTEM_DATA | grep ",vpn=1"  > /dev/null 2>&1
	if [ $? -eq 0 ]; then
		VPN_MODE=1
	else
		VPN_MODE=0
	fi
}

# for new gateway setup, do not use userdata anymore, use property files
getGatewaySystemData() {
    local DNSNAME="mgmtserver.dnsName"
    local CLOUDTYPE="gateway.cloudType"
    local NETWORK="gateway.network"
    local VPNID="gateway.vpnId"

    local dnsName=""
    local cloudType=""
    local network=""
    local vpnId=""

    local systemData=""

    configFile=$OSMOSIX_CONF_HOME/gateway_config.properties
    if [ ! -f $configFile ]; then
        logger -t "OSMOSIX" "$configFile not available"
        return
    fi

    while read line; do
        if [[ "$line" == "#"*  ]]; then
            continue
        fi

        key=`echo $line | awk -F "=" '{print $1}'`
        val=`echo $line | awk -F "=" '{print $2}'`

        if [ "$key" == "$DNSNAME" ]; then
            dnsName=$val
        elif [ "$key" == "$CLOUDTYPE" ]; then
            cloudType=$val
        elif [ "$key" == "$NETWORK" ]; then
            network=$val
        elif [ "$key" == "$VPNID" ]; then
            vpnId=$val
        else
            logger -t "OSMOSIX" "invalid gateway_config.properties content"
            logger -t "OSMOSIX" "content: $line"
        fi
    done < $configFile

    if [ "$dnsName" == "" -o "$cloudType" == "" ]; then
        logger -t "OSMOSIX" "invalid gateway_config.properties, no $DNSNAME or $CLOUDTYPE"
        return
    fi

    systemData=${cloudType},${dnsName}
    if [ "$network" != "" ]; then
        systemData=${systemData},${network}
    fi

    if [ "$vpnId" != "" ]; then
        systemData=${systemData},${vpnId}
    fi

    echo $systemData
}

getAzureMetadataServer() {
	MDS="mds.cliqrtech.com" # default metadata server

	if [ "$OSMOSIX_CLOUD" == "azure" ]; then
	  		 AZURE_CUSTOM_DATA_FILE=/var/lib/waagent/ovf-env.xml
	  		 if [ -f $AZURE_CUSTOM_DATA_FILE ]; then
	  		  		BASE64_CUSTOM_DATA=`tr -d "\n\r" < $AZURE_CUSTOM_DATA_FILE` #remove new lines in the custom data , otherwise decoding fails
		        	CUSTOM_DATA=$(grep -E -m 1 -o "<CustomData>(.*)</CustomData>" <<< $BASE64_CUSTOM_DATA | sed 's/<CustomData>//' | sed 's/<\/CustomData>//')
		        	DATA=`echo $CUSTOM_DATA | base64 -id`
		        	MDS=`echo "$DATA" | cut -f 1 -d,`
	  		 fi
	fi

	echo $MDS
}

getAzureCloudDomain() {
	CLOUD_DOMAIN_NAME=".cloudapp.net" # default metadata server

	if [ "$OSMOSIX_CLOUD" == "azure" ]; then
	  		 AZURE_CUSTOM_DATA_FILE=/var/lib/waagent/ovf-env.xml
	  		 if [ -f $AZURE_CUSTOM_DATA_FILE ]; then
	  		  		BASE64_CUSTOM_DATA=`tr -d "\n\r" < $AZURE_CUSTOM_DATA_FILE` #remove new lines in the custom data , otherwise decoding fails
		        	CUSTOM_DATA=$(grep -E -m 1 -o "<CustomData>(.*)</CustomData>" <<< $BASE64_CUSTOM_DATA | sed 's/<CustomData>//' | sed 's/<\/CustomData>//')
		        	DATA=`echo $CUSTOM_DATA | base64 -id`
		        	CLOUD_DOMAIN_NAME=`echo "$DATA" | cut -f 2 -d,`
	  		 fi
	fi

	echo $CLOUD_DOMAIN_NAME
}

checkMetadataServer() {
  if [ "$OSMOSIX_CLOUD" == "azure" ]; then
	        DEFAULT_MDS_SERVER="mds.cliqrtech.com"
		MDS=`getAzureMetadataServer`
	        META_JS_FILE=$OSMOSIX_PROD_HOME/lib/meta.js
	        if ! grep -q "'"$MDS"'" "$META_JS_FILE"; then
		        if [ ! -z  "$MDS" ]; then
				        sed -i "s,$DEFAULT_MDS_SERVER,$MDS,g" $META_JS_FILE
			fi
		fi
  fi
}

# cloud specific parameters
###
if [ "$OSMOSIX_CLOUD" == "azure" ]; then
    checkMetadataServer
fi


if [ "$OSMOSIX_CLOUD" == "cloudstack" -o "$OSMOSIX_CLOUD" == "cloudn" ]; then
		CLOUDN_METADATA_SERVER=`/usr/local/osmosix/bin/get-cloudn-metadata-server.sh`
        sed '/^.*metadata$/d' /etc/hosts > /tmp/hosts.tmp
        echo "$CLOUDN_METADATA_SERVER	metadata" >> /tmp/hosts.tmp
        cp /tmp/hosts.tmp /etc/hosts
        rm /tmp/hosts.tmp
fi

#Gets the User data using VMtools from the VM's custom properties and creates 2 files:
#/tmp/.inject/rawuserdata       --> contains the raw user data script
#/usr/local/osmosix/etc/user-data  --> contains the userdata as obtained by executing the raw user data  
fetchUserDataVMware() {
    logger -t "OSMOSIX" "Cloud is VMware. Get the userdata script from vmtools env variable and execute it to populate user-data"
    RAW_USERDATA_FILE='/tmp/.inject/rawuserdata'
    #If the Raw Vmware user data file and user-data file exist then skip
    if [[ -f "$RAW_USERDATA_FILE" && -f "$OSMOSIX_USERDATA_FILE" ]]; then
        logger -t "OSMOSIX" "Files already exist: $RAW_USERDATA_FILE and $OSMOSIX_USERDATA_FILE. Skip creation of the files again."
    else
        VMWARE_RAW_USERDATA=$(osGetEsxMetadata userdata)
        if [ "$VMWARE_RAW_USERDATA" == "" ]; then
            logger -t "OSMOSIX" "Raw userdata could not be obtained by running vmtools. Use cloud node metadata service if available"
        else
            echo "$VMWARE_RAW_USERDATA" >> "$RAW_USERDATA_FILE"
            logger -t "OSMOSIX" "Raw userdata obtained using vmtools command written to $RAW_USERDATA_FILE"
            chmod 755 "$RAW_USERDATA_FILE"
            #If user-data file already exists then skip executing raw user data script to populate this file
            if [ -f "$OSMOSIX_USERDATA_FILE" ]; then
                logger -t "OSMOSIX" "User-data file already exists: $OSMOSIX_USERDATA_FILE."
            else
                logger -t "OSMOSIX" "Execute $RAW_USERDATA_FILE to create user-data file"
                bash $RAW_USERDATA_FILE
                #Check if File got created
                if [ -f "$OSMOSIX_USERDATA_FILE" ]; then
                    logger -t "OSMOSIX" "Executed $RAW_USERDATA_FILE to create $OSMOSIX_USERDATA_FILE"
                else
                    logger -t "OSMOSIX" "Executed $RAW_USERDATA_FILE but failed to create $OSMOSIX_USERDATA_FILE. Use cloud node metadata service if available"
                fi
            fi
        fi
    fi
}

logger -t "OSMOSIX" "COMPONENT: $OSMOSIX_COMPONENT"
#For VMware cloud
#if [ "$OSMOSIX_CLOUD" == "vmware" ]; then
#    fetchUserDataVMware
#fi

#For custom workers of custom cloud type, execute metadata extractor and userdata scripts
if [ "$OSMOSIX_CLOUD" == "custom" ]; then
	logger -t "OSMOSIX" "Worker cloud type: custom"
	#If agent is not installed, execute custom metadata extractor and userdata script
	AGENTINSTALLED='/usr/local/osmosix/etc/.AGENTINSTALLED'

	if [ -f "$AGENTINSTALLED" ]; then
		logger -t "OSMOSIX" "Agent already installed. Skipping metadata and userdata extraction for the custom worker of custom cloud type"
	else
		logger -t "OSMOSIX" "Agent is not installed"
		METADATA_OUT_FILE='/usr/local/metadata.out'
		if [ -f "$METADATA_OUT_FILE" ]; then
			logger -t "OSMOSIX" "$METADATA_OUT_FILE is present indicating bootstrap might already be in progress. Skip metadata/userdata extraction"
		else
			logger -t "OSMOSIX" "Extracting metadata and userdata for the custom worker of custom cloud type"
			METADATA_EXTRACTOR="/usr/local/metadata_extractor.sh"
			USERDATA_EXTRACTOR="/usr/local/userdata_extractor.sh"
			RAW_USERDATA="/usr/local/raw_userdata.sh"

			bash $METADATA_EXTRACTOR >> /usr/local/metadata_extractor.log 2>&1
			bash $USERDATA_EXTRACTOR >> /usr/local/userdata_extractor.log 2>&1
			if [ -f $RAW_USERDATA ]; then
				logger -t "OSMOSIX" "Executed $USERDATA_EXTRACTOR to create $RAW_USERDATA. Executing $RAW_USERDATA..."
				bash $RAW_USERDATA >> /usr/local/raw_userdata.log 2>&1
				OSMOSIX_USERDATA_FILE="$OSMOSIX_CONF_HOME/user-data"
				if [ -f $OSMOSIX_USERDATA_FILE ]; then
					logger -t "OSMOSIX" "Executed $RAW_USERDATA to create $OSMOSIX_USERDATA_FILE"
				else
					logger -t "OSMOSIX" "Executed $RAW_USERDATA but failed to create $OSMOSIX_USERDATA_FILE"
				fi
			else
				logger -t "OSMOSIX" "Executed $USERDATA_EXTRACTOR but failed to create $RAW_USERDATA"
			fi
		fi
	fi
fi


if [ "$OSMOSIX_COMPONENT" == "gateway" -o "$OSMOSIX_COMPONENT" == "cso" -o "$OSMOSIX_COMPONENT" == "cco" ]; then
            export OSMOSIX_SYSTEM_DATA=`getGatewaySystemData`
else
    logger -t "OSMOSIX" "OSMOSIX CLOUD: $OSMOSIX_CLOUD"
    if [ "$OSMOSIX_CLOUD" != "" ]; then
        if [ -f "$OSMOSIX_USERDATA_FILE" ]; then
            logger -t "OSMOSIX" "File exists: $OSMOSIX_USERDATA_FILE. Export OSMOSIX_SYSTEM_DATA"
            export OSMOSIX_SYSTEM_DATA=`cat $OSMOSIX_USERDATA_FILE`
            logger -t "OSMOSIX" "Received data as + $OSMOSIX_SYSTEM_DATA"
            logger -t "OSMOSIX" "Userdata has already been written to local user-data file. Skipping usage of node metadata service to get userdata."
        else
            isUserDataPresent=0
            for step in `seq 1 400`; do
                logger -t "OSMOSIX" "Run the node metadata app with 5s timeout"
                result=$(timeout 5s /usr/local/ccc_node-metadata -command user-data)
                if [ $? -eq 0 ]; then
                    logger -t "OSMOSIX" "Got node metadata : $result"
                    isUserDataPresent=1
                    echo "$result" > /tmp/.inject/rawuserdata
                    break
                fi
                #isUserDataPresent=$(curl -s -o /tmp/.inject/rawuserdata -w "%{http_code}" http://localhost:5810/cloud-node-metadata/node/user-data --connect-timeout 30 -m 60)
                #logger -t "OSMOSIX" "Is user data ready + $isUserDataPresent"
                #if [ $isUserDataPresent == '200' ]; then
                #    logger -t "OSMOSIX" "Received the data ready status + $isUserDataPresent"
                #    break
                #fi
                logger -t "OSMOSIX" "Sleep for 5s"
                sleep 5
            done

            if [ $isUserDataPresent -eq 0 ]; then
                logger -t "OSMOSIX" "Failed to get user data + $OSMOSIX_SYSTEM_DATA"
                #exit 1;
            else
                export OSMOSIX_SYSTEM_DATA=`cat /tmp/.inject/rawuserdata`
                logger -t "OSMOSIX" "Received data as + $OSMOSIX_SYSTEM_DATA"
            fi
        fi
    fi
fi;

#OSMOSIX_PRIVATE_IP=`curl -s --retry 30 http://localhost:5810/cloud-node-metadata/node/private-ip`
#OSMOSIX_PUBLIC_IP=`curl -s --retry 30 http://localhost:5810/cloud-node-metadata/node/public-ip`

#logger -t "OSMOSIX" "Public ip received is + $OSMOSIX_PUBLIC_IP"
#logger -t "OSMOSIX" "Private ip received is + $OSMOSIX_PRIVATE_IP"

    if [ "$OSMOSIX_CLOUD" == "amazon" ]; then
    logger -t "OSMOSIX" "Set ubuntu as owner and group of $OSMOSIX_INJECT if /etc/passwd exists with ubuntu user..."
        if [ "`cat /etc/passwd |grep "^ubuntu"`" != "" ]; then
            chown ubuntu:ubuntu $OSMOSIX_INJECT
        else
            chmod 0777 $OSMOSIX_INJECT
        fi
    fi

# create logs directory
if [ ! -d "$OSMOSIX_LOGS_HOME" ]; then
    logger -t "OSMOSIX" "Creating directory: ${OSMOSIX_LOGS_HOME}..."
    mkdir -p $OSMOSIX_LOGS_HOME
fi

# copy dfs.ini file
if [ -f "$OSMOSIX_DFS_INI_FILE" ]; then
    logger -t "OSMOSIX" "Copying $OSMOSIX_DFS_INI_FILE to /usr/local/osmosix/etc..."
    cp $OSMOSIX_DFS_INI_FILE /usr/local/osmosix/etc
fi

#Add google ephemeral disk if it exists
if [ "$OSMOSIX_CLOUD" == "google" ]; then
	googlescratchdev=$(ls -al /dev/disk/by-id | grep "google.*scratch")
	if [ ! -z "$googlescratchdev" ]; then
        	scratchDevice=$(/dev/$(ls -l /dev/disk/by-id/google*scratch* | cut -f 7 -d "/"))
	        if [ ${#scratchDevice[@]} == 1 ]; then
       	         if [ -b ${scratchDevice[0]} -a ! -b ${scratchDevice[0]}'1' ]; then
       	           (echo n; echo p; echo 1; echo ; echo ; echo w) | fdisk $scratchDevice > /dev/null 2>&1
       	                 mkfs.ext4 $scratchDevice'1' > /dev/null 2>&1
       	                 mount $scratchDevice'1' /mnt
       	        elif [ $(mount |grep -c "/mnt") != 1 ]; then
                        mount ${scratchDevice[0]}'1' /mnt
       		    fi
       		fi
    fi
fi

if [ ! -f $OSMOSIX_USERDATA_FILE ]; then
    logger -t "OSMOSIX" "$OSMOSIX_USERDATA_FILE does not exist. Execute the following Osmosix System Data: ${OSMOSIX_SYSTEM_DATA}..."
    TMP_SCRIPT_FILE='/tmp/cliqrUserData.sh'
    echo "$OSMOSIX_SYSTEM_DATA" > $TMP_SCRIPT_FILE
    bash $TMP_SCRIPT_FILE
    rm $TMP_SCRIPT_FILE
    logger -t "OSMOSIX" "Executed Osmosix System Data."
fi

if [ -f $OSMOSIX_USERDATA_FILE ]; then
    logger -t "OSMOSIX" "$OSMOSIX_USERDATA_FILE exists. Export the value in the file."
    export OSMOSIX_SYSTEM_DATA=`cat $OSMOSIX_USERDATA_FILE`
    logger -t "OSMOSIX" "Exported OSMOSIX_SYSTEM_DATA=${OSMOSIX_SYSTEM_DATA}"
else
    logger -t "OSMOSIX" "$OSMOSIX_USERDATA_FILE does not exist. Process the Osmosix System Data to extract the filtered system data..."
    CLIQR_JSON_START="cliqrJson:"
    FILTERED_SYSTEM_DATA=`echo $OSMOSIX_SYSTEM_DATA | grep -o "$CLIQR_JSON_START.*" | sed "s/$CLIQR_JSON_START//g"`
    if [ ! -z $FILTERED_SYSTEM_DATA ]; then
		export OSMOSIX_SYSTEM_DATA=$FILTERED_SYSTEM_DATA
		logger -t "OSMOSIX" "Exported OSMOSIX_SYSTEM_DATA=${OSMOSIX_SYSTEM_DATA}"
    fi
fi

isCredentialPresent=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:5810/cloud-node-metadata/credential/required --connect-timeout 30 -m 60)
if [ $isCredentialPresent == '200' ]; then
	export OSMOSIX_CREDENTIAL_REQUIRED=`curl -s --retry 30 http://localhost:5810/cloud-node-metadata/credential/required`

	if [ 'true' == $OSMOSIX_CREDENTIAL_REQUIRED ]; then
		export OSMOSIX_BOOTSTRAP_USERNAME=`curl -s --retry 30 http://localhost:5810/cloud-node-metadata/credential/bootstrap-username`
		export OSMOSIX_BOOTSTRAP_PASSWORD=`curl -s --retry 30 http://localhost:5810/cloud-node-metadata/credential/bootstrap-password`
	fi
else
	export OSMOSIX_CREDENTIAL_REQUIRED='false'
fi

logger -t "OSMOSIX" "Finished executing osmosix.sh"
