#!/bin/bash

AGENT_MODE='brownfield'
ACTION='install'


if [ -z "$TARGET_VM_HOST" ];
then
	echo "TARGET_VM_HOST not available"
	exit -1
fi

if [ -z "$TARGET_VM_USER" ];
then
	echo "TARGET_VM_USER not available"
    exit -1
fi

if [ -z "$PKG_URL" ];
then
	echo "PKG_URL not available"
    exit -1
fi

if [ -z "$RABBIT_IP" ];
then
	echo "RABBIT_IP not available"
    exit -1
fi

if [ -z "$RABBIT_PORT" ];
then
	echo "RABBIT_PORT not available"
    exit -1
fi

if [ -z "$CLOUD_FAMILY" ];
then
	echo "CLOUD_FAMILY not available"
    exit -1
fi

if [ -z "$NODE_ID" ];
then
	echo "NODE_ID not available"
    exit -1
fi

if [ -z "$VHOST" ];
then
	echo "VHOST not available"
    exit -1
fi

export MY_DIR=`dirname $0`

# Configure custom repo

# Remove cisco internal repo
if [ -f /etc/yum.repos.d/cisco-internal.repo ]; then
    rm -fr /etc/yum.repos.d/cisco-internal.repo
fi

YUM_CONFIG_REPO=/etc/yum.repos.d/ccs.repo
CUSTOM_REPO_URL="http://repo.cliqrtech.com"
YUM_REPO_PATH="yumRepo/centos/7.0/x86_64"

if ! [ -z "$AgentCustomRepository" ];
then
    CUSTOM_REPO_URL=$AgentCustomRepository
fi

{ echo "[cloudrepo]"; echo "name=Custom repo for cloud files"; echo "baseurl=$CUSTOM_REPO_URL/$YUM_REPO_PATH/Packages"; echo "enabled=1"; echo "gpgcheck=0"; echo "priority=1"; echo "skip_if_unavailable=True"; } >> $YUM_CONFIG_REPO

chmod +x $YUM_CONFIG_REPO
yum check-update

if [ "$osType" == "windows" ];
then
    if [ -z "$password" ];
    then
    	echo "Windows Password not available"
        exit -1
    fi
    # Installing packages required for winexe
    yum install -y glibc zlib glibc.i686 zlib.i686
    if [ $? -ne 0 ];
    then
        echo "Failed to install glibc libraries"
        exit -1
    fi

    cd $MY_DIR/
    chmod a+x winexe
    echo "username=$TARGET_VM_USER" > authfile
    echo "password=$password" >> authfile

    if [ ! -z "$domain" ];
    then
        echo "domain=$domain" >> authfile
    fi

    chmod a+x authfile

    ./winexe --authentication-file=authfile //"$TARGET_VM_HOST" 'powershell -Command  invoke-command -ScriptBlock {$PSVersionTable.psversion}' > version
    if [ $? -ne 0 ];
    then
        echo "Failed to execute winexe command"
        exit -1
    fi
    export psversion=`cat version | awk 'NR==4' | awk -F " " '{printf $1}'`
    if [[ $psversion < 4 ]];
    then
        echo "Incompatible Powershell Version $psversion on the target machine. Please upgrade your Powershell version to 4.0 or later versions";
        exit -1
    fi

    export drive=`./winexe --authentication-file=authfile //"$TARGET_VM_HOST" 'powershell -Command  invoke-command -ScriptBlock {(get-location).Drive.Name}'`
    if [ $? -ne 0 ];
    then
        echo "Failed to execute winexe command to fetch the drive information"
        exit -1
    fi
    export drive=`echo $drive | tr -d '\040\011\012\015'`

    ./winexe --authentication-file=authfile //"$TARGET_VM_HOST" "cmd.exe /C echo \$PKG_URL = \"$PKG_URL\">>$drive:\\agentenv.ps1"
    if [ $? -ne 0 ];
    then
        echo "Failed to execute winexe command"
        exit -1
    fi
    ./winexe --authentication-file=authfile //"$TARGET_VM_HOST" "cmd.exe /C echo \$RABBIT_IP = \"$RABBIT_IP\">>$drive:\\agentenv.ps1"
    if [ $? -ne 0 ];
    then
        echo "Failed to execute winexe command 1"
        exit -1
     fi
    ./winexe --authentication-file=authfile //"$TARGET_VM_HOST" "cmd.exe /C echo \$RABBIT_PORT = \"$RABBIT_PORT\">>$drive:\\agentenv.ps1"
    if [ $? -ne 0 ];
    then
            echo "Failed to execute winexe command 2"
        exit -1
     fi
    ./winexe --authentication-file=authfile //"$TARGET_VM_HOST" "cmd.exe /C echo \$CLOUD_FAMILY = \"$CLOUD_FAMILY\">>$drive:\\agentenv.ps1"
    if [ $? -ne 0 ];
    then
        echo "Failed to execute winexe command 3"
        exit -1
     fi
    ./winexe --authentication-file=authfile //"$TARGET_VM_HOST" "cmd.exe /C echo \$NODE_ID = \"$NODE_ID\">>$drive:\\agentenv.ps1"
    if [ $? -ne 0 ];
    then
        echo "Failed to execute winexe command 4"
        exit -1
    fi
    ./winexe --authentication-file=authfile //"$TARGET_VM_HOST" "cmd.exe /C echo \$AGENT_MODE = \"$AGENT_MODE\">>$drive:\\agentenv.ps1"
    if [ $? -ne 0 ];
    then
        echo "Failed to execute winexe command 5"
        exit -1
    fi
    ./winexe --authentication-file=authfile //"$TARGET_VM_HOST" "cmd.exe /C echo \$ACTION = \"$ACTION\">>$drive:\\agentenv.ps1"
    if [ $? -ne 0 ];
    then
        echo "Failed to execute winexe command 6"
        exit -1
    fi

    ./winexe --authentication-file=authfile //"$TARGET_VM_HOST" "cmd.exe /C echo \$VHOST = \"$VHOST\">>$drive:\\agentenv.ps1"
    if [ $? -ne 0 ];
    then
        echo "Failed to execute winexe command 7"
        exit -1
    fi

    buildCredential=""
    credential=""

    if [ -z "$bundleStoreUser" ] || [ -z "$bundleStorePassword" ];
    then
        echo "bundlestore doesn't have credential"
    else
        buildCredential="\$password = ConvertTo-SecureString -String $bundleStorePassword -AsPlainText -Force; \$cred = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $bundleStoreUser,\$password; ";
        credential="-Credential \$cred";
        ./winexe --authentication-file=authfile //"$TARGET_VM_HOST" "cmd.exe /C echo \$buildCredential = '$buildCredential'>>$drive:\\agentenv.ps1"
        ./winexe --authentication-file=authfile //"$TARGET_VM_HOST" "cmd.exe /C echo \$credential = '$credential'>>$drive:\\agentenv.ps1"
    fi

    ./winexe --authentication-file=authfile //"$TARGET_VM_HOST" "powershell -ExecutionPolicy bypass -noninteractive -noprofile -Command cd $drive:/ ; $buildCredential Invoke-WebRequest $credential -Uri "$windowsScriptUrl" -OutFile $drive:\execute.ps1; ls ; . $drive:/execute.ps1"
    if [ $? -ne 0 ];
    then
        echo "Failed to execute execute.ps1 on target machine"
        exit -1
    fi

    exit 0
fi

which scp
if [ $? -ne 0 ];
then
	echo "scp not available, installing it"
	apk update
	apk add openssh
fi
which ssh
if [ $? -ne 0 ];
then
	echo "ssh not available installing it"
	apk update
    apk add openssh
fi

export TARGET_VM_KEY_FILE="keyfile.pem"

if [ -z "$bundleStoreUser" ] || [ -z "$bundleStorePassword" ];
then
    echo "bundlestore doesn't have credential"
fi


if [ -z "$TARGET_VM_KEY" ];
then
	echo "TARGET_VM_KEY not available"
	if [ -z "$password" ];
    then
        echo "Linux User Password not available"
        exit -1
    fi
    apk add sshpass
    if [ $? -ne 0 ];
    then
        echo "Failed to install sshpass"
         exit -1
    fi
    sshpass -p $password scp -o StrictHostKeyChecking=no $MY_DIR/execute.sh "$TARGET_VM_USER"@"$TARGET_VM_HOST":/tmp/
    if [ $? -ne 0 ];
     then
             echo "Failed to copy execute.sh on target machine using sshpass"
             exit -1
    fi
    sshpass -p $password ssh -t -t -o StrictHostKeyChecking=no "$TARGET_VM_USER"@"$TARGET_VM_HOST" "echo '$password' | sudo -S chmod a+x /tmp/execute.sh;"
    if [ $? -ne 0 ];
     then
        echo "Failed to assign execute permissions for the script on target machine"
        exit -1
    fi
    sshpass -p $password ssh -t -t -o StrictHostKeyChecking=no "$TARGET_VM_USER"@"$TARGET_VM_HOST" "echo '$password' | sudo -S bash -x /tmp/execute.sh $PKG_URL $RABBIT_IP $RABBIT_PORT $CLOUD_FAMILY $NODE_ID $AGENT_MODE $ACTION $VHOST $bundleStoreUser $bundleStorePassword"
    if [ $? -ne 0 ];
     then
             echo "Failed to execute execute.sh on target machine"
             exit -1
        fi
    exit 0
fi

if [ -f "$TARGET_VM_KEY_FILE" ];
then
    chmod 0777 $TARGET_VM_KEY_FILE
fi
echo -e "$TARGET_VM_KEY" > $TARGET_VM_KEY_FILE
chmod 0400 $TARGET_VM_KEY_FILE

scp -i $TARGET_VM_KEY_FILE -o StrictHostKeyChecking=no $MY_DIR/execute.sh "$TARGET_VM_USER"@"$TARGET_VM_HOST":/tmp/
if [ $? -ne 0 ];
then
     echo "Failed to copy execute.sh on target machine using scp"
     exit -1
fi
ssh -t -t -i $TARGET_VM_KEY_FILE -o StrictHostKeyChecking=no "$TARGET_VM_USER"@"$TARGET_VM_HOST" "sudo chmod a+x /tmp/execute.sh;"
if [ $? -ne 0 ];
then
    echo "Failed to assign execute permissions for the script on target machine"
    exit -1
fi
ssh -t -t -i $TARGET_VM_KEY_FILE -o StrictHostKeyChecking=no "$TARGET_VM_USER"@"$TARGET_VM_HOST" "sudo bash -x /tmp/execute.sh $PKG_URL $RABBIT_IP $RABBIT_PORT $CLOUD_FAMILY $NODE_ID $AGENT_MODE $ACTION $VHOST $bundleStoreUser $bundleStorePassword"
if [ $? -ne 0 ];
then
     echo "Failed to execute execute.sh on target machine"
     exit -1
fi

exit 0
