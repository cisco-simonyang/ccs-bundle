#!/bin/bash

export PKG_URL="$1"
export brokerHost="$2"
export brokerPort="$3"
export cloudFamily="$4"
export nodeId="$5"
export agentMode="$6"
export action="$7"
export VHOST="$8"
export bundlestore_credential=""
shift 1

if [ -z $8 ] || [ -z $9 ];then
    echo "No credentials provided for bundle store."
else
    export bundlestore_credential="-u $7:$8"
fi

if [ -z $cloudFamily ];
then
	echo "Cloud Family not passed as command line argument \$3"
	exit 3;
fi

if [ -z $brokerHost ];
then
	echo "Broker Host / Rabbit Server Ip not passed as command line argument \$2"
	exit 4;
fi

export PKG_NAME="agent-lite-linux-bundle.tar.gz"
if [ -z $PKG_URL ];
then
	echo "REPO_URL is not passed as command line argument \$1" 
	exit 5;
fi

if [ -f $PKG_NAME ];
then
    mv -f $PKG_NAME $PKG_NAME.bkp
fi

curl $bundlestore_credential -o $PKG_NAME $PKG_URL

if [ -f $PKG_NAME ];
then
    echo "Downloaded $PKG_URL successful"
fi

export AGENT_HOME="/usr/local/agentlite"

if [ -d $AGENT_HOME ];
then
        echo "AgentLite installed already"
        rm -rf $AGENT_HOME
fi

tar -xvf $PKG_NAME -C /usr/local/

if [ ! -d $AGENT_HOME ];
then
        echo "Package didn't extracted correctly"
        exit 2;
fi

#cp $AGENT_HOME/config/config.template.json $AGENT_HOME/config/config.json
#export configFile=$AGENT_HOME/config/config.json

#sed -i "s,%AMQP_HOST%,$brokerHost,g" $configFile
#sed -i "s,%AMQP_PORT%,$brokerPort,g" $configFile
#sed -i "s,%CLOUD_FAMILY%,$cloudFamily,g" $configFile
#sed -i "s,%NODE_ID%,$nodeId,g" $configFile
#export logFile=$AGENT_HOME/log/agent.log
#[ ! -d $AGENT_HOME/log ] && mkdir $AGENT_HOME/log

#yes | bash -x $AGENT_HOME/bin/agent-start.sh

echo "Export CLOUD_FAMILY $cloudFamily"
echo "Export BROKER_HOST $brokerHost"
echo "Export BROKER_PORT $brokerPort"
echo "Export NODE_ID $nodeId"
echo "Export AGENT_MODE $agentMode"
echo "Export ACTION $action"
echo "Export VHOST $VHOST"
export CLOUD_FAMILY=$cloudFamily
export BROKER_HOST=$brokerHost
export BROKER_PORT=$brokerPort
export NODE_ID=$nodeId
export AGENT_MODE=$agentMode
export ACTION=$action
export VHOST=$VHOST

echo "Invoke agent installation"
bash -x $AGENT_HOME/bin/install

exit 0